-- Diwan AI MVP 2.4 — Muallaqat progress views

create table if not exists poem_editorial_targets (
  poem_id uuid primary key references poems(id) on delete cascade,
  target_verse_count integer not null check (target_verse_count > 0),
  batch_label text,
  updated_at timestamptz not null default now()
);

create or replace view poem_documentation_progress as
select
  p.id as poem_id,
  p.title_ar,
  po.name_ar as poet_name,
  p.verification_status,
  coalesce(t.target_verse_count, count(distinct v.id)) as target_verse_count,
  count(distinct v.id) as imported_verse_count,
  count(distinct te.verse_id) filter (
    where coalesce(te.page_start, '') <> ''
  ) as page_mapped_verse_count,
  count(distinct ves.verse_id) filter (
    where ves.human_reviewed = true
  ) as human_reviewed_verse_count,
  count(distinct vr.verse_id) filter (
    where vr.ready_for_verified = true
  ) as ready_for_verified_verse_count,
  case
    when coalesce(t.target_verse_count, count(distinct v.id)) = 0 then 0
    else round(
      100.0 * count(distinct te.verse_id) filter (
        where coalesce(te.page_start, '') <> ''
      ) / coalesce(t.target_verse_count, count(distinct v.id)),
      1
    )
  end as page_mapping_percent,
  case
    when coalesce(t.target_verse_count, count(distinct v.id)) = 0 then 0
    else round(
      100.0 * count(distinct ves.verse_id) filter (
        where ves.human_reviewed = true
      ) / coalesce(t.target_verse_count, count(distinct v.id)),
      1
    )
  end as human_review_percent
from poems p
join poets po on po.id = p.poet_id
left join poem_editorial_targets t on t.poem_id = p.id
left join verses v on v.poem_id = p.id
left join textual_evidence te on te.verse_id = v.id
left join verse_editorial_state ves on ves.verse_id = v.id
left join verse_verification_readiness vr on vr.verse_id = v.id
group by p.id, po.id, t.target_verse_count;

grant select on poem_documentation_progress to authenticated;
