-- Diwan AI MVP 2.6 — unified Arabic poetry search.
-- Lexical search is authoritative for exact text verification.
-- Semantic similarity remains a discovery aid, not attribution proof.

create extension if not exists pg_trgm;

create index if not exists poets_name_ar_trgm_idx
on poets using gin (name_ar gin_trgm_ops);

create index if not exists poems_title_ar_trgm_idx
on poems using gin (title_ar gin_trgm_ops);

create index if not exists verses_full_text_trgm_idx
on verses using gin (full_text gin_trgm_ops);

create index if not exists poems_meter_ar_idx on poems(meter_ar);
create index if not exists poems_rhyme_ar_idx on poems(rhyme_ar);
create index if not exists poems_poet_id_idx on poems(poet_id);
create index if not exists poets_era_id_idx on poets(era_id);

create or replace function search_poetry(
  query_text text,
  filter_era_id uuid default null,
  filter_poet_id uuid default null,
  filter_meter text default null,
  filter_rhyme text default null,
  result_limit integer default 50
)
returns table (
  result_type text,
  result_id uuid,
  poem_id uuid,
  poet_id uuid,
  era_id uuid,
  title text,
  subtitle text,
  matched_text text,
  verse_order integer,
  verification_status text,
  meter_ar text,
  rhyme_ar text,
  score double precision
)
language sql
stable
security invoker
set search_path = public
as $$
  with q as (
    select nullif(trim(query_text), '') as value
  ),
  verse_hits as (
    select
      'verse'::text as result_type,
      v.id as result_id,
      p.id as poem_id,
      po.id as poet_id,
      e.id as era_id,
      p.title_ar as title,
      po.name_ar || ' — ' || coalesce(e.name_ar, '') as subtitle,
      v.full_text as matched_text,
      v.verse_order,
      p.verification_status,
      p.meter_ar,
      p.rhyme_ar,
      greatest(
        similarity(v.full_text, q.value),
        similarity(v.first_hemistich, q.value),
        similarity(v.second_hemistich, q.value)
      )::double precision as score
    from verses v
    join poems p on p.id = v.poem_id
    join poets po on po.id = p.poet_id
    left join eras e on e.id = po.era_id
    cross join q
    where q.value is not null
      and (
        v.full_text ilike '%' || q.value || '%'
        or v.first_hemistich ilike '%' || q.value || '%'
        or v.second_hemistich ilike '%' || q.value || '%'
        or similarity(v.full_text, q.value) > 0.20
      )
      and (filter_era_id is null or po.era_id = filter_era_id)
      and (filter_poet_id is null or po.id = filter_poet_id)
      and (filter_meter is null or p.meter_ar = filter_meter)
      and (filter_rhyme is null or p.rhyme_ar = filter_rhyme)
  ),
  poem_hits as (
    select
      'poem'::text,
      p.id,
      p.id,
      po.id,
      e.id,
      p.title_ar,
      po.name_ar || ' — ' || coalesce(e.name_ar, ''),
      p.title_ar,
      null::integer,
      p.verification_status,
      p.meter_ar,
      p.rhyme_ar,
      similarity(p.title_ar, q.value)::double precision
    from poems p
    join poets po on po.id = p.poet_id
    left join eras e on e.id = po.era_id
    cross join q
    where q.value is not null
      and (
        p.title_ar ilike '%' || q.value || '%'
        or similarity(p.title_ar, q.value) > 0.20
      )
      and (filter_era_id is null or po.era_id = filter_era_id)
      and (filter_poet_id is null or po.id = filter_poet_id)
      and (filter_meter is null or p.meter_ar = filter_meter)
      and (filter_rhyme is null or p.rhyme_ar = filter_rhyme)
  ),
  poet_hits as (
    select
      'poet'::text,
      po.id,
      null::uuid,
      po.id,
      e.id,
      po.name_ar,
      coalesce(e.name_ar, ''),
      po.name_ar,
      null::integer,
      null::text,
      null::text,
      null::text,
      similarity(po.name_ar, q.value)::double precision
    from poets po
    left join eras e on e.id = po.era_id
    cross join q
    where q.value is not null
      and (
        po.name_ar ilike '%' || q.value || '%'
        or similarity(po.name_ar, q.value) > 0.20
      )
      and (filter_era_id is null or po.era_id = filter_era_id)
      and (filter_poet_id is null or po.id = filter_poet_id)
  )
  select * from (
    select * from verse_hits
    union all
    select * from poem_hits
    union all
    select * from poet_hits
  ) all_hits
  order by
    case result_type when 'verse' then 1 when 'poem' then 2 else 3 end,
    score desc
  limit greatest(1, least(result_limit, 100));
$$;

grant execute on function search_poetry(
  text, uuid, uuid, text, text, integer
) to anon, authenticated;
