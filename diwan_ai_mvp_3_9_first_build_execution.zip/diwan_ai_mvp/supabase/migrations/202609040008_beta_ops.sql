-- Diwan AI MVP 2.1 — Beta Operations
-- Feedback, remote feature flags, and beta configuration.

create table if not exists app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  is_public boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists beta_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  category text not null
    check (category in ('bug','content','suggestion','ai_answer','other')),
  message text not null,
  screen_name text,
  app_version text,
  metadata jsonb not null default '{}'::jsonb,
  status text not null default 'new'
    check (status in ('new','reviewing','resolved','rejected')),
  created_at timestamptz not null default now()
);

alter table app_settings enable row level security;
alter table beta_feedback enable row level security;

drop policy if exists "public read public app settings" on app_settings;
create policy "public read public app settings"
on app_settings for select
to anon, authenticated
using (is_public = true);

drop policy if exists "users submit feedback" on beta_feedback;
create policy "users submit feedback"
on beta_feedback for insert
to anon, authenticated
with check (
  user_id is null
  or auth.uid() = user_id
);

drop policy if exists "users read own feedback" on beta_feedback;
create policy "users read own feedback"
on beta_feedback for select
to authenticated
using (auth.uid() = user_id);

grant select on app_settings to anon, authenticated;
grant insert on beta_feedback to anon, authenticated;
grant select on beta_feedback to authenticated;

-- Initial public feature flags.
insert into app_settings(key, value, is_public)
values
  ('beta_mode', '{"enabled": true, "label": "نسخة تجريبية"}'::jsonb, true),
  ('features', '{
    "rag": true,
    "daily_verse": true,
    "share_cards": true,
    "favorites": true,
    "deep_links": true,
    "feedback": true
  }'::jsonb, true)
on conflict (key) do update
set value = excluded.value,
    is_public = excluded.is_public,
    updated_at = now();
