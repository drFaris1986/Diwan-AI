-- Diwan AI MVP 3.1 — account deletion requests + release readiness.
-- Actual destructive deletion remains a privileged server/admin action.

create table if not exists account_deletion_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  reason text,
  status text not null default 'requested'
    check (status in ('requested', 'processing', 'completed', 'cancelled')),
  requested_at timestamptz not null default now(),
  completed_at timestamptz,
  unique (user_id, status)
);

alter table account_deletion_requests enable row level security;

drop policy if exists "deletion_request_insert_own"
on account_deletion_requests;
create policy "deletion_request_insert_own"
on account_deletion_requests for insert
to authenticated
with check (auth.uid() = user_id and status = 'requested');

drop policy if exists "deletion_request_select_own"
on account_deletion_requests;
create policy "deletion_request_select_own"
on account_deletion_requests for select
to authenticated
using (auth.uid() = user_id);

revoke update, delete on account_deletion_requests from anon, authenticated;
grant select, insert on account_deletion_requests to authenticated;

create or replace view account_data_summary as
select
  u.id as user_id,
  (select count(*) from favorite_poems f where f.user_id = u.id) as favorite_count,
  (select count(*) from saved_verses s where s.user_id = u.id) as saved_verse_count,
  (select count(*) from question_history q where q.user_id = u.id) as question_count,
  (select count(*) from reading_progress r where r.user_id = u.id) as reading_progress_count
from auth.users u;

-- Do not expose the view globally. Users read their own table data directly;
-- the view is reserved for privileged operational tooling.
revoke all on account_data_summary from anon, authenticated;
