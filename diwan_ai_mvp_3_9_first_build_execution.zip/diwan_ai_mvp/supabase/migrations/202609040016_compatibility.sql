-- Diwan AI MVP 2.9 — compatibility and production hardening.
-- Safe additions for fields referenced by newer Flutter screens.

alter table poets
  add column if not exists birth_label text,
  add column if not exists death_label text,
  add column if not exists country_or_region text;

alter table poems
  add column if not exists occasion_ar text,
  add column if not exists editorial_notes text,
  add column if not exists reviewed_at timestamptz,
  add column if not exists reviewed_by text;

alter table verses
  add column if not exists explanation_ar text,
  add column if not exists vocabulary_ar jsonb not null default '{}'::jsonb,
  add column if not exists rhetoric_ar jsonb not null default '[]'::jsonb;

alter table sources
  add column if not exists author_or_editor text,
  add column if not exists publisher text,
  add column if not exists edition text,
  add column if not exists publication_year text,
  add column if not exists license_status text,
  add column if not exists source_type text not null default 'book',
  add column if not exists is_primary boolean not null default false;

alter table verse_sources
  add column if not exists quote_variant text,
  add column if not exists variant_type text;

-- Needed by metadata upsert scripts.
create unique index if not exists poets_name_ar_unique_idx
on poets(name_ar);

-- Useful catalog indexes.
create index if not exists poems_verification_status_idx
on poems(verification_status);

create index if not exists verses_poem_order_idx
on verses(poem_id, verse_order);

-- Keep editorial fields server-controlled.
revoke update (
  editorial_notes,
  reviewed_at,
  reviewed_by
) on poems from anon, authenticated;

revoke update (
  license_status,
  is_primary
) on sources from anon, authenticated;
