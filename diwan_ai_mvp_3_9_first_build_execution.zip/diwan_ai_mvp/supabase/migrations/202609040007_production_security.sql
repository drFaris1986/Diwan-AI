-- Diwan AI MVP 1.9 — Production security baseline
-- Run AFTER schema, user features, RAG, daily verse, and editorial SQL.

-- Explicit grants for public content.
grant select on table
  eras,
  poets,
  sources,
  poems,
  poem_sources,
  verses,
  topics,
  poem_topics,
  verse_sources,
  daily_verses
to anon, authenticated;

-- User-owned tables.
grant select, insert, update, delete on table
  profiles,
  favorite_poems,
  saved_verses,
  question_history
to authenticated;

-- Editorial tables should NOT be writable by mobile clients.
grant select on table
  verse_variants,
  editorial_reviews
to authenticated;

revoke insert, update, delete on table
  verse_variants,
  editorial_reviews
from anon, authenticated;

-- Views exposed to clients.
grant select on table
  verse_catalog,
  rag_evidence_catalog,
  daily_verse_catalog,
  poem_editorial_status
to anon, authenticated;

-- Search RPC.
grant execute on function match_verses(vector(1536), integer, double precision)
to authenticated, service_role;

-- Restrict anonymous access to semantic search RPC by default.
revoke execute on function match_verses(vector(1536), integer, double precision)
from anon;

-- Ensure RLS is enabled on user-owned tables.
alter table profiles enable row level security;
alter table favorite_poems enable row level security;
alter table saved_verses enable row level security;
alter table question_history enable row level security;

-- Editorial content is read-only from app clients.
alter table verse_variants enable row level security;
alter table editorial_reviews enable row level security;

drop policy if exists "authenticated read verse variants" on verse_variants;
create policy "authenticated read verse variants"
on verse_variants for select
to authenticated
using (true);

drop policy if exists "authenticated read editorial reviews" on editorial_reviews;
create policy "authenticated read editorial reviews"
on editorial_reviews for select
to authenticated
using (true);

-- Intentionally no insert/update/delete policies for editorial tables.
-- Writes should come only from a trusted admin environment/service role.
