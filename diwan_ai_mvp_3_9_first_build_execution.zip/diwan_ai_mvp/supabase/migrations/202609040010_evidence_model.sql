-- Diwan AI MVP 2.3 — granular textual evidence
-- Adds page-level evidence and verse-level review state.

create table if not exists textual_evidence (
  id uuid primary key default gen_random_uuid(),
  verse_id uuid not null references verses(id) on delete cascade,
  source_id uuid not null references sources(id) on delete cascade,
  evidence_type text not null default 'edition'
    check (evidence_type in ('edition','digital_crosscheck','commentary','manuscript','other')),
  page_start text,
  page_end text,
  quoted_first_hemistich text,
  quoted_second_hemistich text,
  normalized_match boolean,
  reviewer_note text,
  created_at timestamptz not null default now()
);

create table if not exists verse_editorial_state (
  verse_id uuid primary key references verses(id) on delete cascade,
  source_count integer not null default 0,
  page_evidence_count integer not null default 0,
  crosscheck_count integer not null default 0,
  has_material_variant boolean not null default false,
  human_reviewed boolean not null default false,
  review_status text not null default 'pending'
    check (review_status in ('pending','ready_for_review','approved','changes_required','disputed')),
  reviewed_by_label text,
  reviewed_at timestamptz,
  notes text,
  updated_at timestamptz not null default now()
);

create index if not exists textual_evidence_verse_idx
on textual_evidence(verse_id);

create index if not exists textual_evidence_source_idx
on textual_evidence(source_id);

create or replace view verse_verification_readiness as
select
  v.id as verse_id,
  v.poem_id,
  v.verse_order,
  v.first_hemistich,
  v.second_hemistich,
  p.title_ar as poem_title,
  po.name_ar as poet_name,
  p.verification_status as poem_verification_status,
  count(distinct te.source_id) as evidence_source_count,
  count(distinct te.id) filter (
    where coalesce(te.page_start, '') <> ''
  ) as page_evidence_count,
  count(distinct te.id) filter (
    where te.evidence_type = 'digital_crosscheck'
  ) as digital_crosscheck_count,
  coalesce(ves.has_material_variant, false) as has_material_variant,
  coalesce(ves.human_reviewed, false) as human_reviewed,
  coalesce(ves.review_status, 'pending') as verse_review_status,
  case
    when coalesce(ves.review_status, 'pending') = 'disputed' then false
    when count(distinct te.source_id) >= 2
      and count(distinct te.id) filter (
        where coalesce(te.page_start, '') <> ''
      ) >= 1
      and coalesce(ves.human_reviewed, false) = true
      and coalesce(ves.has_material_variant, false) = false
    then true
    else false
  end as ready_for_verified
from verses v
join poems p on p.id = v.poem_id
join poets po on po.id = p.poet_id
left join textual_evidence te on te.verse_id = v.id
left join verse_editorial_state ves on ves.verse_id = v.id
group by
  v.id, p.id, po.id, ves.has_material_variant,
  ves.human_reviewed, ves.review_status;

grant select on textual_evidence to authenticated;
grant select on verse_editorial_state to authenticated;
grant select on verse_verification_readiness to authenticated;

-- Mobile clients remain read-only for editorial evidence.
revoke insert, update, delete on textual_evidence from anon, authenticated;
revoke insert, update, delete on verse_editorial_state from anon, authenticated;
