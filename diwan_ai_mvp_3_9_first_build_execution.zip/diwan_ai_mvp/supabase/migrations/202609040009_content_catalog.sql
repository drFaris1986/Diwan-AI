-- Diwan AI MVP 2.2 — editorial content catalog

create table if not exists poet_source_candidates (
  id uuid primary key default gen_random_uuid(),
  poet_id uuid not null references poets(id) on delete cascade,
  source_id uuid not null references sources(id) on delete cascade,
  editorial_rank text not null default 'candidate'
    check (editorial_rank in ('primary_candidate','secondary_candidate','commentary_candidate','candidate')),
  notes text,
  created_at timestamptz not null default now(),
  unique(poet_id, source_id)
);

create table if not exists content_expansion_queue (
  id uuid primary key default gen_random_uuid(),
  poet_id uuid not null references poets(id) on delete cascade,
  target_poem_count integer not null default 5 check (target_poem_count > 0),
  imported_poem_count integer not null default 0 check (imported_poem_count >= 0),
  reviewed_poem_count integer not null default 0 check (reviewed_poem_count >= 0),
  priority integer not null default 100,
  status text not null default 'planned'
    check (status in ('planned','sourcing','importing','reviewing','complete','blocked')),
  notes text,
  updated_at timestamptz not null default now(),
  unique(poet_id)
);

create or replace view content_expansion_status as
select
  po.id as poet_id,
  po.name_ar as poet_name,
  e.name_ar as era_name,
  q.target_poem_count,
  q.imported_poem_count,
  q.reviewed_poem_count,
  q.priority,
  q.status,
  count(distinct p.id) as database_poem_count,
  count(distinct p.id) filter (where p.verification_status = 'verified') as verified_poem_count,
  count(distinct p.id) filter (where p.verification_status = 'review_required') as review_required_poem_count,
  count(distinct psc.source_id) as source_candidate_count
from poets po
left join eras e on e.id = po.era_id
left join poems p on p.poet_id = po.id
left join content_expansion_queue q on q.poet_id = po.id
left join poet_source_candidates psc on psc.poet_id = po.id
group by po.id, e.name_ar, q.target_poem_count, q.imported_poem_count,
         q.reviewed_poem_count, q.priority, q.status;

grant select on content_expansion_status to authenticated;
