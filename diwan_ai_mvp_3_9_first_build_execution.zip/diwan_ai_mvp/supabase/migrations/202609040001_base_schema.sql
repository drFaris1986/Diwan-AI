-- Diwan AI MVP 1.0
-- PostgreSQL / Supabase schema
-- Focus: poets, eras, poems, verses, sources, topics, and citation-ready retrieval.

create extension if not exists pgcrypto;
create extension if not exists vector;

create table if not exists eras (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null unique,
  sort_order int not null,
  start_label text,
  end_label text,
  description_ar text,
  created_at timestamptz not null default now()
);

create table if not exists poets (
  id uuid primary key default gen_random_uuid(),
  era_id uuid references eras(id) on delete set null,
  name_ar text not null,
  name_normalized text not null,
  birth_label text,
  death_label text,
  bio_ar text,
  country_or_region text,
  created_at timestamptz not null default now()
);

create index if not exists poets_name_normalized_idx on poets(name_normalized);

create table if not exists sources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  author_or_editor text,
  publisher text,
  edition text,
  publication_year text,
  url text,
  source_type text not null default 'book',
  reliability_score numeric(3,2) not null default 0.80
    check (reliability_score >= 0 and reliability_score <= 1),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists poems (
  id uuid primary key default gen_random_uuid(),
  poet_id uuid references poets(id) on delete cascade,
  era_id uuid references eras(id) on delete set null,
  title_ar text not null,
  title_normalized text not null,
  meter_ar text,
  rhyme_ar text,
  occasion_ar text,
  verification_status text not null default 'review_required'
    check (verification_status in ('verified','review_required','disputed')),
  created_at timestamptz not null default now()
);

create index if not exists poems_title_normalized_idx on poems(title_normalized);

create table if not exists poem_sources (
  poem_id uuid references poems(id) on delete cascade,
  source_id uuid references sources(id) on delete cascade,
  page_reference text,
  notes text,
  primary key (poem_id, source_id)
);

create table if not exists verses (
  id uuid primary key default gen_random_uuid(),
  poem_id uuid references poems(id) on delete cascade,
  verse_order int not null,
  first_hemistich text not null,
  second_hemistich text,
  full_text text generated always as (
    case
      when second_hemistich is null or second_hemistich = '' then first_hemistich
      else first_hemistich || ' / ' || second_hemistich
    end
  ) stored,
  normalized_text text not null,
  explanation_ar text,
  vocabulary_ar jsonb not null default '{}'::jsonb,
  rhetoric_ar jsonb not null default '[]'::jsonb,
  embedding vector(1536),
  created_at timestamptz not null default now(),
  unique (poem_id, verse_order)
);

create index if not exists verses_normalized_text_idx on verses using gin (to_tsvector('simple', normalized_text));

create table if not exists topics (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null unique
);

create table if not exists poem_topics (
  poem_id uuid references poems(id) on delete cascade,
  topic_id uuid references topics(id) on delete cascade,
  primary key (poem_id, topic_id)
);

create table if not exists verse_sources (
  verse_id uuid references verses(id) on delete cascade,
  source_id uuid references sources(id) on delete cascade,
  page_reference text,
  quote_variant text,
  notes text,
  primary key (verse_id, source_id)
);

-- Citation-ready search view
create or replace view verse_catalog as
select
  v.id as verse_id,
  v.poem_id,
  v.verse_order,
  v.first_hemistich,
  v.second_hemistich,
  v.full_text,
  v.normalized_text,
  v.explanation_ar,
  p.title_ar as poem_title,
  p.meter_ar,
  p.rhyme_ar,
  p.verification_status,
  po.id as poet_id,
  po.name_ar as poet_name,
  e.name_ar as era_name
from verses v
join poems p on p.id = v.poem_id
join poets po on po.id = p.poet_id
left join eras e on e.id = p.era_id;

-- Optional semantic match RPC for Supabase.
create or replace function match_verses(
  query_embedding vector(1536),
  match_count int default 8,
  match_threshold float default 0.55
)
returns table (
  verse_id uuid,
  poem_id uuid,
  verse_order int,
  full_text text,
  poem_title text,
  poet_name text,
  era_name text,
  verification_status text,
  similarity float
)
language sql stable
as $$
  select
    v.id,
    p.id,
    v.verse_order,
    v.full_text,
    p.title_ar,
    po.name_ar,
    e.name_ar,
    p.verification_status,
    1 - (v.embedding <=> query_embedding) as similarity
  from verses v
  join poems p on p.id = v.poem_id
  join poets po on po.id = p.poet_id
  left join eras e on e.id = p.era_id
  where v.embedding is not null
    and 1 - (v.embedding <=> query_embedding) >= match_threshold
  order by v.embedding <=> query_embedding
  limit match_count;
$$;
