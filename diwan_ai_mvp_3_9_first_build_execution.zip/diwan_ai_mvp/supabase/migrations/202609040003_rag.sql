-- Diwan AI MVP 1.4 — semantic search / RAG upgrade
-- Uses 1536-dimensional embeddings to match text-embedding-3-small.

create extension if not exists vector;

alter table verses
  add column if not exists embedding vector(1536);

create index if not exists verses_embedding_hnsw_idx
on verses using hnsw (embedding vector_cosine_ops);

create or replace function match_verses(
  query_embedding vector(1536),
  match_count int default 8,
  match_threshold float default 0.50
)
returns table (
  verse_id uuid,
  poem_id uuid,
  verse_order int,
  full_text text,
  poem_title text,
  poet_name text,
  era_name text,
  verification_status text,
  similarity float
)
language sql stable
as $$
  select
    v.id,
    p.id,
    v.verse_order,
    v.full_text,
    p.title_ar,
    po.name_ar,
    e.name_ar,
    p.verification_status,
    1 - (v.embedding <=> query_embedding) as similarity
  from verses v
  join poems p on p.id = v.poem_id
  join poets po on po.id = p.poet_id
  left join eras e on e.id = p.era_id
  where v.embedding is not null
    and 1 - (v.embedding <=> query_embedding) >= match_threshold
  order by v.embedding <=> query_embedding
  limit least(match_count, 20);
$$;

create or replace view rag_evidence_catalog as
select
  v.id as verse_id,
  v.full_text,
  v.verse_order,
  p.id as poem_id,
  p.title_ar as poem_title,
  p.verification_status,
  po.name_ar as poet_name,
  e.name_ar as era_name,
  coalesce(
    jsonb_agg(
      distinct jsonb_build_object(
        'title', s.title,
        'url', s.url,
        'page_reference', vs.page_reference,
        'reliability_score', s.reliability_score
      )
    ) filter (where s.id is not null),
    '[]'::jsonb
  ) as sources
from verses v
join poems p on p.id = v.poem_id
join poets po on po.id = p.poet_id
left join eras e on e.id = p.era_id
left join verse_sources vs on vs.verse_id = v.id
left join sources s on s.id = vs.source_id
group by v.id, p.id, po.name_ar, e.name_ar;
