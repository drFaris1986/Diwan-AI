-- Diwan AI MVP 1.7 — textual variants + editorial audit trail

create table if not exists verse_variants (
  id uuid primary key default gen_random_uuid(),
  verse_id uuid not null references verses(id) on delete cascade,
  source_id uuid references sources(id) on delete set null,
  first_hemistich_variant text,
  second_hemistich_variant text,
  full_text_variant text,
  variant_type text not null default 'wording'
    check (variant_type in ('wording','order','orthography','attribution','other')),
  editorial_note text,
  is_preferred boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists editorial_reviews (
  id uuid primary key default gen_random_uuid(),
  poem_id uuid references poems(id) on delete cascade,
  verse_id uuid references verses(id) on delete cascade,
  reviewer_label text not null,
  decision text not null
    check (decision in ('approved','changes_requested','disputed')),
  notes text,
  reviewed_at timestamptz not null default now(),
  constraint review_target_check
    check (
      (poem_id is not null and verse_id is null)
      or
      (poem_id is null and verse_id is not null)
    )
);

create index if not exists verse_variants_verse_idx
on verse_variants(verse_id);

create index if not exists editorial_reviews_poem_idx
on editorial_reviews(poem_id);

create index if not exists editorial_reviews_verse_idx
on editorial_reviews(verse_id);

create or replace view poem_editorial_status as
select
  p.id as poem_id,
  p.title_ar,
  p.verification_status,
  po.name_ar as poet_name,
  count(distinct v.id) as verse_count,
  count(distinct vs.source_id) as linked_source_count,
  count(distinct vv.id) as variant_count,
  count(distinct er.id) filter (where er.decision = 'approved') as approval_count,
  count(distinct er.id) filter (where er.decision = 'changes_requested') as changes_requested_count,
  count(distinct er.id) filter (where er.decision = 'disputed') as disputed_review_count
from poems p
join poets po on po.id = p.poet_id
left join verses v on v.poem_id = p.id
left join verse_sources vs on vs.verse_id = v.id
left join verse_variants vv on vv.verse_id = v.id
left join editorial_reviews er on er.poem_id = p.id
group by p.id, po.name_ar;
