-- Diwan AI MVP 1.5
-- User profiles, favorites, saved poems, and question history.

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists favorite_poems (
  user_id uuid references auth.users(id) on delete cascade,
  poem_id uuid references poems(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, poem_id)
);

create table if not exists saved_verses (
  user_id uuid references auth.users(id) on delete cascade,
  verse_id uuid references verses(id) on delete cascade,
  note text,
  created_at timestamptz not null default now(),
  primary key (user_id, verse_id)
);

create table if not exists question_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  question text not null,
  answer text,
  confidence numeric(4,3),
  evidence jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table favorite_poems enable row level security;
alter table saved_verses enable row level security;
alter table question_history enable row level security;

drop policy if exists "users read own profile" on profiles;
create policy "users read own profile" on profiles for select
using (auth.uid() = id);

drop policy if exists "users update own profile" on profiles;
create policy "users update own profile" on profiles for update
using (auth.uid() = id)
with check (auth.uid() = id);

drop policy if exists "users insert own profile" on profiles;
create policy "users insert own profile" on profiles for insert
with check (auth.uid() = id);

drop policy if exists "users manage own favorites" on favorite_poems;
create policy "users manage own favorites" on favorite_poems for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "users manage own saved verses" on saved_verses;
create policy "users manage own saved verses" on saved_verses for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "users manage own history" on question_history;
create policy "users manage own history" on question_history for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
