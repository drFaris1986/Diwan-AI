-- Diwan AI MVP 1.8 — Verse of the Day

create table if not exists daily_verses (
  day date primary key,
  verse_id uuid not null references verses(id) on delete cascade,
  editorial_note text,
  created_at timestamptz not null default now()
);

alter table daily_verses enable row level security;

drop policy if exists "public read daily verse" on daily_verses;
create policy "public read daily verse" on daily_verses for select
using (true);

create or replace view daily_verse_catalog as
select
  d.day,
  d.editorial_note,
  v.id as verse_id,
  v.first_hemistich,
  v.second_hemistich,
  v.full_text,
  p.id as poem_id,
  p.title_ar as poem_title,
  p.verification_status,
  po.id as poet_id,
  po.name_ar as poet_name,
  e.name_ar as era_name
from daily_verses d
join verses v on v.id = d.verse_id
join poems p on p.id = v.poem_id
join poets po on po.id = p.poet_id
left join eras e on e.id = p.era_id;
