-- Diwan AI MVP 2.7 — Smart Home personalization and reading continuity.

create table if not exists reading_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  poem_id uuid not null references poems(id) on delete cascade,
  last_verse_id uuid references verses(id) on delete set null,
  last_verse_order integer,
  progress_percent numeric(5,2) not null default 0
    check (progress_percent >= 0 and progress_percent <= 100),
  updated_at timestamptz not null default now(),
  primary key (user_id, poem_id)
);

create table if not exists poem_popularity_daily (
  day date not null default current_date,
  poem_id uuid not null references poems(id) on delete cascade,
  read_count integer not null default 0 check (read_count >= 0),
  save_count integer not null default 0 check (save_count >= 0),
  share_count integer not null default 0 check (share_count >= 0),
  primary key (day, poem_id)
);

alter table reading_progress enable row level security;
alter table poem_popularity_daily enable row level security;

drop policy if exists "reading_progress_select_own" on reading_progress;
create policy "reading_progress_select_own"
on reading_progress for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "reading_progress_write_own" on reading_progress;
create policy "reading_progress_write_own"
on reading_progress for all
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "popularity_read_all" on poem_popularity_daily;
create policy "popularity_read_all"
on poem_popularity_daily for select
to anon, authenticated
using (true);

grant select, insert, update, delete on reading_progress to authenticated;
grant select on poem_popularity_daily to anon, authenticated;

create or replace view popular_poems_30d as
select
  p.id as poem_id,
  p.title_ar,
  po.name_ar as poet_name,
  p.verification_status,
  coalesce(sum(pp.read_count), 0) as reads,
  coalesce(sum(pp.save_count), 0) as saves,
  coalesce(sum(pp.share_count), 0) as shares,
  (
    coalesce(sum(pp.read_count), 0)
    + 3 * coalesce(sum(pp.save_count), 0)
    + 2 * coalesce(sum(pp.share_count), 0)
  ) as popularity_score
from poems p
join poets po on po.id = p.poet_id
left join poem_popularity_daily pp
  on pp.poem_id = p.id
 and pp.day >= current_date - interval '30 days'
group by p.id, po.id
order by popularity_score desc;

grant select on popular_poems_30d to anon, authenticated;

create or replace view continue_reading_catalog as
select
  rp.user_id,
  rp.poem_id,
  rp.last_verse_id,
  rp.last_verse_order,
  rp.progress_percent,
  rp.updated_at,
  p.title_ar,
  po.name_ar as poet_name,
  p.verification_status
from reading_progress rp
join poems p on p.id = rp.poem_id
join poets po on po.id = p.poet_id;

grant select on continue_reading_catalog to authenticated;
