-- Diwan AI MVP 2.8 — privacy-conscious product analytics.
-- Raw events are append-only from clients. User-facing dashboards expose aggregates only.

create table if not exists app_events (
  id uuid primary key default gen_random_uuid(),
  event_name text not null check (
    event_name in (
      'poem_open',
      'verse_save',
      'favorite_add',
      'favorite_remove',
      'verse_share',
      'search_performed',
      'rag_question',
      'continue_reading'
    )
  ),
  user_id uuid references auth.users(id) on delete set null,
  session_id text not null,
  poem_id uuid references poems(id) on delete set null,
  verse_id uuid references verses(id) on delete set null,
  metadata jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now()
);

create index if not exists app_events_occurred_at_idx
on app_events(occurred_at desc);

create index if not exists app_events_event_name_idx
on app_events(event_name);

create index if not exists app_events_poem_id_idx
on app_events(poem_id)
where poem_id is not null;

create index if not exists app_events_verse_id_idx
on app_events(verse_id)
where verse_id is not null;

alter table app_events enable row level security;

drop policy if exists "app_events_insert" on app_events;
create policy "app_events_insert"
on app_events for insert
to anon, authenticated
with check (
  user_id is null
  or auth.uid() = user_id
);

-- Raw analytics are not readable from mobile clients.
revoke select, update, delete on app_events from anon, authenticated;
grant insert on app_events to anon, authenticated;

-- Keep MVP 2.7 popularity table synchronized from app events.
create or replace function apply_app_event_to_popularity()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.poem_id is null then
    return new;
  end if;

  if new.event_name not in ('poem_open', 'verse_save', 'favorite_add', 'verse_share') then
    return new;
  end if;

  insert into poem_popularity_daily (
    day, poem_id, read_count, save_count, share_count
  )
  values (
    (new.occurred_at at time zone 'utc')::date,
    new.poem_id,
    case when new.event_name = 'poem_open' then 1 else 0 end,
    case when new.event_name in ('verse_save', 'favorite_add') then 1 else 0 end,
    case when new.event_name = 'verse_share' then 1 else 0 end
  )
  on conflict (day, poem_id)
  do update set
    read_count = poem_popularity_daily.read_count
      + excluded.read_count,
    save_count = poem_popularity_daily.save_count
      + excluded.save_count,
    share_count = poem_popularity_daily.share_count
      + excluded.share_count;

  return new;
end;
$$;

drop trigger if exists app_events_popularity_trigger on app_events;
create trigger app_events_popularity_trigger
after insert on app_events
for each row execute function apply_app_event_to_popularity();

create or replace view analytics_overview_30d as
select
  count(*) filter (
    where event_name = 'poem_open'
  ) as poem_opens,
  count(*) filter (
    where event_name = 'verse_save'
  ) as verse_saves,
  count(*) filter (
    where event_name = 'verse_share'
  ) as verse_shares,
  count(*) filter (
    where event_name = 'search_performed'
  ) as searches,
  count(*) filter (
    where event_name = 'rag_question'
  ) as rag_questions,
  count(distinct session_id) as sessions,
  count(distinct user_id) filter (
    where user_id is not null
  ) as signed_in_users
from app_events
where occurred_at >= now() - interval '30 days';

create or replace view analytics_top_poems_30d as
select
  p.id as poem_id,
  p.title_ar,
  po.name_ar as poet_name,
  count(*) filter (
    where ae.event_name = 'poem_open'
  ) as opens,
  count(*) filter (
    where ae.event_name = 'verse_save'
  ) as saves,
  count(*) filter (
    where ae.event_name = 'verse_share'
  ) as shares,
  count(*) as total_events
from app_events ae
join poems p on p.id = ae.poem_id
join poets po on po.id = p.poet_id
where ae.occurred_at >= now() - interval '30 days'
group by p.id, po.id
order by total_events desc, opens desc;

create or replace view analytics_top_poets_30d as
select
  po.id as poet_id,
  po.name_ar as poet_name,
  count(*) filter (
    where ae.event_name = 'poem_open'
  ) as poem_opens,
  count(*) filter (
    where ae.event_name = 'verse_save'
  ) as verse_saves,
  count(*) filter (
    where ae.event_name = 'verse_share'
  ) as verse_shares,
  count(*) as total_events
from app_events ae
join poems p on p.id = ae.poem_id
join poets po on po.id = p.poet_id
where ae.occurred_at >= now() - interval '30 days'
group by po.id
order by total_events desc, poem_opens desc;

-- Beta dashboard exposes only aggregate rows, never event-level user data.
grant select on analytics_overview_30d to authenticated;
grant select on analytics_top_poems_30d to authenticated;
grant select on analytics_top_poets_30d to authenticated;
