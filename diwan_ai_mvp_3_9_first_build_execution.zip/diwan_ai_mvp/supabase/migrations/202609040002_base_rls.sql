-- Enable RLS and allow public read-only access for MVP.
-- Admin writes should use a service role only on a trusted backend.

alter table eras enable row level security;
alter table poets enable row level security;
alter table sources enable row level security;
alter table poems enable row level security;
alter table poem_sources enable row level security;
alter table verses enable row level security;
alter table topics enable row level security;
alter table poem_topics enable row level security;
alter table verse_sources enable row level security;

drop policy if exists "public read eras" on eras;
create policy "public read eras" on eras for select using (true);

drop policy if exists "public read poets" on poets;
create policy "public read poets" on poets for select using (true);

drop policy if exists "public read sources" on sources;
create policy "public read sources" on sources for select using (true);

drop policy if exists "public read poems" on poems;
create policy "public read poems" on poems for select using (true);

drop policy if exists "public read poem_sources" on poem_sources;
create policy "public read poem_sources" on poem_sources for select using (true);

drop policy if exists "public read verses" on verses;
create policy "public read verses" on verses for select using (true);

drop policy if exists "public read topics" on topics;
create policy "public read topics" on topics for select using (true);

drop policy if exists "public read poem_topics" on poem_topics;
create policy "public read poem_topics" on poem_topics for select using (true);

drop policy if exists "public read verse_sources" on verse_sources;
create policy "public read verse_sources" on verse_sources for select using (true);
