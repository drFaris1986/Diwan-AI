-- Diwan AI MVP 2.5 — reading tools, verse navigation, and variants summary.

create or replace view poem_reading_catalog as
select
  p.id as poem_id,
  p.title_ar,
  po.name_ar as poet_name,
  e.name_ar as era_name,
  p.verification_status,
  v.id as verse_id,
  v.verse_order,
  v.first_hemistich,
  v.second_hemistich,
  v.full_text,
  count(distinct vv.id) as variant_count,
  count(distinct te.id) as evidence_count,
  count(distinct te.source_id) as evidence_source_count
from poems p
join poets po on po.id = p.poet_id
left join eras e on e.id = p.era_id
join verses v on v.poem_id = p.id
left join verse_variants vv on vv.verse_id = v.id
left join textual_evidence te on te.verse_id = v.id
group by
  p.id, po.id, e.id, v.id;

grant select on poem_reading_catalog to anon, authenticated;

create or replace view verse_variant_catalog as
select
  vv.id,
  vv.verse_id,
  vv.variant_type,
  vv.first_hemistich_variant,
  vv.second_hemistich_variant,
  vv.full_text_variant,
  vv.editorial_note,
  vv.is_preferred,
  s.title as source_title,
  s.author_or_editor,
  s.publisher,
  s.edition,
  s.publication_year
from verse_variants vv
left join sources s on s.id = vv.source_id;

grant select on verse_variant_catalog to authenticated;
