import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getSupabaseSecretKey } from "../_shared/supabase_secrets.ts";
import { OPENAI_EMBEDDING_MODEL, requireOpenAIKey } from "../_shared/openai.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = getSupabaseSecretKey();
    const openaiKey = requireOpenAIKey();

    const supabase = createClient(supabaseUrl, serviceKey);

    const { limit = 50 } = await req.json().catch(() => ({}));

    const { data: verses, error } = await supabase
      .from("verses")
      .select("id, full_text")
      .is("embedding", null)
      .limit(Math.min(Number(limit) || 50, 100));

    if (error) throw error;
    if (!verses?.length) {
      return Response.json({ updated: 0, message: "No pending verses." }, {
        headers: corsHeaders,
      });
    }

    const inputs = verses.map((v) => v.full_text);

    const embeddingResponse = await fetch("https://api.openai.com/v1/embeddings", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: OPENAI_EMBEDDING_MODEL,
        input: inputs,
        encoding_format: "float",
      }),
    });

    if (!embeddingResponse.ok) {
      throw new Error(await embeddingResponse.text());
    }

    const embeddingJson = await embeddingResponse.json();

    let updated = 0;
    for (let i = 0; i < verses.length; i++) {
      const embedding = embeddingJson.data?.[i]?.embedding;
      if (!embedding) continue;

      const { error: updateError } = await supabase
        .from("verses")
        .update({ embedding })
        .eq("id", verses[i].id);

      if (updateError) throw updateError;
      updated++;
    }

    return Response.json({ updated }, { headers: corsHeaders });
  } catch (error) {
    return Response.json(
      { error: String(error?.message ?? error) },
      { status: 500, headers: corsHeaders },
    );
  }
});
