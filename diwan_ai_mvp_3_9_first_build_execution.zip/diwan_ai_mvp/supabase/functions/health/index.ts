import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getSupabaseSecretKey } from "../_shared/supabase_secrets.ts";

Deno.serve(async () => {
  const startedAt = Date.now();

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    if (!supabaseUrl) throw new Error("SUPABASE_URL is missing.");

    const client = createClient(supabaseUrl, getSupabaseSecretKey());

    const checks: Record<string, unknown> = {};

    const { count: poemCount, error: poemError } = await client
      .from("poems")
      .select("*", { count: "exact", head: true });

    checks.poems = {
      ok: !poemError,
      count: poemCount ?? 0,
      error: poemError?.message,
    };

    const { count: verseCount, error: verseError } = await client
      .from("verses")
      .select("*", { count: "exact", head: true });

    checks.verses = {
      ok: !verseError,
      count: verseCount ?? 0,
      error: verseError?.message,
    };

    return Response.json({
      ok: !poemError && !verseError,
      service: "diwan-ai",
      version: "2.0.0-beta",
      checks,
      elapsed_ms: Date.now() - startedAt,
    });
  } catch (error) {
    return Response.json(
      {
        ok: false,
        service: "diwan-ai",
        version: "2.0.0-beta",
        error: String(error?.message ?? error),
        elapsed_ms: Date.now() - startedAt,
      },
      { status: 500 },
    );
  }
});
