import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getSupabaseSecretKey } from "../_shared/supabase_secrets.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return Response.json({ error: "method_not_allowed" }, { status: 405, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const publishableKey = Deno.env.get("SUPABASE_ANON_KEY");
    if (!supabaseUrl || !publishableKey) {
      throw new Error("Supabase client environment is not configured.");
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return Response.json({ error: "authentication_required" }, { status: 401, headers: corsHeaders });
    }

    // Resolve the caller with the caller's token.
    const caller = createClient(supabaseUrl, publishableKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false },
    });

    const { data: userData, error: userError } = await caller.auth.getUser();
    if (userError || !userData.user) {
      return Response.json({ error: "invalid_session" }, { status: 401, headers: corsHeaders });
    }

    const userId = userData.user.id;

    // Privileged client exists only inside the Edge Function.
    const admin = createClient(supabaseUrl, getSupabaseSecretKey(), {
      auth: { persistSession: false },
    });

    const { data: requestRow, error: requestError } = await admin
      .from("account_deletion_requests")
      .select("id,status")
      .eq("user_id", userId)
      .eq("status", "requested")
      .order("requested_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (requestError) throw requestError;
    if (!requestRow) {
      return Response.json(
        { error: "deletion_request_required" },
        { status: 409, headers: corsHeaders },
      );
    }

    await admin
      .from("account_deletion_requests")
      .update({ status: "processing" })
      .eq("id", requestRow.id);

    // Cascading foreign keys remove user-owned rows. Analytics user_id is SET NULL.
    const { error: deleteError } = await admin.auth.admin.deleteUser(userId);
    if (deleteError) {
      // The request row may be deleted by cascade if auth deletion partially succeeded;
      // this update is best-effort only.
      await admin
        .from("account_deletion_requests")
        .update({ status: "requested" })
        .eq("id", requestRow.id);
      throw deleteError;
    }

    return Response.json(
      { deleted: true },
      { status: 200, headers: corsHeaders },
    );
  } catch (error) {
    return Response.json(
      { error: String(error?.message ?? error) },
      { status: 500, headers: corsHeaders },
    );
  }
});
