import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getSupabaseSecretKey } from "../_shared/supabase_secrets.ts";
import { OPENAI_EMBEDDING_MODEL, OPENAI_RAG_MODEL, requireOpenAIKey } from "../_shared/openai.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function extractResponseText(payload: any): string {
  if (typeof payload?.output_text === "string") return payload.output_text;

  const chunks: string[] = [];
  for (const item of payload?.output ?? []) {
    for (const content of item?.content ?? []) {
      if (typeof content?.text === "string") chunks.push(content.text);
    }
  }
  return chunks.join("\n").trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { question } = await req.json();

    if (!question || String(question).trim().length < 2) {
      return Response.json({ error: "question is required" }, {
        status: 400,
        headers: corsHeaders,
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    if (!supabaseUrl) throw new Error("SUPABASE_URL is not configured.");

    const supabase = createClient(
      supabaseUrl,
      getSupabaseSecretKey(),
    );
    const openaiKey = requireOpenAIKey();

    // 1) Embed the user's Arabic question.
    const embResp = await fetch("https://api.openai.com/v1/embeddings", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: OPENAI_EMBEDDING_MODEL,
        input: String(question),
        encoding_format: "float",
      }),
    });

    if (!embResp.ok) throw new Error(await embResp.text());
    const embJson = await embResp.json();
    const queryEmbedding = embJson.data?.[0]?.embedding;
    if (!queryEmbedding) throw new Error("Embedding was not returned.");

    // 2) Semantic retrieval through pgvector RPC.
    const { data: matches, error: matchError } = await supabase.rpc(
      "match_verses",
      {
        query_embedding: queryEmbedding,
        match_count: 8,
        match_threshold: 0.48,
      },
    );
    if (matchError) throw matchError;

    if (!matches?.length) {
      return Response.json({
        answer:
          "لم أجد في قاعدة ديوان الحالية أدلة كافية للإجابة بثقة. لن أنسب أبياتًا أو معلومات شعرية من دون دليل مسترجع.",
        evidence: [],
        confidence: 0,
      }, { headers: corsHeaders });
    }

    // 3) Enrich retrieved verses with source metadata.
    const verseIds = matches.map((m: any) => m.verse_id);
    const { data: catalog, error: catalogError } = await supabase
      .from("rag_evidence_catalog")
      .select("*")
      .in("verse_id", verseIds);

    if (catalogError) throw catalogError;

    const catalogById = new Map(
      (catalog ?? []).map((row: any) => [row.verse_id, row]),
    );

    const evidence = matches.map((m: any, index: number) => {
      const rich = catalogById.get(m.verse_id) ?? {};
      return {
        evidence_id: index + 1,
        verse_id: m.verse_id,
        text: m.full_text,
        poet: m.poet_name,
        poem_title: m.poem_title,
        era: m.era_name,
        verification_status: m.verification_status,
        similarity: Number(m.similarity ?? 0),
        sources: rich.sources ?? [],
      };
    });

    const evidenceText = evidence.map((e: any) => `
[${e.evidence_id}]
النص: ${e.text}
الشاعر: ${e.poet}
القصيدة: ${e.poem_title}
العصر: ${e.era}
حالة التوثيق: ${e.verification_status}
درجة التشابه: ${e.similarity.toFixed(3)}
المصادر: ${JSON.stringify(e.sources)}
`).join("\n");

    const instructions = `
أنت "ديوان AI"، مساعد متخصص في الشعر العربي.
أجب بالعربية الواضحة.
قواعد صارمة:
1) اعتمد فقط على الأدلة المقدمة لك في هذه الرسالة.
2) لا تخترع بيتًا شعريًا، ولا تكمل بيتًا من ذاكرتك، ولا تنسب نصًا لشاعر إذا لم يوجد ذلك في الأدلة.
3) عند ذكر معلومة من الأدلة، ضع رقم الدليل بصيغة [1] أو [2].
4) إذا كانت حالة التوثيق review_required فقل بوضوح إن النص يحتاج مراجعة تحريرية قبل الاعتماد النهائي.
5) إذا لم تكف الأدلة، قل ذلك صراحة بدل التخمين.
6) فرّق بين "التشابه الدلالي" و"التوثيق النصي".
7) لا تعتبر similarity وحدها دليل صحة نسبة البيت.
`;

    // 4) Generate grounded answer using the Responses API.
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: OPENAI_RAG_MODEL,
        instructions,
        input: `سؤال المستخدم:\n${question}\n\nالأدلة المسترجعة:\n${evidenceText}`,
        max_output_tokens: 900,
      }),
    });

    if (!response.ok) throw new Error(await response.text());
    const responseJson = await response.json();
    const answer = extractResponseText(responseJson);

    const topSimilarity = Math.max(
      ...evidence.map((e: any) => Number(e.similarity || 0)),
    );
    const hasVerified = evidence.some(
      (e: any) => e.verification_status === "verified",
    );
    const sourceCount = evidence.reduce(
      (sum: number, e: any) => sum + (e.sources?.length ?? 0),
      0,
    );

    // This is a product confidence indicator, not a statistical probability.
    let confidence = topSimilarity * 0.65;
    if (hasVerified) confidence += 0.20;
    if (sourceCount > 0) confidence += 0.10;
    confidence = Math.max(0, Math.min(confidence, 0.95));

    return Response.json({
      answer,
      evidence,
      confidence,
      model: OPENAI_RAG_MODEL,
    }, { headers: corsHeaders });
  } catch (error) {
    return Response.json(
      { error: String(error?.message ?? error) },
      { status: 500, headers: corsHeaders },
    );
  }
});
