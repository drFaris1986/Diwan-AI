export function getSupabaseSecretKey(): string {
  // Current Supabase secret-key environment variable is a JSON dictionary.
  const modern = Deno.env.get("SUPABASE_SECRET_KEYS");
  if (modern) {
    try {
      const parsed = JSON.parse(modern);
      const value = parsed?.default;
      if (typeof value === "string" && value.length > 0) return value;
    } catch (_) {
      // Fall through to legacy key for older projects.
    }
  }

  const legacy = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy && legacy.length > 0) return legacy;

  throw new Error(
    "Missing Supabase server secret. Configure SUPABASE_SECRET_KEYS or SUPABASE_SERVICE_ROLE_KEY.",
  );
}
