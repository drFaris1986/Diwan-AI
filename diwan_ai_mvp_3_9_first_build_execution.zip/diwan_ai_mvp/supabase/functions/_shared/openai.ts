export const OPENAI_EMBEDDING_MODEL =
  Deno.env.get("OPENAI_EMBEDDING_MODEL") || "text-embedding-3-small";

export const OPENAI_RAG_MODEL =
  Deno.env.get("OPENAI_RAG_MODEL") || "gpt-5.6-luna";

export function requireOpenAIKey(): string {
  const key = Deno.env.get("OPENAI_API_KEY");
  if (!key) throw new Error("OPENAI_API_KEY is not configured.");
  return key;
}
