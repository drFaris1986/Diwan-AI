-- Minimal seed data for Diwan AI MVP.
-- These entries are intentionally limited; production ingestion must be tied to reviewed sources.

insert into eras (name_ar, sort_order, description_ar)
values
('العصر الجاهلي', 1, 'الشعر العربي قبل الإسلام.'),
('صدر الإسلام', 2, 'الشعر في صدر الإسلام.'),
('العصر الأموي', 3, 'الشعر في العصر الأموي.'),
('العصر العباسي', 4, 'الشعر في العصر العباسي.'),
('العصر الأندلسي', 5, 'الشعر العربي في الأندلس.'),
('العصر المملوكي', 6, 'الشعر في العصر المملوكي.'),
('العصر العثماني', 7, 'الشعر في العصر العثماني.'),
('عصر النهضة', 8, 'الشعر في النهضة العربية.'),
('العصر الحديث', 9, 'الشعر العربي الحديث.'),
('العصر المعاصر', 10, 'الشعر العربي المعاصر.')
on conflict (name_ar) do nothing;

insert into poets (era_id, name_ar, name_normalized, bio_ar)
select id, 'امرؤ القيس', 'امرؤ القيس', 'من أشهر شعراء العصر الجاهلي.'
from eras where name_ar='العصر الجاهلي'
and not exists (select 1 from poets where name_ar='امرؤ القيس');

insert into poets (era_id, name_ar, name_normalized, bio_ar)
select id, 'عنترة بن شداد', 'عنترة بن شداد', 'شاعر وفارس جاهلي.'
from eras where name_ar='العصر الجاهلي'
and not exists (select 1 from poets where name_ar='عنترة بن شداد');

insert into poets (era_id, name_ar, name_normalized, bio_ar)
select id, 'المتنبي', 'المتنبي', 'من أشهر شعراء العصر العباسي.'
from eras where name_ar='العصر العباسي'
and not exists (select 1 from poets where name_ar='المتنبي');

insert into sources (title, source_type, reliability_score, notes)
select 'مصدر تجريبي للنسخة الأولية', 'editorial_demo', 0.50,
'يجب استبداله بمراجع محققة قبل الإطلاق العام.'
where not exists (select 1 from sources where title='مصدر تجريبي للنسخة الأولية');
