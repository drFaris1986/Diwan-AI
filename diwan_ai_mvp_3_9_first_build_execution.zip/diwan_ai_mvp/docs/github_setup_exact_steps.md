# GitHub — Exact First Build Steps

1. أنشئ Private Repository باسم مناسب مثل:
   `diwan-ai`

2. فك الحزمة في جهاز فيه Git، ثم من داخل مجلد المشروع:
```bash
bash scripts/prepare_github_repository.sh
```

3. أضف remote وادفع إلى `main`.

4. من GitHub:
   Settings → Secrets and variables → Actions.

5. Variables:
   - `DIWAN_ANDROID_APP_ID`
   - `DIWAN_IOS_BUNDLE_ID`
   - `DIWAN_APP_LINK_DOMAIN`

6. Secrets:
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`

يمكن ترك Supabase فارغًا لأول compile فقط؛ سيعمل التطبيق في local fallback.

7. Actions → **Diwan AI Mobile Build** → Run workflow.

8. السيناريوهات:
   - Quality أحمر: نزّل `quality-failure-logs`.
   - Android أحمر: نزّل `android-failure-logs`.
   - iOS أحمر: نزّل `ios-failure-logs`.
   - Android أخضر: نزّل `diwan-ai-android-debug`.
   - iOS أخضر: نزّل `diwan-ai-ios-simulator`.

9. بعد أول Run، عالج logs قبل أي Feature إضافية.
