# Mobile Build — Next Steps

## أقصر طريق إلى أول Build فعلي

### GitHub
1. ضع المشروع في repository خاص.
2. ارفع الملفات.
3. افتح Actions.
4. شغل workflow:
   `Diwan AI Mobile Build`
5. راقب job Android وjob iOS.
6. نزّل artifacts إذا نجحا.

### إذا فشل analyze
نصلح أخطاء Dart/Flutter من log ثم نعيد workflow.

### إذا فشل Android
نراجع:
- Gradle/JDK.
- plugin Android manifests.
- minSdk / compileSdk.
- package compatibility.

### إذا فشل iOS
نراجع:
- CocoaPods.
- plugin podspecs.
- minimum iOS deployment target.
- Xcode/Swift build issues.

## بعد أول Build ناجح
- استبدال package IDs.
- إضافة الأيقونة.
- splash.
- Android release signing.
- iOS signing.
- TestFlight/Internal Testing.
