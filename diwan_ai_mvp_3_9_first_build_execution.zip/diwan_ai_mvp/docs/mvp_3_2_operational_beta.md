# Diwan AI — MVP 3.2 Operational Beta

## الهدف
الانتقال من "طلب حذف الحساب" إلى workflow حقيقي وآمن، وتجميع خطوات فحص الإصدار في pipeline واحدة.

## حذف الحساب
أضيفت Edge Function:
`delete-account`

التدفق:
1. المستخدم يسجل طلب حذف عبر جدول `account_deletion_requests`.
2. المستخدم يؤكد الحذف النهائي من التطبيق.
3. Edge Function تتحقق من JWT الحالي.
4. تتحقق من وجود طلب بحالة `requested`.
5. تستخدم مفتاح Supabase السري داخل الخادم فقط.
6. تحذف مستخدم Auth عبر Admin API.
7. علاقات FK تنظف بيانات الحساب، بينما analytics غير المعرِّفة يمكن أن تبقى مجمعة.

لا يوجد Service Role / Secret Key داخل Flutter.

## Release Pipeline
`scripts/release_pipeline.sh`

يشغل:
- structural preflight.
- release candidate check.
- Flutter pub/analyze/test إذا كان Flutter متوفرًا.
- staging smoke test إذا كانت بيئة Supabase متوفرة.

## Staging Smoke
يتحقق من:
- eras
- poets
- poems
- verses
- popular_poems_30d
- health Edge Function

## ما يزال يحتاج بيئة حقيقية
- تنفيذ migrations.
- نشر Edge Functions.
- تشغيل OpenAI.
- Flutter compile.
- iOS/Android signing.
