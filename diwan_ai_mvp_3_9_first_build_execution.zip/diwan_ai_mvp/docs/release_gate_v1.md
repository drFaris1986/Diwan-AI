# Release Gate v1

لا تعتبر نسخة Diwan AI Beta قابلة للإطلاق العام قبل نجاح الآتي:

## Build
- `flutter pub get`
- `flutter analyze`
- `flutter test`
- Android debug build
- iOS simulator/device build

## Supabase
- `supabase db push` على مشروع staging جديد.
- لا migration تفشل.
- اختبار RLS بمستخدمين مختلفين.
- التأكد من أن raw analytics غير قابلة للقراءة من mobile clients.
- اختبار account / favorites / saved verses / reading progress.

## Edge Functions
- health = 200
- embed-verses = يعمل على دفعة صغيرة
- ask-diwan = يرفض الاختلاق عند غياب الدليل
- لا secret key في client bundle

## Editorial
- لا قصيدة `verified` دون page evidence + review.
- disputed content ظاهر بوضوح.
- modern copyrighted poetry لا يستورد نصه بكميات كبيرة دون ترخيص.

## Search
- exact verse
- partial verse
- typo-near search
- filters
- wrong attribution query

## Privacy
- نص البحث غير مخزن في analytics.
- raw events غير قابلة للقراءة من العميل.
