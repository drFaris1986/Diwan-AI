# Diwan AI — Beta Operations Runbook

## قبل النشر إلى Staging
1. راجع `.env.example`.
2. أنشئ مشروع Supabase Staging منفصلًا عن Production.
3. اضبط `SUPABASE_PROJECT_REF`.
4. اضبط OpenAI secrets في Supabase Edge Functions.
5. شغل `scripts/deploy_beta.sh`.
6. اضبط `SUPABASE_URL` و`SUPABASE_PUBLISHABLE_KEY`.
7. شغل `scripts/staging_smoke_test.py`.

## قبل توزيع التطبيق
1. شغل `scripts/release_pipeline.sh`.
2. يجب أن ينجح `flutter analyze`.
3. يجب أن تنجح الاختبارات.
4. اختبر حسابين منفصلين للتحقق من RLS.
5. اختبر حذف حساب تجريبي فقط.
6. اختبر سؤال RAG بلا دليل؛ يجب ألا يخترع بيتًا.
7. اختبر سؤال نسبة خاطئة لبيت معروف.
8. راجع شاشة الخصوصية وحالة التوثيق.

## Incident
إذا ظهرت نسبة شعرية خاطئة:
- صنفها P1.
- عطّل/اخفِ المحتوى محل الشك إذا لزم.
- غيّر الحالة إلى `review_required` أو `disputed`.
- راجع الأدلة قبل إعادة النشر.

إذا ظهر تسرب بيانات أو تجاوز RLS:
- أوقف Beta.
- دوّر الأسرار المتأثرة.
- راجع السياسات قبل إعادة الفتح.
