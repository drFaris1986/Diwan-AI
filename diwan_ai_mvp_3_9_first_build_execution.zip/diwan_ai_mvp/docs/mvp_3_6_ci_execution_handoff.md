# Diwan AI — MVP 3.6 CI Execution Handoff

## هذه هي نقطة الانتقال إلى Build حقيقي

لم نعد نحتاج Feature جديدة قبل الـCI.

الـworkflow الحالي يحتوي على ثلاث بوابات:

### 1. Quality
- Flutter 3.47.2
- platform generation
- native config verification
- `flutter pub get`
- `dart format --set-exit-if-changed`
- `flutter analyze`
- `flutter test`

إذا فشلت Quality فلن يبدأ Android أو iOS.

### 2. Android
ينتج:
`build/app/outputs/flutter-apk/app-debug.apk`

ويتم رفعه باسم:
`diwan-ai-android-debug`

### 3. iOS
على macOS:
`flutter build ios --simulator`

ثم يرفع:
`diwan-ai-ios-simulator.zip`

## GitHub Variables
يفضل ضبطها قبل التشغيل:

- `DIWAN_ANDROID_APP_ID`
- `DIWAN_IOS_BUNDLE_ID`
- `DIWAN_APP_LINK_DOMAIN`

إذا لم تكن الهوية التجارية النهائية حُسمت، يمكن لأول compile تشغيل placeholders مؤقتًا.

## GitHub Secrets
لبناء متصل بـSupabase:
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`

لا تضع:
- `OPENAI_API_KEY`
- Supabase Secret/Service Role
في Client CI.

## إذا فشل CI
نزّل diagnostic artifact ثم:
```bash
python scripts/ci_failure_summary.py PATH_TO_EXTRACTED_LOGS
```

سيحول logs إلى قائمة أخطاء أقصر نستخدمها للإصلاح.

## المعيار
لا نقول إن Build ناجح إلا عندما يظهر Artifact فعلي في GitHub Actions.
