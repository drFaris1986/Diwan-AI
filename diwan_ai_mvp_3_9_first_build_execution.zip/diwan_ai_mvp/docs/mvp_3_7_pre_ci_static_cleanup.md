# Diwan AI — MVP 3.7 Pre-CI Static Cleanup

قبل أول تشغيل Flutter فعلي أضيف فحص لا يحتاج Dart SDK لاكتشاف أخطاء تناسق المصدر مبكرًا.

## الإصلاحات
- توحيد package imports في tests مع اسم الحزمة في pubspec.
- استخدام Supabase initialization parameter متوافق مع baseline الحالي.
- إصلاح صياغة PostgREST `.or(...)` في Smart Home.
- فحص local/package imports قبل تشغيل Flutter.

## Quality CI
الترتيب الآن:
1. source consistency.
2. platform generation.
3. pub get.
4. format.
5. analyze.
6. tests.

الهدف أن يكون أول فشل حقيقي متعلقًا بـFlutter/Gradle/Xcode بدل أخطاء يمكن اكتشافها مسبقًا.
