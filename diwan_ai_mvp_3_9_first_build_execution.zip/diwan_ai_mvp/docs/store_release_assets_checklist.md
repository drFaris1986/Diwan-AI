# Store Release Assets Checklist

## Branding
- [ ] App icon master artwork.
- [ ] iOS icon asset set.
- [ ] Android adaptive icon.
- [ ] launch/splash assets.
- [ ] screenshots for phone sizes.
- [ ] optional tablet screenshots.

## Identity
- [ ] final Bundle ID.
- [ ] final Android Application ID.
- [ ] support email.
- [ ] support URL.
- [ ] privacy policy public URL.
- [ ] terms URL if published separately.

## Native
- [ ] generate ios/android Flutter platform folders.
- [ ] deep link URL scheme.
- [ ] Universal Links / App Links.
- [ ] associated domains.
- [ ] signing certificates/profiles.
- [ ] Android keystore and Play signing flow.

## Review
- [ ] account deletion flow if accounts are offered.
- [ ] test account for reviewers if needed.
- [ ] content moderation/reporting path if user-generated content is later added.
- [ ] verify AI disclosures and help text.
- [ ] legal review of privacy policy and terms.
