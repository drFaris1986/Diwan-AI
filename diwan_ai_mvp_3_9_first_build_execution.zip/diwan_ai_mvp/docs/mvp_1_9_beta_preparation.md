# Diwan AI — MVP 1.9 Beta Preparation

## ما تم تحديثه

### 1. Supabase client key
تم تحديث التطبيق ليستخدم `publishableKey` في `Supabase.initialize`.
ما زال يدعم `SUPABASE_ANON_KEY` كـ fallback مؤقت للمشاريع القديمة.

تشغيل مفضل:
```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxx
```

### 2. Baseline للحزم
- `supabase_flutter: ^2.15.4`
- `share_plus: ^12.0.2`
- `app_links: ^6.4.1`

تم اختيار هذه الإصدارات لأنها متوافقة مع Dart 3.5 baseline الحالي للمشروع.
لا نستخدم أحدث إصدارات كل الحزم قسرًا لأن بعضها يتطلب Dart أحدث.

### 3. Production security SQL
الملف:
`supabase/mvp_1_9_production_security.sql`

يفرض:
- أقل صلاحيات ممكنة للعميل.
- عدم السماح بكتابة جداول التحرير من تطبيق الهاتف.
- إبقاء service role في بيئة موثوقة فقط.
- RLS لجداول المستخدم.

### 4. شاشة جاهزية Beta
`جاهزية النسخة التجريبية`

تفحص:
- إعداد Supabase.
- قراءة الشعراء والقصائد والأبيات.
- View بيت اليوم.
- استجابة Edge Function الخاصة بـ RAG.

### 5. Preflight محلي
```bash
python scripts/beta_preflight.py
```

هذا يفحص سلامة ملفات المشروع وJSON وإعدادات البيئة.
لا يقوم بعمل Flutter build.

## ما يلزم خارج بيئة ChatGPT قبل Beta حقيقية
1. إنشاء/ربط مشروع Supabase فعلي.
2. تشغيل ملفات SQL بالترتيب.
3. نشر Edge Functions.
4. ضبط الأسرار في Supabase.
5. تشغيل `flutter pub get`.
6. تشغيل `flutter analyze`.
7. تشغيل اختبارات Flutter.
8. بناء Android وiOS.
9. اختبار تسجيل الدخول وRAG والمشاركة وDeep Links على أجهزة حقيقية.
10. تدقيق RLS من حساب anon وحساب authenticated.
11. مراجعة سياسة الخصوصية وشروط الاستخدام قبل النشر العام.

## قيد مهم
هذه الحزمة مصدر برمجي محسّن للـBeta، وليست build مُجربًا على جهاز لأن Flutter SDK غير متوفر في بيئة الإنشاء الحالية.
