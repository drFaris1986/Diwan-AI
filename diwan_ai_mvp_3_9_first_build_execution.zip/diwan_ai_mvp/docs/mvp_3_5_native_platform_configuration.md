# Diwan AI — MVP 3.5 Native Platform Configuration

- Android minimum API: 24.
- iOS minimum version: 15.
- `diwanai://` custom scheme.
- `app_links` plugin mode disables Flutter's built-in deep-link handler.
- Optional HTTPS App/Universal Links using `DIWAN_APP_LINK_DOMAIN`.
- Optional real Android/iOS identifiers using `DIWAN_ANDROID_APP_ID` and `DIWAN_IOS_BUNDLE_ID`.

These minimums match Flutter 3.47.2 current supported mobile platforms.
