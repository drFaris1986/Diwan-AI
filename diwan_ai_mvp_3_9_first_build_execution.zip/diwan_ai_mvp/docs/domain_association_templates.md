# Deep Link Domain Association Templates

## Android assetlinks.json
Use your real Application ID and release signing SHA-256 fingerprint.

## iOS apple-app-site-association
Use your real Apple Team ID and Bundle ID, with `/poem/*` and `/poet/*` paths.
