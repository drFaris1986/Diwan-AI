# Diwan AI — MVP 3.8 Compile Risk Reduction

تم فصل parser الروابط العميقة عن plugin لتسهيل اختباره، وجعل AppLinks lazy، وتشديد SharedPreferences async، وإضافة widget smoke test للـOnboarding.

كما أضيف Compile/Security Risk Scan قبل Flutter CI للتأكد من عدم وجود مفاتيح خادمية داخل Flutter أو استخدام parameter غير متوافق مع baseline الحالي.

الهدف التالي هو أول GitHub CI run فعلي.
