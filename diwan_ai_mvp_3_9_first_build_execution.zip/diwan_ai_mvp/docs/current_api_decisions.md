# Current API Decisions — September 2026

## Supabase
Flutter initialization uses:
- `url`
- `publishableKey`

Legacy `anonKey` remains only as a compatibility fallback.

On Edge Functions, current Supabase environments expose:
- `SUPABASE_PUBLISHABLE_KEYS`
- `SUPABASE_SECRET_KEYS`

The code prefers the modern secret dictionary and falls back to
`SUPABASE_SERVICE_ROLE_KEY` for older projects.

## OpenAI
RAG uses the Responses API.
Current default model in Diwan:
- `gpt-5.6-luna`

Embedding model:
- `text-embedding-3-small`

The OpenAI key remains server-side in Supabase Edge Functions only.

## Package baseline
Project baseline remains Dart 3.5-compatible:
- supabase_flutter 2.15.4
- share_plus 12.0.2
- app_links 6.4.1

This is intentional. Newer stable package releases may require newer Dart versions.
