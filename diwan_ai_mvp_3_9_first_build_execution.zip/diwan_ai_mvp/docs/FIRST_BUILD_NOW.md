# FIRST BUILD NOW

وصل المشروع إلى النقطة التي يجب فيها تشغيل Flutter خارج بيئة ChatGPT الحالية.

## المطلوب الآن

### 1. أنشئ GitHub Private Repository
اسم مقترح:
`diwan-ai`

### 2. فك الحزمة وارفع محتويات مجلد `diwan_ai_mvp`

من Terminal:

```bash
cd diwan_ai_mvp
bash scripts/first_ci_run_checklist.sh
git init
git branch -M main
git add .
git commit -m "Diwan AI first build candidate"
git remote add origin YOUR_GITHUB_REPOSITORY
git push -u origin main
```

### 3. شغل GitHub Actions

GitHub → Actions → **Diwan AI Mobile Build** → Run workflow.

لا تحتاج Supabase لأول Compile فقط.

## النتيجة المطلوبة

### Quality أخضر
يعني:
- dependencies resolved
- Dart formatting صحيح
- flutter analyze ناجح
- flutter test ناجح

### Android أخضر
Artifact:
`diwan-ai-android-debug`

ويحتوي:
`app-debug.apk`

### iOS أخضر
Artifact:
`diwan-ai-ios-simulator`

ويحتوي:
`Runner.app`

## إذا ظهر أحمر

نزّل artifact الخاص بالفشل:
- `quality-failure-logs`
- `android-failure-logs`
- `ios-failure-logs`

ثم أرسل ملف الـZIP الخاص بالـlogs إلى ChatGPT في هذه المحادثة.

لا نحتاج وصف الخطأ يدويًا؛ الـlogs نفسها هي الأفضل.
