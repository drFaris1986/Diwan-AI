# Diwan AI — MVP 3.1 Release Readiness

## الجديد
- طلب حذف الحساب داخل التطبيق.
- جدول `account_deletion_requests` مع RLS.
- الحذف الفعلي يبقى عملية server/admin privileged ولا يتم من Flutter مباشرة.
- شاشة جاهزية إصدار واضحة داخل التطبيق.
- migration رقم 17 ضمن `supabase/migrations`.
- release candidate checker.

## لماذا لا نحذف auth.users من Flutter؟
حذف المستخدم من Supabase Auth يحتاج صلاحية إدارية ولا يجب وضعها في تطبيق الهاتف.
العميل يسجل الطلب فقط، ثم تنفذه وظيفة خادم أو إجراء إداري موثوق.

## ما يزال يمنع الإطلاق
- Flutter SDK build/analyze/test.
- إنشاء ios/android.
- staging Supabase deploy.
- Edge Functions live.
- signing.
- public legal/support URLs.
- اختبار متجر حقيقي.
