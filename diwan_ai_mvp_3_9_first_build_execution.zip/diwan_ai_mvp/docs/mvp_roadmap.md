# خارطة الطريق — ديوان AI

## MVP 1.2 — الذي تم بناؤه الآن
- طبقة Repository قابلة للتبديل بين Local وSupabase
- تهيئة Supabase داخل Flutter
- شاشة حالة الاتصال والبيانات
- RLS للقراءة العامة
- سكربت استيراد تحريرية
- نموذج JSON لدفعات القصائد
- فصل مفاتيح البيئة عن الكود

## MVP 1.3
- بيانات حقيقية مراجعة
- صفحة شاعر من قاعدة البيانات
- صفحة قصيدة من قاعدة البيانات
- بحث مباشر في Supabase
- عرض المصدر والصفحة

## MVP 1.4
- embeddings
- semantic search
- RAG فعلي
- إجابات مع استشهادات
- درجة ثقة

## MVP 1.5
- حساب مستخدم
- المفضلة
- سجل الأسئلة
- قصيدة اليوم
- شاعر اليوم


## MVP 1.4 — تم تجهيز البنية
- semantic search عبر pgvector
- embeddings للأبيات
- Edge Function للاسترجاع والتوليد
- RAG grounded answers
- evidence cards
- confidence indicator
- test cases

## المرحلة التالية — MVP 1.5
- تحويل Dataset من review_required إلى verified عبر مراجع محققة
- توسيع المحتوى
- حسابات المستخدمين والمفضلة
- سجل الأسئلة
