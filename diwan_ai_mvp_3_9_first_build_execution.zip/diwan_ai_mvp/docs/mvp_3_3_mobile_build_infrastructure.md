# Diwan AI — MVP 3.3 Mobile Build Infrastructure

## الهدف
تحويل المشروع من مصدر Flutter فقط إلى مشروع يمكن توليد Android/iOS له وبناؤه في بيئة CI مناسبة.

## Flutter
الـworkflow يستخدم Flutter `3.47.2` لأن وثائق Flutter الرسمية الحالية في سبتمبر 2026 تشير إلى هذا الإصدار في صفحات إعداد Android/Linux.

## Android
يتم:
1. توليد `android/`.
2. `flutter pub get`.
3. `flutter analyze`.
4. `flutter test` إذا وُجد مجلد tests.
5. `flutter build apk --debug`.
6. رفع `app-debug.apk` كـCI artifact.

استخدام debug هنا مقصود: الهدف أولًا إثبات أن المشروع يترجم على Android دون الحاجة إلى keystore إنتاجي.

## iOS
iOS لا يمكن بناؤه على Linux. الـworkflow يستخدم macOS runner:
1. توليد `ios/`.
2. `flutter pub get`.
3. `flutter analyze`.
4. الاختبارات.
5. `flutter build ios --simulator`.
6. ضغط `Runner.app` ورفعه كـCI artifact.

Simulator build يثبت أن كود iOS يترجم دون شهادة Apple أو provisioning profile.

## المعرّفات
`bootstrap_mobile_platforms.sh` يولد package IDs تحت `com.example`.
هذا Placeholder فقط ولا يجوز استخدامه للإطلاق التجاري.

قبل المتاجر يجب اختيار:
- iOS Bundle Identifier نهائي.
- Android Application ID نهائي.
- Apple Team.
- Android upload keystore.

## الأسرار
الموبايل يأخذ فقط:
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`

لا يوضع:
- Supabase service/secret key
- OpenAI API key
داخل Flutter أو GitHub mobile build secrets التي تصل للعميل.

## متى نقول "Android build ناجح"؟
فقط بعد أن ينتج CI:
`build/app/outputs/flutter-apk/app-debug.apk`

## متى نقول "iOS build ناجح"؟
فقط بعد أن ينتج macOS CI:
`build/ios/iphonesimulator/Runner.app`

وجود scripts/workflow وحده لا يعني أن build قد نجح.
