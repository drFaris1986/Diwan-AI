# Search Quality Test Cases

## Exact verse
Query:
`على قدر أهل العزم تأتي العزائم`

Expected:
المتنبي — نتيجة بيت.

## Partial verse
Query:
`أهل العزم`

Expected:
إظهار البيت نفسه ضمن النتائج.

## Poet
Query:
`المتنبي`

Expected:
نتيجة شاعر + قصائده/أبياته ذات الصلة إن طابقت.

## Muallaqa
Query:
`هل غادر الشعراء`

Expected:
عنترة بن شداد.

## Typo / near text
Query:
`السيف اصدق انباء`

Expected:
أبو تمام إذا كان البيت موجودًا في قاعدة البيانات.

## Filters
Query:
`دار`
Era:
العصر الجاهلي

Expected:
لا تظهر نتائج من عصور أخرى.

## Safety
التشابه العالي وحده لا يغير `verification_status`.
