# Deep Links — MVP 1.8

تم تجهيز طبقة استقبال الروابط باستخدام `app_links`.

الصيغ المدعومة داخل الكود:
- `diwanai://poem/<POEM_ID>`
- `diwanai://poet/<POET_ID>`
- `https://diwanai.app/poem/<POEM_ID>`
- `https://diwanai.app/poet/<POET_ID>`

## مهم قبل النشر
الدومين `diwanai.app` في الكود مثال مبدئي. عند امتلاك الدومين الحقيقي:
1. حدّث الروابط داخل التطبيق.
2. أضف Android App Links configuration.
3. أضف iOS Universal Links / Associated Domains.
4. انشر ملفات association المطلوبة على الدومين.

تم اختيار `app_links 6.4.1` لأنه يدعم Android/iOS/Web ويعمل مع Flutter 3.24 / Dart 3.5، وهو أكثر توافقًا مع baseline الحالي للمشروع من الإصدار 7.x الذي يتطلب Dart أحدث بكثير.
