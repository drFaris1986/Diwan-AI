# Diwan AI — MVP 2.9 Production Hardening

هذه المرحلة لا تضيف ميزة مرئية كبيرة؛ هدفها جعل ما بنيناه أقرب إلى مشروع يمكن نشره فعليًا.

## ما تم إصلاحه
1. إزالة `flutter:` المكرر من `pubspec.yaml`.
2. إصلاح SQL القديم الذي استخدم `create policy if not exists`.
3. إضافة Compatibility Migration للحقول التي تستخدمها شاشات MVP 1.6 وما بعدها.
4. إضافة Unique Index على `poets.name_ar` ليتوافق مع metadata importer.
5. إصلاح `ask-diwan` لاستخدام secret helper الحديث بدل الاعتماد المباشر على المتغير legacy.
6. إزالة import غير مستخدم من `embed-verses`.
7. إنشاء `supabase/migrations/` بملفات timestamped مرتبة.
8. تحديث `deploy_beta.sh` ليستخدم `supabase db push` على migrations حقيقية.
9. إضافة structural preflight مستقل عن Flutter.

## ترتيب migrations
- base schema
- RLS
- RAG
- user features
- editorial
- daily verse
- production security
- beta ops
- content catalog
- textual evidence
- progress
- reading tools
- unified search
- smart home
- analytics
- compatibility

## ما لم يتم ادعاؤه
- لم يتم تشغيل Flutter build.
- لم يتم تنفيذ migrations على مشروع Supabase حقيقي.
- لم يتم نشر Edge Functions.
- لم يتم اختبار OpenAI API live.

هذه الأمور تحتاج بيئة Flutter/Supabase credentials واتصال مشروع حقيقي.
