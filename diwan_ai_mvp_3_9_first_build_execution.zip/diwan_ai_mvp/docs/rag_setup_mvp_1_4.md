# تشغيل RAG الحقيقي — Diwan AI MVP 1.4

## البنية
سؤال المستخدم
→ OpenAI Embeddings
→ Supabase pgvector
→ `match_verses`
→ جلب الأدلة والمصادر
→ OpenAI Responses API
→ إجابة مقيدة بالأدلة
→ عرض المصادر + مؤشر الثقة

## 1) SQL
بعد `schema.sql` نفّذ:

```sql
-- supabase/mvp_1_4_rag.sql
```

## 2) أسرار Edge Functions
داخل Supabase Functions Secrets أضف:

- `OPENAI_API_KEY`
- `OPENAI_RAG_MODEL` (اختياري)

القيمة الافتراضية في الكود:
`gpt-5.6-luna`

لا تضع `OPENAI_API_KEY` داخل تطبيق Flutter.

## 3) نشر الدوال

```bash
supabase functions deploy embed-verses
supabase functions deploy ask-diwan
```

## 4) توليد embeddings للأبيات
استدعِ `embed-verses` على دفعات بعد استيراد القصائد.

مثال من Supabase Functions أو أداة API:
```json
{"limit": 50}
```

كرر حتى تصبح كل الأبيات ذات embedding.

## 5) تشغيل Flutter
```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

ثم افتح:
**اسأل ديوان — RAG**

## سياسة منع الهلوسة
الدالة `ask-diwan` تُلزم النموذج بعدم:
- اختراع أبيات.
- إكمال بيت من الذاكرة.
- نسبة بيت دون دليل.
- التعامل مع similarity كأنه توثيق.
- إخفاء حالة `review_required`.

## مهم
RAG لا يحوّل مصدرًا ضعيفًا إلى مصدر موثوق.
جودة الإجابة تعتمد على جودة قاعدة الشعر والمصادر المحققة.
