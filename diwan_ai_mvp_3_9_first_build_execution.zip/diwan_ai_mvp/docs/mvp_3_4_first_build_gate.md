# Diwan AI — MVP 3.4 First Real Build Gate

## الهدف
النسخة 3.4 لا تدعي أن binary تم بناؤه بعد؛ بل تجعل أول تشغيل CI يعطي إجابة حاسمة وقابلة للإصلاح:

1. هل dependencies تحل؟
2. هل `flutter analyze` ينجح؟
3. هل unit tests تنجح؟
4. هل Android ينتج APK؟
5. هل iOS ينتج Runner.app؟

## اختبارات فعلية أضيفت
- ArabicNormalizer.
- Deep-link parser.
- AppConfig.

## CI الآن 3 مراحل
### Quality
لا يسمح ببناء المنصات قبل نجاح:
- pub get
- analyze
- tests

### Android
ينتج:
`app-debug.apk`

### iOS
ينتج:
`Runner.app`
على macOS/Xcode.

## Diagnostics
أضيف:
- `collect_flutter_diagnostics.sh`
- `parse_flutter_failures.py`

إذا فشل build في جهاز تطوير أو CI، تحفظ logs ويمكن تحويلها إلى قائمة أخطاء محددة بدل التخمين.

## الإصدار المستهدف
Flutter stable `3.47.2`، وهو الإصدار الذي تعكسه وثائق Flutter الرسمية الحالية في سبتمبر 2026.

## نقطة القرار التالية
لا نضيف ميزات جديدة قبل اجتياز Quality job.
أول خطأ compile حقيقي يصبح أولوية المرحلة التالية.
