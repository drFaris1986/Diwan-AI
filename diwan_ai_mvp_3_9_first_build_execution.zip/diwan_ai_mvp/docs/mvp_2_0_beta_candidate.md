# Diwan AI — MVP 2.0 Beta Candidate

هذه المرحلة تحول المشروع من سلسلة MVPs إلى **Beta Candidate**.

## ما تم تنفيذه

### Backend
- دعم Supabase publishable keys في Flutter.
- دعم Supabase secret-key environment الجديد داخل Edge Functions مع fallback للمفتاح القديم.
- Health Edge Function.
- RAG على الخادم فقط.
- OpenAI API key لا يدخل تطبيق الهاتف.
- default RAG model: `gpt-5.6-luna`.
- default embedding model: `text-embedding-3-small`.

### Deployment
- `scripts/deploy_beta.sh`
- `scripts/beta_live_smoke_test.py`
- checklist نشر واختبار.

### Security
- أقل صلاحيات ممكنة للعميل.
- RLS لجداول المستخدم.
- عدم فتح جداول التحرير للكتابة من الجوال.
- أسرار OpenAI وSupabase server-side فقط.

## لماذا لم ننفذ Live Deployment هنا؟
لأن المستودع لا يحتوي Project Ref أو مفاتيح مشروع Supabase فعلية، ولا يجب إنشاء أسرار وهمية أو وضع مفاتيح حقيقية داخل الحزمة.

## خطوات الانتقال إلى Beta حقيقية
1. ربط مشروع Supabase.
2. تنفيذ migrations.
3. استيراد Dataset.
4. نشر Edge Functions.
5. وضع `OPENAI_API_KEY` كسر في Supabase.
6. توليد embeddings.
7. تشغيل live smoke test.
8. تشغيل Flutter build على بيئة فيها Flutter SDK.
9. اختبار iPhone وAndroid فعليًا.
