# ربط ديوان AI مع Supabase

## 1) أنشئ مشروع Supabase
من لوحة Supabase أنشئ مشروعًا جديدًا.

## 2) نفّذ ملفات SQL بالترتيب
1. `supabase/schema.sql`
2. `supabase/seed.sql`
3. `supabase/rls.sql`

## 3) تشغيل التطبيق بمفاتيح البيئة
لا تضع المفاتيح مباشرة داخل الكود.

مثال:

```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

إذا لم تُمرر القيم، سيعمل التطبيق تلقائيًا بالبيانات المحلية التجريبية.

## 4) استيراد دفعة شعرية مراجعة
على جهاز إداري موثوق:

```bash
export SUPABASE_URL="https://YOUR_PROJECT.supabase.co"
export SUPABASE_SERVICE_ROLE_KEY="YOUR_SERVICE_ROLE_KEY"
python scripts/import_poetry.py data/poetry_seed.json
```

مهم:
- مفتاح service role لا يوضع في تطبيق الهاتف.
- يستخدم فقط في بيئة إدارية/خلفية موثوقة.


## استيراد Dataset v1 القابل للتتبع

```bash
export SUPABASE_URL="https://YOUR_PROJECT.supabase.co"
export SUPABASE_SERVICE_ROLE_KEY="YOUR_SERVICE_ROLE_KEY"
python scripts/import_poetry.py data/poetry_seed_traceable_v1.json
```

بعد الاستيراد افتح من التطبيق:
**المكتبة الموثقة** → ستظهر البيانات مباشرة من Supabase.
