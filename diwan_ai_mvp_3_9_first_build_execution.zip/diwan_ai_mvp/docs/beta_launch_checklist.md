# Diwan AI — Beta Launch Checklist

## Database
- [ ] Project connected.
- [ ] All SQL migrations applied.
- [ ] RLS enabled.
- [ ] Grants reviewed.
- [ ] Public read tables tested as anon.
- [ ] User-owned data tested with two separate accounts.
- [ ] Editorial write attempts from client rejected.

## Content
- [ ] At least 20 poets.
- [ ] At least 100 poems.
- [ ] Every published poem has source metadata.
- [ ] `review_required` label is visible where required.
- [ ] No `disputed` verse is promoted as authoritative.
- [ ] "بيت اليوم" has a 30-day editorial queue.

## AI
- [ ] Embeddings generated.
- [ ] `ask-diwan` deployed.
- [ ] No OpenAI key in Flutter.
- [ ] Unsupported questions return insufficient evidence.
- [ ] Attribution correction test passes.
- [ ] Evidence and verification status are shown.

## Mobile
- [ ] flutter pub get.
- [ ] flutter analyze.
- [ ] unit/widget tests.
- [ ] Android build.
- [ ] iOS build.
- [ ] share sheet tested.
- [ ] deep links tested.
- [ ] auth redirect/deep link interactions tested.
- [ ] RTL layout checked on common screen sizes.

## Product
- [ ] Privacy policy.
- [ ] Terms of use.
- [ ] Support email/contact.
- [ ] App icon.
- [ ] Splash screen.
- [ ] Store screenshots.
- [ ] Beta feedback channel.
