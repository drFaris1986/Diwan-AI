import 'package:flutter/material.dart';

import '../data/mock_data.dart';
import '../widgets/section_title.dart';
import 'ai_screen.dart';
import 'eras_screen.dart';
import 'poem_detail_screen.dart';
import 'poets_screen.dart';
import 'search_screen.dart';
import 'verify_verse_screen.dart';
import 'data_status_screen.dart';
import 'cloud_library_screen.dart';
import 'rag_ai_screen.dart';
import 'account_screen.dart';
import 'my_library_screen.dart';
import 'editorial_status_screen.dart';
import 'daily_verse_screen.dart';
import 'editorial_dashboard_screen.dart';
import 'beta_readiness_screen.dart';
import 'beta_feedback_screen.dart';
import 'beta_about_screen.dart';
import 'content_expansion_screen.dart';
import 'muallaqat_progress_screen.dart';
import 'unified_search_screen.dart';
import 'smart_home_screen.dart';
import 'analytics_dashboard_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;

  final pages = const [
    _HomeContent(),
    SearchScreen(),
    AiScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.search),
            label: 'البحث',
          ),
          NavigationDestination(
            icon: Icon(Icons.auto_awesome_outlined),
            selectedIcon: Icon(Icons.auto_awesome),
            label: 'اسأل ديوان',
          ),
        ],
      ),
    );
  }
}

class _HomeContent extends StatelessWidget {
  const _HomeContent();

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF0D2240);
    const gold = Color(0xFFC99A3D);

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 210,
          backgroundColor: navy,
          actions: [
            IconButton(
              tooltip: 'الإعدادات',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SettingsScreen(),
                ),
              ),
              icon: const Icon(Icons.settings_outlined),
            ),
          ],
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              padding: const EdgeInsets.fromLTRB(20, 70, 20, 20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0D2240), Color(0xFF183B67)],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      CircleAvatar(
                        radius: 23,
                        backgroundColor: gold,
                        child: Icon(Icons.menu_book_rounded, color: navy),
                      ),
                      SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'ديوان AI',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            'الذكاء الاصطناعي للشعر العربي',
                            style: TextStyle(
                              color: Color(0xFFD7E2EF),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    'من الجاهلي إلى المعاصر',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'اكتشف، اقرأ، حلّل، واسأل عن الشعر العربي.',
                    style: TextStyle(color: Color(0xFFE8EEF5)),
                  ),
                ],
              ),
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SearchScreen()),
                  );
                },
                child: const IgnorePointer(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'ابحث عن شاعر، قصيدة، بيت أو موضوع...',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const SectionTitle(title: 'استكشف'),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.insights_outlined),
                  title: const Text(
                    'مؤشرات الاستخدام — Beta',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text(
                    'القراءة، البحث، الحفظ والمشاركة خلال آخر 30 يومًا.',
                  ),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AnalyticsDashboardScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.home_outlined),
                  title: const Text(
                    'الرئيسية الذكية',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text(
                    'أكمل القراءة، الأكثر قراءة، ومختارات مخصصة لك.',
                  ),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const SmartHomeScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.manage_search),
                  title: const Text(
                    'محرك البحث الشعري',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text(
                    'ابحث في الشعراء والقصائد والأبيات مع فلاتر متقدمة.',
                  ),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const UnifiedSearchScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.stacked_bar_chart_outlined),
                  title: const Text(
                    'إنجاز توثيق المعلقات',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('35 بيتًا في الدفعة الأولى مع حالة التوثيق.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const MuallaqatProgressScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.auto_stories_outlined),
                  title: const Text(
                    'النواة الكلاسيكية — 20 شاعرًا',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('خطة المحتوى الأولى نحو 100 قصيدة مراجعة.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ContentExpansionScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: _FeatureCard(
                      title: 'العصور',
                      subtitle: '10 عصور شعرية',
                      icon: Icons.account_balance_outlined,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ErasScreen()),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _FeatureCard(
                      title: 'الشعراء',
                      subtitle: 'استكشف الشعراء',
                      icon: Icons.person_search_outlined,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const PoetsScreen()),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              SectionTitle(
                title: 'قصيدة مختارة',
                action: 'عرض',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PoemDetailScreen(poem: poems.first),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PoemDetailScreen(poem: poems.first),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          poems.first.title,
                          style: const TextStyle(
                            color: navy,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text('${poems.first.poet} • ${poems.first.era}'),
                        const Divider(height: 28),
                        Text(
                          poems.first.verses.first,
                          style: const TextStyle(
                            fontSize: 19,
                            height: 1.8,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFF3E8D1),
                    child: Icon(Icons.wb_sunny_outlined, color: navy),
                  ),
                  title: const Text(
                    'بيت اليوم',
                    style: TextStyle(fontWeight: FontWeight.w800, color: navy),
                  ),
                  subtitle: const Text('اختيار يومي من المكتبة مع الشاعر والمصدر.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const DailyVerseScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFF3E8D1),
                    child: Icon(Icons.psychology_alt_outlined, color: navy),
                  ),
                  title: const Text(
                    'اسأل ديوان — RAG',
                    style: TextStyle(fontWeight: FontWeight.w800, color: navy),
                  ),
                  subtitle: const Text('بحث دلالي ثم إجابة مقيدة بالأدلة والمصادر.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const RagAiScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const SectionTitle(title: 'التحقق من الأبيات'),
              const SizedBox(height: 8),
              Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFF3E8D1),
                    child: Icon(Icons.fact_check_outlined, color: navy),
                  ),
                  title: const Text(
                    'هل هذا البيت صحيح؟',
                    style: TextStyle(fontWeight: FontWeight.w800, color: navy),
                  ),
                  subtitle: const Text('تحقق من النص والنسبة والمصدر.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const VerifyVerseScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const SectionTitle(title: 'اسأل ديوان'),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    children: [
                      const Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: navy,
                            child: Icon(Icons.auto_awesome, color: gold),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'اسأل عن بيت، شاعر، معنى، بحر أو عصر.',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                color: navy,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const AiScreen()),
                          ),
                          icon: const Icon(Icons.chat_bubble_outline),
                          label: const Text('ابدأ المحادثة'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: Card(
                      child: ListTile(
                        leading: const Icon(Icons.person_outline),
                        title: const Text(
                          'حسابي',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AccountScreen(),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Card(
                      child: ListTile(
                        leading: const Icon(Icons.bookmarks_outlined),
                        title: const Text(
                          'مكتبتي',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const MyLibraryScreen(),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Card(
                      child: ListTile(
                        leading: const Icon(Icons.feedback_outlined),
                        title: const Text(
                          'ملاحظات Beta',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const BetaFeedbackScreen(),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Card(
                      child: ListTile(
                        leading: const Icon(Icons.info_outline),
                        title: const Text(
                          'حول Beta',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const BetaAboutScreen(),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.rocket_launch_outlined),
                  title: const Text(
                    'جاهزية النسخة التجريبية',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('فحص الاتصال، البيانات، بيت اليوم وRAG.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const BetaReadinessScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.dashboard_customize_outlined),
                  title: const Text(
                    'لوحة التحرير',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('جاهزية المصادر والمراجعات قبل الاعتماد.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const EditorialDashboardScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.fact_check_outlined),
                  title: const Text(
                    'حالة التوثيق التحريري',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('المصادر، اختلاف الروايات، ومراجعات الاعتماد.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const EditorialStatusScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.library_books_outlined),
                  title: const Text(
                    'المكتبة الموثقة',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('عرض الشعراء والقصائد والمصادر من Supabase.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const CloudLibraryScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.cloud_done_outlined),
                  title: const Text(
                    'حالة قاعدة البيانات',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('تحقق من الاتصال وعدادات المحتوى.'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const DataStatusScreen(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ]),
          ),
        ),
      ],
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 30, color: const Color(0xFFC99A3D)),
              const SizedBox(height: 20),
              Text(
                title,
                style: const TextStyle(
                  color: Color(0xFF0D2240),
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                ),
              ),
              Text(subtitle, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
