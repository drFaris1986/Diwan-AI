import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ContentExpansionScreen extends StatefulWidget {
  const ContentExpansionScreen({super.key});

  @override
  State<ContentExpansionScreen> createState() => _ContentExpansionScreenState();
}

class _ContentExpansionScreenState extends State<ContentExpansionScreen> {
  bool loading = true;
  List<Map<String, dynamic>> poets = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final raw = await rootBundle.loadString('data/classical_core_20_poets.json');
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    if (!mounted) return;
    setState(() {
      poets = List<Map<String, dynamic>>.from(decoded['poets'] as List);
      loading = false;
    });
  }

  String statusLabel(String status) {
    switch (status) {
      case 'strong_candidate':
        return 'مصدر قوي مرشح';
      case 'multiple_candidates':
        return 'عدة مصادر مرشحة';
      case 'muallaqat_candidate':
        return 'مرجع المعلقات متوفر';
      default:
        return 'يحتاج مصدرًا إضافيًا';
    }
  }

  @override
  Widget build(BuildContext context) {
    final eras = <String>{for (final p in poets) p['era'].toString()}.length;

    return Scaffold(
      appBar: AppBar(title: const Text('توسعة المحتوى')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Row(
                      children: [
                        Expanded(
                          child: _Metric(
                            value: '${poets.length}',
                            label: 'شاعرًا',
                          ),
                        ),
                        Expanded(
                          child: _Metric(
                            value: '$eras',
                            label: 'عصور',
                          ),
                        ),
                        const Expanded(
                          child: _Metric(
                            value: '100',
                            label: 'هدف قصائد',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'النواة الكلاسيكية',
                  style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF0D2240),
                  ),
                ),
                const SizedBox(height: 8),
                ...poets.map(
                  (p) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.person_outline),
                      title: Text(p['name']?.toString() ?? ''),
                      subtitle: Text(
                        '${p['era'] ?? ''}\n${p['representative_work'] ?? ''}',
                      ),
                      isThreeLine: true,
                      trailing: SizedBox(
                        width: 92,
                        child: Text(
                          statusLabel(p['source_status']?.toString() ?? ''),
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 10),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String value;
  final String label;

  const _Metric({
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.w900,
            color: Color(0xFF0D2240),
          ),
        ),
        Text(label),
      ],
    );
  }
}
