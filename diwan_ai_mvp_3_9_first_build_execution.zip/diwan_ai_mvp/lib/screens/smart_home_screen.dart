import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../services/smart_home_service.dart';
import 'cloud_poem_detail_screen.dart';
import 'unified_search_screen.dart';

class SmartHomeScreen extends StatefulWidget {
  const SmartHomeScreen({super.key});

  @override
  State<SmartHomeScreen> createState() => _SmartHomeScreenState();
}

class _SmartHomeScreenState extends State<SmartHomeScreen> {
  final service = SmartHomeService();

  bool loading = true;
  List<Map<String, dynamic>> popular = const [];
  List<Map<String, dynamic>> continueReading = const [];
  List<Map<String, dynamic>> suggestions = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    final data = await Future.wait([
      service.popularPoems(),
      service.continueReading(),
      service.personalizedSuggestions(),
    ]);

    if (!mounted) return;
    setState(() {
      popular = data[0];
      continueReading = data[1];
      suggestions = data[2];
      loading = false;
    });
  }

  void openPoem(Map<String, dynamic> row) {
    final id = row['poem_id']?.toString() ?? row['id']?.toString();
    final title = row['title_ar']?.toString() ?? '';
    if (id == null || id.isEmpty) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CloudPoemDetailScreen(
          poemId: id,
          title: title,
        ),
      ),
    );
  }

  String poetName(Map<String, dynamic> row) {
    if (row['poet_name'] != null) return row['poet_name'].toString();
    final poet = row['poets'];
    if (poet is Map && poet['name_ar'] != null) {
      return poet['name_ar'].toString();
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    if (!AppConfig.hasSupabase) {
      return Scaffold(
        appBar: AppBar(title: const Text('الرئيسية الذكية')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'الرئيسية الذكية تحتاج ربط Supabase وتشغيل migration 2.7.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('ديوان AI'),
        actions: [
          IconButton(
            tooltip: 'البحث',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const UnifiedSearchScreen(),
              ),
            ),
            icon: const Icon(Icons.search),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
                children: [
                  const _HeroSearchCard(),
                  if (continueReading.isNotEmpty) ...[
                    const SizedBox(height: 22),
                    const _SectionTitle(
                      title: 'أكمل القراءة',
                      subtitle: 'تابع من المكان الذي توقفت عنده.',
                    ),
                    const SizedBox(height: 8),
                    ...continueReading.map(
                      (row) => _ContinueCard(
                        row: row,
                        onTap: () => openPoem(row),
                      ),
                    ),
                  ],
                  const SizedBox(height: 22),
                  const _SectionTitle(
                    title: 'الأكثر قراءة',
                    subtitle: 'قصائد يتفاعل معها القراء خلال آخر 30 يومًا.',
                  ),
                  const SizedBox(height: 8),
                  if (popular.isEmpty)
                    const _EmptyCard(text: 'لا توجد بيانات قراءة كافية بعد.')
                  else
                    ...popular.map(
                      (row) => _PoemTile(
                        row: row,
                        poetName: poetName(row),
                        onTap: () => openPoem(row),
                      ),
                    ),
                  const SizedBox(height: 22),
                  const _SectionTitle(
                    title: 'مختارة لك',
                    subtitle:
                        'اقتراحات أولية بناءً على مفضلاتك والعصور والشعراء الذين تقرأهم.',
                  ),
                  const SizedBox(height: 8),
                  if (suggestions.isEmpty)
                    const _EmptyCard(
                      text: 'أضف قصائد إلى المفضلة لنخصص الاقتراحات لك.',
                    )
                  else
                    ...suggestions.map(
                      (row) => _PoemTile(
                        row: row,
                        poetName: poetName(row),
                        onTap: () => openPoem(row),
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}

class _HeroSearchCard extends StatelessWidget {
  const _HeroSearchCard();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const UnifiedSearchScreen(),
          ),
        ),
        child: const Padding(
          padding: EdgeInsets.all(20),
          child: Row(
            children: [
              Icon(
                Icons.auto_awesome,
                size: 34,
                color: Color(0xFFC99A3D),
              ),
              SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ماذا تريد أن تجد اليوم؟',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF0D2240),
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'ابحث عن شاعر، قصيدة، بيت أو عبارة شعرية.',
                      style: TextStyle(height: 1.5),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_left),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionTitle({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 21,
            fontWeight: FontWeight.w900,
            color: Color(0xFF0D2240),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          style: const TextStyle(fontSize: 12, height: 1.5),
        ),
      ],
    );
  }
}

class _PoemTile extends StatelessWidget {
  final Map<String, dynamic> row;
  final String poetName;
  final VoidCallback onTap;

  const _PoemTile({
    required this.row,
    required this.poetName,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: onTap,
        leading: const CircleAvatar(
          child: Icon(Icons.menu_book_outlined),
        ),
        title: Text(
          row['title_ar']?.toString() ?? '',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(poetName),
        trailing: const Icon(Icons.chevron_left),
      ),
    );
  }
}

class _ContinueCard extends StatelessWidget {
  final Map<String, dynamic> row;
  final VoidCallback onTap;

  const _ContinueCard({
    required this.row,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final progress =
        ((row['progress_percent'] as num?)?.toDouble() ?? 0).clamp(0, 100);

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                row['title_ar']?.toString() ?? '',
                style: const TextStyle(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 4),
              Text(row['poet_name']?.toString() ?? ''),
              const SizedBox(height: 10),
              LinearProgressIndicator(value: progress / 100),
              const SizedBox(height: 6),
              Text(
                '${progress.toStringAsFixed(0)}% • البيت ${row['last_verse_order'] ?? '-'}',
                style: const TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final String text;

  const _EmptyCard({required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Text(text),
      ),
    );
  }
}
