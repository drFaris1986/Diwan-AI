import 'dart:async';

import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../models/search_result_item.dart';
import '../services/unified_search_service.dart';
import '../services/analytics_service.dart';
import 'cloud_poem_detail_screen.dart';
import 'poet_profile_screen.dart';
import 'verse_evidence_screen.dart';

class UnifiedSearchScreen extends StatefulWidget {
  const UnifiedSearchScreen({super.key});

  @override
  State<UnifiedSearchScreen> createState() => _UnifiedSearchScreenState();
}

class _UnifiedSearchScreenState extends State<UnifiedSearchScreen> {
  final controller = TextEditingController();
  final service = UnifiedSearchService();

  Timer? debounce;
  bool loading = false;
  String? error;
  List<SearchResultItem> results = const [];
  List<Map<String, dynamic>> eras = const [];
  List<Map<String, dynamic>> poets = const [];
  List<String> meters = const [];
  List<String> rhymes = const [];

  String? eraId;
  String? poetId;
  String? meter;
  String? rhyme;

  @override
  void initState() {
    super.initState();
    loadFilters();
    controller.addListener(onQueryChanged);
  }

  Future<void> loadFilters() async {
    if (!AppConfig.hasSupabase) return;
    try {
      final loaded = await Future.wait([
        service.eras(),
        service.poets(),
        service.distinctPoemField('meter_ar'),
        service.distinctPoemField('rhyme_ar'),
      ]);
      if (!mounted) return;
      setState(() {
        eras = loaded[0] as List<Map<String, dynamic>>;
        poets = loaded[1] as List<Map<String, dynamic>>;
        meters = loaded[2] as List<String>;
        rhymes = loaded[3] as List<String>;
      });
    } catch (_) {}
  }

  void onQueryChanged() {
    debounce?.cancel();
    debounce = Timer(const Duration(milliseconds: 350), runSearch);
  }

  Future<void> runSearch() async {
    final q = controller.text.trim();
    if (q.isEmpty) {
      setState(() => results = const []);
      return;
    }

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final rows = await service.search(
        q,
        filters: SearchFilters(
          eraId: eraId,
          poetId: poetId,
          meter: meter,
          rhyme: rhyme,
        ),
      );
      AnalyticsService.instance.search(
        queryLength: q.length,
        hasFilters: eraId != null ||
            poetId != null ||
            meter != null ||
            rhyme != null,
        resultCount: rows.length,
      );
      if (!mounted) return;
      setState(() {
        results = rows;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = e.toString();
      });
    }
  }

  void clearFilters() {
    setState(() {
      eraId = null;
      poetId = null;
      meter = null;
      rhyme = null;
    });
    runSearch();
  }

  Future<void> showFilters() async {
    String? tempEra = eraId;
    String? tempPoet = poetId;
    String? tempMeter = meter;
    String? tempRhyme = rhyme;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, modalSetState) {
          final filteredPoets = tempEra == null
              ? poets
              : poets.where((p) => p['era_id']?.toString() == tempEra).toList();

          return SafeArea(
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                16,
                16,
                16,
                16 + MediaQuery.of(context).viewInsets.bottom,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'تصفية البحث',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<String>(
                      value: tempEra,
                      decoration: const InputDecoration(labelText: 'العصر'),
                      items: eras
                          .map(
                            (e) => DropdownMenuItem(
                              value: e['id'].toString(),
                              child: Text(e['name_ar']?.toString() ?? ''),
                            ),
                          )
                          .toList(),
                      onChanged: (value) => modalSetState(() {
                        tempEra = value;
                        if (tempPoet != null &&
                            !filteredPoets.any(
                              (p) => p['id'].toString() == tempPoet,
                            )) {
                          tempPoet = null;
                        }
                      }),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: tempPoet,
                      decoration: const InputDecoration(labelText: 'الشاعر'),
                      items: filteredPoets
                          .map(
                            (p) => DropdownMenuItem(
                              value: p['id'].toString(),
                              child: Text(p['name_ar']?.toString() ?? ''),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          modalSetState(() => tempPoet = value),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: tempMeter,
                      decoration: const InputDecoration(labelText: 'البحر'),
                      items: meters
                          .map(
                            (m) => DropdownMenuItem(
                              value: m,
                              child: Text(m),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          modalSetState(() => tempMeter = value),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: tempRhyme,
                      decoration: const InputDecoration(labelText: 'القافية'),
                      items: rhymes
                          .map(
                            (r) => DropdownMenuItem(
                              value: r,
                              child: Text(r),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          modalSetState(() => tempRhyme = value),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              modalSetState(() {
                                tempEra = null;
                                tempPoet = null;
                                tempMeter = null;
                                tempRhyme = null;
                              });
                            },
                            child: const Text('مسح'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton(
                            onPressed: () {
                              setState(() {
                                eraId = tempEra;
                                poetId = tempPoet;
                                meter = tempMeter;
                                rhyme = tempRhyme;
                              });
                              Navigator.pop(context);
                              runSearch();
                            },
                            child: const Text('تطبيق'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void openResult(SearchResultItem item) {
    if (item.type == 'poet' && item.poetId != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PoetProfileScreen(
            poetId: item.poetId!,
            poetName: item.title,
          ),
        ),
      );
      return;
    }

    if (item.type == 'poem' && item.poemId != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CloudPoemDetailScreen(
            poemId: item.poemId!,
            title: item.title,
          ),
        ),
      );
      return;
    }

    if (item.type == 'verse') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => VerseEvidenceScreen(
            verseId: item.id,
            verseText: item.matchedText,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    debounce?.cancel();
    controller.removeListener(onQueryChanged);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasFilters =
        eraId != null || poetId != null || meter != null || rhyme != null;

    return Scaffold(
      appBar: AppBar(title: const Text('البحث الشامل')),
      body: !AppConfig.hasSupabase
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'البحث الشامل يحتاج ربط Supabase وتشغيل migration 2.6.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: controller,
                          textInputAction: TextInputAction.search,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.search),
                            hintText:
                                'بيت، شاعر، قصيدة، كلمة أو عبارة...',
                          ),
                          onSubmitted: (_) => runSearch(),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filledTonal(
                        tooltip: 'الفلاتر',
                        onPressed: showFilters,
                        icon: Badge(
                          isLabelVisible: hasFilters,
                          child: const Icon(Icons.tune),
                        ),
                      ),
                    ],
                  ),
                ),
                if (hasFilters)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        onPressed: clearFilters,
                        icon: const Icon(Icons.close),
                        label: const Text('مسح الفلاتر'),
                      ),
                    ),
                  ),
                if (loading) const LinearProgressIndicator(),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(error!),
                  ),
                Expanded(
                  child: controller.text.trim().isEmpty
                      ? const _SearchIntro()
                      : results.isEmpty && !loading
                          ? const Center(
                              child: Text('لم أجد نتائج مطابقة.'),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.all(16),
                              itemCount: results.length,
                              itemBuilder: (context, index) {
                                final item = results[index];
                                return _ResultCard(
                                  item: item,
                                  onTap: () => openResult(item),
                                );
                              },
                            ),
                ),
              ],
            ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final SearchResultItem item;
  final VoidCallback onTap;

  const _ResultCard({
    required this.item,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final icon = switch (item.type) {
      'verse' => Icons.format_quote,
      'poem' => Icons.menu_book_outlined,
      _ => Icons.person_outline,
    };

    final label = switch (item.type) {
      'verse' => 'بيت',
      'poem' => 'قصيدة',
      _ => 'شاعر',
    };

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: const Color(0xFFC99A3D)),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const Spacer(),
                  if (item.verificationStatus != null)
                    Text(
                      item.verificationStatus!,
                      style: const TextStyle(fontSize: 10),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              if (item.type == 'verse')
                Text(
                  item.matchedText,
                  style: const TextStyle(
                    fontSize: 19,
                    height: 1.7,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF0D2240),
                  ),
                )
              else
                Text(
                  item.title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              const SizedBox(height: 6),
              Text(item.subtitle),
              if (item.meter != null || item.rhyme != null) ...[
                const SizedBox(height: 6),
                Text(
                  [
                    if (item.meter != null) 'البحر: ${item.meter}',
                    if (item.rhyme != null) 'القافية: ${item.rhyme}',
                  ].join(' • '),
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _SearchIntro extends StatelessWidget {
  const _SearchIntro();

  @override
  Widget build(BuildContext context) {
    return const ListView(
      padding: EdgeInsets.all(24),
      children: [
        Icon(
          Icons.manage_search,
          size: 58,
          color: Color(0xFFC99A3D),
        ),
        SizedBox(height: 14),
        Text(
          'محرك البحث الشعري',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 23,
            fontWeight: FontWeight.w900,
            color: Color(0xFF0D2240),
          ),
        ),
        SizedBox(height: 8),
        Text(
          'ابحث باسم الشاعر، عنوان القصيدة، بيت كامل أو جزء منه، '
          'ثم صفِّ النتائج حسب العصر والشاعر والبحر والقافية.',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.7),
        ),
      ],
    );
  }
}
