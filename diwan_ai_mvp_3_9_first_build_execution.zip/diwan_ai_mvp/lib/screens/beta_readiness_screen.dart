import 'package:flutter/material.dart';

import '../services/beta_health_service.dart';

class BetaReadinessScreen extends StatefulWidget {
  const BetaReadinessScreen({super.key});

  @override
  State<BetaReadinessScreen> createState() => _BetaReadinessScreenState();
}

class _BetaReadinessScreenState extends State<BetaReadinessScreen> {
  bool loading = true;
  List<BetaHealthResult> results = const [];

  @override
  void initState() {
    super.initState();
    run();
  }

  Future<void> run() async {
    setState(() => loading = true);
    final next = await BetaHealthService().run();
    if (!mounted) return;
    setState(() {
      results = next;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final passed = results.where((r) => r.ok).length;
    final total = results.length;

    return Scaffold(
      appBar: AppBar(title: const Text('جاهزية النسخة التجريبية')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        Text(
                          total == 0 ? '0/0' : '$passed/$total',
                          style: const TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF0D2240),
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'اختبارات جاهزية تم اجتيازها',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'هذه شاشة فحص تشغيلية وليست شهادة أمان أو اختبارًا كاملاً على متجر التطبيقات.',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, height: 1.5),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                ...results.map(
                  (r) => Card(
                    child: ListTile(
                      leading: Icon(
                        r.ok ? Icons.check_circle_outline : Icons.error_outline,
                        color: r.ok ? Colors.green : Colors.red,
                      ),
                      title: Text(r.name),
                      subtitle: Text(r.detail),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: run,
                  icon: const Icon(Icons.refresh),
                  label: const Text('إعادة الفحص'),
                ),
              ],
            ),
    );
  }
}
