import 'package:flutter/material.dart';

import '../services/local_preferences_service.dart';
import 'account_screen.dart';
import 'account_deletion_screen.dart';
import 'release_readiness_screen.dart';
import 'beta_about_screen.dart';
import 'legal_document_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final prefs = LocalPreferencesService();
  bool loading = true;
  bool compactReading = false;
  bool showReviewLabels = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final values = await Future.wait([
      prefs.compactReadingMode(),
      prefs.showReviewLabels(),
    ]);
    if (!mounted) return;
    setState(() {
      compactReading = values[0];
      showReviewLabels = values[1];
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const _Header('الحساب'),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.person_outline),
                    title: const Text('الحساب وتسجيل الدخول'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AccountScreen(),
                      ),
                    ),
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.delete_outline),
                    title: const Text('طلب حذف الحساب'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AccountDeletionScreen(),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const _Header('القراءة'),
                Card(
                  child: Column(
                    children: [
                      SwitchListTile(
                        value: compactReading,
                        title: const Text('وضع قراءة مضغوط'),
                        subtitle: const Text(
                          'تفضيل محلي تمهيدًا لربطه الكامل بشاشة القراءة.',
                        ),
                        onChanged: (value) async {
                          setState(() => compactReading = value);
                          await prefs.setCompactReadingMode(value);
                        },
                      ),
                      const Divider(height: 1),
                      SwitchListTile(
                        value: showReviewLabels,
                        title: const Text('إظهار حالة التوثيق'),
                        subtitle: const Text(
                          'إظهار review_required وdisputed عند توفرها.',
                        ),
                        onChanged: (value) async {
                          setState(() => showReviewLabels = value);
                          await prefs.setShowReviewLabels(value);
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                const _Header('الخصوصية والقانون'),
                Card(
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.privacy_tip_outlined),
                        title: const Text('سياسة الخصوصية'),
                        trailing: const Icon(Icons.chevron_left),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const LegalDocumentScreen(
                              title: 'سياسة الخصوصية',
                              sections: privacySections,
                            ),
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.gavel_outlined),
                        title: const Text('شروط الاستخدام'),
                        trailing: const Icon(Icons.chevron_left),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const LegalDocumentScreen(
                              title: 'شروط الاستخدام',
                              sections: termsSections,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                const _Header('عن ديوان'),
                Card(
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.info_outline),
                        title: const Text('حول النسخة التجريبية'),
                        trailing: const Icon(Icons.chevron_left),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const BetaAboutScreen(),
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.fact_check_outlined),
                        title: const Text('جاهزية الإصدار'),
                        trailing: const Icon(Icons.chevron_left),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const ReleaseReadinessScreen(),
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.restart_alt),
                        title: const Text('إعادة عرض المقدمة'),
                        onTap: () async {
                          await prefs.resetOnboarding();
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'ستظهر المقدمة عند تشغيل التطبيق القادم.',
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                const Center(
                  child: Text(
                    'Diwan AI 0.3.0-beta.1',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
    );
  }
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(right: 4, bottom: 6),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w900,
            color: Color(0xFF0D2240),
          ),
        ),
      );
}
