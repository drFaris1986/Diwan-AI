import 'package:flutter/material.dart';

import '../services/arabic_normalizer.dart';
import '../services/poem_reading_service.dart';
import 'verse_evidence_screen.dart';
import 'verse_variants_screen.dart';

class PoemReadingScreen extends StatefulWidget {
  final String poemId;
  final String title;
  final String poetName;

  const PoemReadingScreen({
    super.key,
    required this.poemId,
    required this.title,
    required this.poetName,
  });

  @override
  State<PoemReadingScreen> createState() => _PoemReadingScreenState();
}

class _PoemReadingScreenState extends State<PoemReadingScreen> {
  final search = TextEditingController();
  final jump = TextEditingController();
  final scroll = ScrollController();
  final service = PoemReadingService();

  bool loading = true;
  List<PoemReadingVerse> all = const [];
  List<PoemReadingVerse> visible = const [];
  double fontSize = 24;

  @override
  void initState() {
    super.initState();
    load();
    search.addListener(applySearch);
  }

  Future<void> load() async {
    final rows = await service.load(widget.poemId);
    if (!mounted) return;
    setState(() {
      all = rows;
      visible = rows;
      loading = false;
    });
  }

  void applySearch() {
    final q = ArabicNormalizer.normalize(search.text.trim());
    if (q.isEmpty) {
      setState(() => visible = all);
      return;
    }

    setState(() {
      visible = all.where((verse) {
        return ArabicNormalizer.normalize(verse.fullText).contains(q);
      }).toList();
    });
  }

  void jumpToVerse() {
    final n = int.tryParse(jump.text.trim());
    if (n == null || n < 1 || n > all.length) return;

    search.clear();
    setState(() => visible = all);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      const estimatedCardHeight = 190.0;
      final target = ((n - 1) * estimatedCardHeight).clamp(
        0.0,
        scroll.position.maxScrollExtent,
      );
      scroll.animateTo(
        target,
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    search.removeListener(applySearch);
    search.dispose();
    jump.dispose();
    scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            tooltip: 'تصغير الخط',
            onPressed: fontSize <= 18
                ? null
                : () => setState(() => fontSize -= 2),
            icon: const Icon(Icons.text_decrease),
          ),
          IconButton(
            tooltip: 'تكبير الخط',
            onPressed: fontSize >= 34
                ? null
                : () => setState(() => fontSize += 2),
            icon: const Icon(Icons.text_increase),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: Column(
                    children: [
                      TextField(
                        controller: search,
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText: 'ابحث داخل القصيدة...',
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: jump,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                hintText: 'رقم البيت',
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          FilledButton(
                            onPressed: jumpToVerse,
                            child: const Text('انتقل'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: visible.isEmpty
                      ? const Center(
                          child: Text('لا توجد أبيات مطابقة للبحث.'),
                        )
                      : ListView.builder(
                          controller: scroll,
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                          itemCount: visible.length,
                          itemBuilder: (context, index) {
                            final verse = visible[index];

                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: Padding(
                                padding: const EdgeInsets.all(18),
                                child: Column(
                                  children: [
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Text(
                                        'البيت ${verse.order}',
                                        style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w800,
                                          color: Color(0xFFC99A3D),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      verse.first,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: fontSize,
                                        height: 1.8,
                                        fontWeight: FontWeight.w700,
                                        color: const Color(0xFF0D2240),
                                      ),
                                    ),
                                    if (verse.second.isNotEmpty)
                                      Text(
                                        verse.second,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: fontSize,
                                          height: 1.8,
                                          fontWeight: FontWeight.w700,
                                          color: const Color(0xFF0D2240),
                                        ),
                                      ),
                                    const SizedBox(height: 10),
                                    Wrap(
                                      alignment: WrapAlignment.center,
                                      spacing: 8,
                                      runSpacing: 4,
                                      children: [
                                        OutlinedButton.icon(
                                          onPressed: () => Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  VerseEvidenceScreen(
                                                verseId: verse.id,
                                                verseText: verse.fullText,
                                              ),
                                            ),
                                          ),
                                          icon: const Icon(
                                            Icons.fact_check_outlined,
                                          ),
                                          label: Text(
                                            'الأدلة ${verse.evidenceCount}',
                                          ),
                                        ),
                                        OutlinedButton.icon(
                                          onPressed: () => Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  VerseVariantsScreen(
                                                verseId: verse.id,
                                                verseText: verse.fullText,
                                              ),
                                            ),
                                          ),
                                          icon: const Icon(
                                            Icons.compare_arrows_outlined,
                                          ),
                                          label: Text(
                                            'الروايات ${verse.variantCount}',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
