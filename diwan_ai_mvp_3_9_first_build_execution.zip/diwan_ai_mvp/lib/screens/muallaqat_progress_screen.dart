import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MuallaqatProgressScreen extends StatefulWidget {
  const MuallaqatProgressScreen({super.key});

  @override
  State<MuallaqatProgressScreen> createState() =>
      _MuallaqatProgressScreenState();
}

class _MuallaqatProgressScreenState extends State<MuallaqatProgressScreen> {
  bool loading = true;
  List<Map<String, dynamic>> poems = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final raw =
        await rootBundle.loadString('data/muallaqat_opening_35_verses.json');
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    if (!mounted) return;
    setState(() {
      poems = List<Map<String, dynamic>>.from(decoded['poems'] as List);
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final verseCount = poems.fold<int>(
      0,
      (sum, p) => sum + (p['verses'] as List).length,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('إنجاز توثيق المعلقات')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Row(
                      children: [
                        Expanded(child: _metric('7', 'معلقات')),
                        Expanded(child: _metric('$verseCount', 'بيتًا مدخلًا')),
                        Expanded(child: _metric('0', 'بيتًا page-verified')),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                      'تمت زيادة الدفعة الرقمية إلى أول 5 أبيات من كل معلقة. '
                      'التقدم في الصفحات سيبقى 0% حتى تتم مقابلة النسخة المصورة وتسجيل أرقام الصفحات فعليًا.',
                      style: TextStyle(height: 1.7),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                ...poems.map((p) {
                  final count = (p['verses'] as List).length;
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.menu_book_outlined),
                      ),
                      title: Text(p['title']?.toString() ?? ''),
                      subtitle: Text(
                        '${p['poet'] ?? ''}\n$count أبيات — مطابقة رقمية أولية',
                      ),
                      isThreeLine: true,
                      trailing: const Text(
                        'review\nrequired',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                  );
                }),
              ],
            ),
    );
  }

  Widget _metric(String value, String label) => Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.w900,
              color: Color(0xFF0D2240),
            ),
          ),
          Text(label, textAlign: TextAlign.center),
        ],
      );
}
