import 'package:flutter/material.dart';
import '../models/verse_result.dart';
import '../services/poetry_repository.dart';
import '../services/repository_provider.dart';

class VerifyVerseScreen extends StatefulWidget {
  const VerifyVerseScreen({super.key});

  @override
  State<VerifyVerseScreen> createState() => _VerifyVerseScreenState();
}

class _VerifyVerseScreenState extends State<VerifyVerseScreen> {
  final controller = TextEditingController();
  late final PoetryRepository repository;

  @override
  void initState() {
    super.initState();
    repository = RepositoryProvider.create();
  }

  bool loading = false;
  bool searched = false;
  List<VerseResult> results = const [];

  Future<void> verify() async {
    final text = controller.text.trim();
    if (text.isEmpty) return;

    setState(() {
      loading = true;
      searched = true;
    });

    final found = await repository.verifyVerse(text);

    if (!mounted) return;
    setState(() {
      results = found;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('هل هذا البيت صحيح؟')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'ألصق البيت أو جزءًا منه، وسيبحث ديوان عن التطابق والنسبة والمصدر.',
            style: TextStyle(height: 1.7),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: controller,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              hintText: 'مثال: على قدر أهل العزم تأتي العزائم',
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: loading ? null : verify,
            icon: const Icon(Icons.fact_check_outlined),
            label: Text(loading ? 'جاري التحقق...' : 'تحقق من البيت'),
          ),
          const SizedBox(height: 18),
          if (searched && !loading && results.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Text(
                  'لم أجد تطابقًا في بيانات النسخة الأولية. هذا لا يعني أن البيت غير صحيح؛ '
                  'يعني فقط أن قاعدة MVP الحالية محدودة.',
                  style: TextStyle(height: 1.7),
                ),
              ),
            ),
          ...results.map((r) => _VerificationCard(result: r)),
        ],
      ),
    );
  }
}

class _VerificationCard extends StatelessWidget {
  final VerseResult result;
  const _VerificationCard({required this.result});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.verified_outlined, color: Color(0xFFC99A3D)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'تطابق ${(result.relevance * 100).round()}%',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              result.text,
              style: const TextStyle(fontSize: 20, height: 1.8),
            ),
            const Divider(height: 26),
            Text('الشاعر: ${result.poet}'),
            Text('القصيدة: ${result.poemTitle}'),
            Text('العصر: ${result.era}'),
            Text('الحالة: ${result.verificationStatus}'),
            const SizedBox(height: 8),
            ...result.sources.map(
              (s) => Text(
                'المصدر: ${s.title} — موثوقية المصدر ${(s.reliabilityScore * 100).round()}%',
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
