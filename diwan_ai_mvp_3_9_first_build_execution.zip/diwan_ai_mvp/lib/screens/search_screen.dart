import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import 'poem_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final q = query.trim();
    final poemResults = poems.where((p) {
      return p.title.contains(q) ||
          p.poet.contains(q) ||
          p.era.contains(q) ||
          p.verses.any((v) => v.contains(q));
    }).toList();

    final poetResults = poets.where((p) {
      return p.name.contains(q) ||
          p.era.contains(q) ||
          p.themes.any((t) => t.contains(q));
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('البحث في ديوان')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            autofocus: true,
            onChanged: (value) => setState(() => query = value),
            decoration: const InputDecoration(
              hintText: 'مثال: المتنبي، الفخر، الجاهلي...',
              prefixIcon: Icon(Icons.search),
            ),
          ),
          const SizedBox(height: 18),
          if (q.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 70),
              child: Center(
                child: Text('ابدأ بكتابة اسم شاعر، قصيدة، بيت أو موضوع.'),
              ),
            )
          else ...[
            Text(
              'الشعراء (${poetResults.length})',
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 8),
            ...poetResults.map(
              (p) => Card(
                child: ListTile(
                  leading: const Icon(Icons.person_outline),
                  title: Text(p.name),
                  subtitle: Text('${p.era} • ${p.themes.join('، ')}'),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'القصائد (${poemResults.length})',
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 8),
            ...poemResults.map(
              (p) => Card(
                child: ListTile(
                  leading: const Icon(Icons.menu_book_outlined),
                  title: Text(p.title),
                  subtitle: Text('${p.poet} • ${p.era}'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PoemDetailScreen(poem: p),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
