import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:share_plus/share_plus.dart';

import '../services/analytics_service.dart';

class VerseShareCardScreen extends StatefulWidget {
  final String? poemId;
  final String? verseId;
  final String firstHemistich;
  final String secondHemistich;
  final String poetName;
  final String poemTitle;
  final String verificationStatus;

  const VerseShareCardScreen({
    super.key,
    this.poemId,
    this.verseId,
    required this.firstHemistich,
    required this.secondHemistich,
    required this.poetName,
    required this.poemTitle,
    required this.verificationStatus,
  });

  @override
  State<VerseShareCardScreen> createState() => _VerseShareCardScreenState();
}

class _VerseShareCardScreenState extends State<VerseShareCardScreen> {
  final GlobalKey _cardKey = GlobalKey();
  bool sharing = false;

  String get shareText {
    final second = widget.secondHemistich.trim().isEmpty
        ? ''
        : '\n${widget.secondHemistich}';
    return '${widget.firstHemistich}$second\n\n'
        '— ${widget.poetName}\n'
        '${widget.poemTitle}\n'
        'ديوان AI';
  }

  Future<void> shareAsText(BuildContext buttonContext) async {
    final box = buttonContext.findRenderObject() as RenderBox?;
    await SharePlus.instance.share(
      ShareParams(
        text: shareText,
        title: 'بيت من ديوان AI',
        sharePositionOrigin:
            box == null ? null : box.localToGlobal(Offset.zero) & box.size,
      ),
    );
    AnalyticsService.instance.verseShare(
      poemId: widget.poemId,
      verseId: widget.verseId,
      format: 'text',
    );
  }

  Future<void> shareAsImage(BuildContext buttonContext) async {
    if (sharing) return;
    setState(() => sharing = true);

    try {
      await WidgetsBinding.instance.endOfFrame;
      final boundary =
          _cardKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        throw StateError('تعذر التقاط البطاقة.');
      }

      final ui.Image image = await boundary.toImage(pixelRatio: 3);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) {
        throw StateError('تعذر إنشاء صورة البطاقة.');
      }

      final pngBytes = byteData.buffer.asUint8List();
      final box = buttonContext.findRenderObject() as RenderBox?;

      await SharePlus.instance.share(
        ShareParams(
          text: 'بيت من ديوان AI — ${widget.poetName}',
          files: [
            XFile.fromData(
              pngBytes,
              mimeType: 'image/png',
            ),
          ],
          fileNameOverrides: const ['diwan-ai-verse.png'],
          sharePositionOrigin:
              box == null ? null : box.localToGlobal(Offset.zero) & box.size,
        ),
      );
      AnalyticsService.instance.verseShare(
        poemId: widget.poemId,
        verseId: widget.verseId,
        format: 'image',
      );
    } finally {
      if (mounted) setState(() => sharing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final reviewRequired = widget.verificationStatus != 'verified';

    return Scaffold(
      appBar: AppBar(title: const Text('بطاقة شعرية')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          RepaintBoundary(
            key: _cardKey,
            child: AspectRatio(
              aspectRatio: 4 / 5,
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFF7F1E7),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(
                    color: const Color(0xFFC99A3D),
                    width: 1.4,
                  ),
                ),
                padding: const EdgeInsets.all(28),
                child: Column(
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.auto_stories_outlined,
                          color: Color(0xFFC99A3D),
                        ),
                        SizedBox(width: 8),
                        Text(
                          'ديوان AI',
                          style: TextStyle(
                            color: Color(0xFF0D2240),
                            fontWeight: FontWeight.w900,
                            fontSize: 20,
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      widget.firstHemistich,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF0D2240),
                        fontSize: 25,
                        height: 1.9,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (widget.secondHemistich.trim().isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        widget.secondHemistich,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFF0D2240),
                          fontSize: 25,
                          height: 1.9,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                    const Spacer(),
                    Container(
                      width: 54,
                      height: 1,
                      color: const Color(0xFFC99A3D),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      widget.poetName,
                      style: const TextStyle(
                        color: Color(0xFF0D2240),
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      widget.poemTitle,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF183B67),
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (reviewRequired)
                      const Text(
                        'النص في مرحلة المراجعة التحريرية',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 10,
                          color: Color(0xFF735C2C),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Builder(
            builder: (buttonContext) => FilledButton.icon(
              onPressed: sharing ? null : () => shareAsImage(buttonContext),
              icon: const Icon(Icons.image_outlined),
              label: Text(sharing ? 'جاري إنشاء البطاقة...' : 'مشاركة كصورة'),
            ),
          ),
          const SizedBox(height: 8),
          Builder(
            builder: (buttonContext) => OutlinedButton.icon(
              onPressed: () => shareAsText(buttonContext),
              icon: const Icon(Icons.share_outlined),
              label: const Text('مشاركة كنص'),
            ),
          ),
        ],
      ),
    );
  }
}
