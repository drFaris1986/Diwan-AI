import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class PoetProfileScreen extends StatefulWidget {
  final String poetId;
  final String poetName;

  const PoetProfileScreen({
    super.key,
    required this.poetId,
    required this.poetName,
  });

  @override
  State<PoetProfileScreen> createState() => _PoetProfileScreenState();
}

class _PoetProfileScreenState extends State<PoetProfileScreen> {
  bool loading = true;
  String? error;
  Map<String, dynamic>? poet;
  List<Map<String, dynamic>> poems = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final client = Supabase.instance.client;
      final poetRow = await client
          .from('poets')
          .select('id,name_ar,bio_ar,birth_label,death_label,country_or_region,eras(name_ar)')
          .eq('id', widget.poetId)
          .single();

      final poemRows = await client
          .from('poems')
          .select('id,title_ar,meter_ar,rhyme_ar,verification_status')
          .eq('poet_id', widget.poetId)
          .order('title_ar');

      if (!mounted) return;
      setState(() {
        poet = Map<String, dynamic>.from(poetRow);
        poems = List<Map<String, dynamic>>.from(poemRows as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  String value(String key, {String fallback = '—'}) {
    final v = poet?[key]?.toString().trim();
    return (v == null || v.isEmpty) ? fallback : v;
  }

  String nestedEra() {
    final era = poet?['eras'];
    if (era is Map<String, dynamic>) return era['name_ar']?.toString() ?? '—';
    return '—';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.poetName)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(error!),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          children: [
                            const CircleAvatar(
                              radius: 34,
                              backgroundColor: Color(0xFFF3E8D1),
                              child: Icon(
                                Icons.person_outline,
                                size: 34,
                                color: Color(0xFF0D2240),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              widget.poetName,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF0D2240),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              nestedEra(),
                              style: const TextStyle(
                                color: Color(0xFFC99A3D),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 14),
                            Text(
                              value('bio_ar', fallback: 'السيرة ستُستكمل ضمن التحرير الموسوعي.'),
                              style: const TextStyle(height: 1.7),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(child: _Info(label: 'الميلاد', value: value('birth_label'))),
                        const SizedBox(width: 8),
                        Expanded(child: _Info(label: 'الوفاة', value: value('death_label'))),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'القصائد (${poems.length})',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF0D2240),
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (poems.isEmpty)
                      const Text('لا توجد قصائد مرتبطة بهذا الشاعر بعد.'),
                    ...poems.map(
                      (p) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.menu_book_outlined),
                          title: Text(p['title_ar']?.toString() ?? ''),
                          subtitle: Text(
                            '${p['meter_ar'] ?? 'بحر غير محدد'} • ${p['verification_status'] ?? 'review_required'}',
                          ),
                          trailing: const Icon(Icons.chevron_left),
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}

class _Info extends StatelessWidget {
  final String label;
  final String value;

  const _Info({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Text(label, style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}
