import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/user_library_service.dart';
import '../services/analytics_service.dart';
import 'verse_share_card_screen.dart';
import 'verse_evidence_screen.dart';
import 'poem_reading_screen.dart';

class CloudPoemDetailScreen extends StatefulWidget {
  final String poemId;
  final String title;

  const CloudPoemDetailScreen({
    super.key,
    required this.poemId,
    required this.title,
  });

  @override
  State<CloudPoemDetailScreen> createState() => _CloudPoemDetailScreenState();
}

class _CloudPoemDetailScreenState extends State<CloudPoemDetailScreen> {
  bool loading = true;
  bool favorite = false;
  String? error;
  Map<String, dynamic>? poem;
  List<Map<String, dynamic>> verses = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final client = Supabase.instance.client;
      AnalyticsService.instance.poemOpen(widget.poemId);

      final poemRow = await client
          .from('poems')
          .select(
            'id,title_ar,meter_ar,rhyme_ar,occasion_ar,verification_status,'
            'poets(id,name_ar),eras(name_ar),'
            'poem_sources(page_reference,notes,sources(title,author_or_editor,publisher,edition,publication_year,url,reliability_score))',
          )
          .eq('id', widget.poemId)
          .single();

      final verseRows = await client
          .from('verses')
          .select(
            'id,verse_order,first_hemistich,second_hemistich,full_text,'
            'explanation_ar,vocabulary_ar,rhetoric_ar,'
            'verse_sources(page_reference,quote_variant,sources(title,url,reliability_score))',
          )
          .eq('poem_id', widget.poemId)
          .order('verse_order');

      if (client.auth.currentUser != null) {
        final fav = await client
            .from('favorite_poems')
            .select('poem_id')
            .eq('user_id', client.auth.currentUser!.id)
            .eq('poem_id', widget.poemId);
        favorite = (fav as List).isNotEmpty;
      }

      if (!mounted) return;
      setState(() {
        poem = Map<String, dynamic>.from(poemRow);
        verses = List<Map<String, dynamic>>.from(verseRows as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> toggleFavorite() async {
    final client = Supabase.instance.client;
    if (client.auth.currentUser == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('سجّل الدخول أولًا لإضافة القصيدة إلى المفضلة.')),
      );
      return;
    }

    final library = UserLibraryService(client);
    final adding = !favorite;
    if (favorite) {
      await library.unfavoritePoem(widget.poemId);
    } else {
      await library.favoritePoem(widget.poemId);
    }
    AnalyticsService.instance.favorite(
      poemId: widget.poemId,
      added: adding,
    );

    if (!mounted) return;
    setState(() => favorite = adding);
  }

  Future<void> saveVerse(String verseId) async {
    final client = Supabase.instance.client;
    if (client.auth.currentUser == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('سجّل الدخول أولًا لحفظ البيت.')),
      );
      return;
    }

    await UserLibraryService(client).saveVerse(verseId);
    AnalyticsService.instance.verseSave(
      poemId: widget.poemId,
      verseId: verseId,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حفظ البيت في مكتبتك.')),
    );
  }

  Map<String, dynamic> map(dynamic v) =>
      v is Map<String, dynamic> ? v : <String, dynamic>{};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            tooltip: 'المفضلة',
            onPressed: loading ? null : toggleFavorite,
            icon: Icon(favorite ? Icons.favorite : Icons.favorite_border),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(error!),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _Header(poem: poem!),
                    const SizedBox(height: 16),
                    ...verses.map(
                      (v) {
                        final poet = poem?['poets'] is Map
                            ? poem!['poets']['name_ar']?.toString() ?? ''
                            : '';
                        return _VerseCard(
                          verse: v,
                          onSave: () => saveVerse(v['id'].toString()),
                          onEvidence: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => VerseEvidenceScreen(
                                verseId: v['id'].toString(),
                                verseText:
                                    '${v['first_hemistich'] ?? ''} ${v['second_hemistich'] ?? ''}',
                              ),
                            ),
                          ),
                          onShare: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => VerseShareCardScreen(
                                poemId: widget.poemId,
                                verseId: v['id'].toString(),
                                firstHemistich:
                                    v['first_hemistich']?.toString() ?? '',
                                secondHemistich:
                                    v['second_hemistich']?.toString() ?? '',
                                poetName: poet,
                                poemTitle: poem?['title_ar']?.toString() ?? '',
                                verificationStatus:
                                    poem?['verification_status']?.toString() ??
                                        'review_required',
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 18),
                    _Sources(poem: poem!),
                  ],
                ),
    );
  }
}

class _Header extends StatelessWidget {
  final Map<String, dynamic> poem;
  const _Header({required this.poem});

  @override
  Widget build(BuildContext context) {
    final poet = poem['poets'] is Map ? poem['poets']['name_ar'] : '';
    final era = poem['eras'] is Map ? poem['eras']['name_ar'] : '';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Text(
              poem['title_ar'] ?? '',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: Color(0xFF0D2240),
              ),
            ),
            const SizedBox(height: 8),
            Text('$poet • $era'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                Chip(label: Text('البحر: ${poem['meter_ar'] ?? '—'}')),
                Chip(label: Text('القافية: ${poem['rhyme_ar'] ?? '—'}')),
                Chip(label: Text('التوثيق: ${poem['verification_status'] ?? 'review_required'}')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _VerseCard extends StatelessWidget {
  final Map<String, dynamic> verse;
  final VoidCallback onSave;
  final VoidCallback onShare;
  final VoidCallback onEvidence;

  const _VerseCard({
    required this.verse,
    required this.onSave,
    required this.onShare,
    required this.onEvidence,
  });

  @override
  Widget build(BuildContext context) {
    final explanation = verse['explanation_ar']?.toString().trim();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                '${verse['verse_order']}.',
                style: const TextStyle(
                  color: Color(0xFFC99A3D),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              verse['first_hemistich'] ?? '',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 21, height: 1.8),
            ),
            if ((verse['second_hemistich']?.toString() ?? '').isNotEmpty)
              Text(
                verse['second_hemistich'],
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 21, height: 1.8),
              ),
            if (explanation != null && explanation.isNotEmpty) ...[
              const Divider(height: 28),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  explanation,
                  style: const TextStyle(height: 1.7),
                ),
              ),
            ],
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: 'أدلة البيت',
                    onPressed: onEvidence,
                    icon: const Icon(Icons.fact_check_outlined),
                  ),
                  IconButton(
                    tooltip: 'مشاركة البيت',
                    onPressed: onShare,
                    icon: const Icon(Icons.ios_share_outlined),
                  ),
                  IconButton(
                    tooltip: 'حفظ البيت',
                    onPressed: onSave,
                    icon: const Icon(Icons.bookmark_add_outlined),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Sources extends StatelessWidget {
  final Map<String, dynamic> poem;
  const _Sources({required this.poem});

  @override
  Widget build(BuildContext context) {
    final links = (poem['poem_sources'] as List?) ?? const [];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'المصادر',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: Color(0xFF0D2240),
              ),
            ),
            const SizedBox(height: 10),
            if (links.isEmpty)
              const Text('لا توجد مصادر مرتبطة ظاهرة لهذه القصيدة.')
            else
              ...links.map((raw) {
                final link = raw is Map<String, dynamic> ? raw : <String, dynamic>{};
                final source = link['sources'] is Map<String, dynamic>
                    ? Map<String, dynamic>.from(link['sources'])
                    : <String, dynamic>{};

                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(
                    '${source['title'] ?? 'مصدر'}'
                    '${source['author_or_editor'] != null ? ' — ${source['author_or_editor']}' : ''}'
                    '${source['edition'] != null ? ' — ${source['edition']}' : ''}'
                    '${link['page_reference'] != null ? ' — ص/ ${link['page_reference']}' : ''}',
                    style: const TextStyle(height: 1.6),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
