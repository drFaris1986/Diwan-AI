import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class EditorialDashboardScreen extends StatefulWidget {
  const EditorialDashboardScreen({super.key});

  @override
  State<EditorialDashboardScreen> createState() =>
      _EditorialDashboardScreenState();
}

class _EditorialDashboardScreenState extends State<EditorialDashboardScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> poems = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final rows = await Supabase.instance.client
          .from('poem_editorial_status')
          .select('*')
          .order('verification_status')
          .order('poet_name');

      if (!mounted) return;
      setState(() {
        poems = List<Map<String, dynamic>>.from(rows as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  String readiness(Map<String, dynamic> p) {
    final sources = (p['linked_source_count'] as num?)?.toInt() ?? 0;
    final approvals = (p['approval_count'] as num?)?.toInt() ?? 0;
    final disputed = (p['disputed_review_count'] as num?)?.toInt() ?? 0;
    final changes = (p['changes_requested_count'] as num?)?.toInt() ?? 0;

    if (disputed > 0) return 'متنازع عليه';
    if (changes > 0) return 'يحتاج تعديلات';
    if (sources >= 2 && approvals >= 1) return 'جاهز للمراجعة النهائية';
    if (sources >= 1) return 'توثيق جزئي';
    return 'مصادر غير كافية';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحرير')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !AppConfig.hasSupabase
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text(
                        'لوحة التحرير تحتاج Supabase وملفات SQL الخاصة بـ MVP 1.7 و1.8.',
                      ),
                    ),
                  ),
                )
              : error != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(error!),
                    )
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        const Card(
                          child: Padding(
                            padding: EdgeInsets.all(16),
                            child: Text(
                              'الغرض من هذه الشاشة مساعدة المحررين على تحديد القصائد التي تحتاج مصادر أو مراجعة أو معالجة اختلاف الرواية. '
                              'لا تعتمد النصوص تلقائيًا.',
                              style: TextStyle(height: 1.7),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        ...poems.map(
                          (p) => Card(
                            child: ListTile(
                              leading: const Icon(Icons.rule_folder_outlined),
                              title: Text(p['title_ar']?.toString() ?? ''),
                              subtitle: Text(
                                '${p['poet_name'] ?? ''}\n${readiness(p)}',
                              ),
                              isThreeLine: true,
                              trailing: Text(
                                p['verification_status']?.toString() ??
                                    'review_required',
                                style: const TextStyle(fontSize: 11),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
    );
  }
}
