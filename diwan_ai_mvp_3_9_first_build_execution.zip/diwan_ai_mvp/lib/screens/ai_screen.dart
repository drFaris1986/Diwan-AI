import 'package:flutter/material.dart';

import '../models/verse_result.dart';
import '../services/ai_answer_service.dart';
import '../services/repository_provider.dart';

class AiScreen extends StatefulWidget {
  const AiScreen({super.key});

  @override
  State<AiScreen> createState() => _AiScreenState();
}

class _AiScreenState extends State<AiScreen> {
  final controller = TextEditingController();
  late final AiAnswerService service;

  @override
  void initState() {
    super.initState();
    service = AiAnswerService(RepositoryProvider.create());
  }

  final messages = <_ChatItem>[
    const _ChatItem(
      text:
          'مرحبًا بك في ديوان AI. اسألني عن شاعر، بيت، معنى، عصر أو موضوع شعري.',
      isUser: false,
    ),
  ];

  bool loading = false;

  Future<void> send() async {
    final text = controller.text.trim();
    if (text.isEmpty || loading) return;

    setState(() {
      messages.add(_ChatItem(text: text, isUser: true));
      controller.clear();
      loading = true;
    });

    final result = await service.answerQuestion(text);

    if (!mounted) return;
    setState(() {
      messages.add(
        _ChatItem(
          text: result.answer,
          isUser: false,
          evidence: result.evidence,
        ),
      );
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          children: [
            Text('اسأل ديوان'),
            Text(
              'بحث مستند إلى قاعدة الشعر',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w400),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length + (loading ? 1 : 0),
              itemBuilder: (context, index) {
                if (loading && index == messages.length) {
                  return const Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: CircularProgressIndicator(),
                    ),
                  );
                }

                final m = messages[index];
                return _MessageBubble(item: m);
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      onSubmitted: (_) => send(),
                      decoration: const InputDecoration(
                        hintText: 'مثال: أبيات عن الفخر أو المتنبي...',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: send,
                    icon: const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final _ChatItem item;
  const _MessageBubble({required this.item});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment:
          item.isUser ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 340),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: item.isUser ? const Color(0xFF0D2240) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: item.isUser
              ? null
              : Border.all(color: const Color(0xFFE7DDCA)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              item.text,
              style: TextStyle(
                height: 1.7,
                color: item.isUser ? Colors.white : Colors.black87,
              ),
            ),
            if (item.evidence.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Divider(),
              const Text(
                'الأدلة المسترجعة',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              ...item.evidence.map(
                (e) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    '• ${e.text}\n  ${e.poet} — ${e.poemTitle}',
                    style: const TextStyle(fontSize: 12, height: 1.5),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ChatItem {
  final String text;
  final bool isUser;
  final List<VerseResult> evidence;

  const _ChatItem({
    required this.text,
    required this.isUser,
    this.evidence = const [],
  });
}
