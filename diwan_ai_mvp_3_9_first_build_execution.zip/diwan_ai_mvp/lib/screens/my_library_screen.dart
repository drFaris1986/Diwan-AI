import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import '../services/user_library_service.dart';

class MyLibraryScreen extends StatefulWidget {
  const MyLibraryScreen({super.key});

  @override
  State<MyLibraryScreen> createState() => _MyLibraryScreenState();
}

class _MyLibraryScreenState extends State<MyLibraryScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> poems = const [];
  List<Map<String, dynamic>> verses = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase ||
        Supabase.instance.client.auth.currentUser == null) {
      setState(() => loading = false);
      return;
    }

    try {
      final service = UserLibraryService(Supabase.instance.client);
      final p = await service.favoritePoems();
      final v = await service.savedVerses();

      if (!mounted) return;
      setState(() {
        poems = p;
        verses = v;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final signedIn = AppConfig.hasSupabase &&
        Supabase.instance.client.auth.currentUser != null;

    return Scaffold(
      appBar: AppBar(title: const Text('مكتبتي')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !signedIn
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text(
                        'سجّل الدخول أولًا لعرض القصائد والأبيات المحفوظة.',
                      ),
                    ),
                  ),
                )
              : error != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(error!),
                    )
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        const Text(
                          'القصائد المفضلة',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 8),
                        if (poems.isEmpty)
                          const Text('لا توجد قصائد مفضلة بعد.'),
                        ...poems.map(
                          (row) => Card(
                            child: ListTile(
                              leading: const Icon(Icons.favorite_outline),
                              title: Text(
                                row['poems']?['title_ar']?.toString() ?? '',
                              ),
                              subtitle: Text(
                                row['poems']?['poets']?['name_ar']
                                        ?.toString() ??
                                    '',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'الأبيات المحفوظة',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 8),
                        if (verses.isEmpty)
                          const Text('لا توجد أبيات محفوظة بعد.'),
                        ...verses.map(
                          (row) => Card(
                            child: ListTile(
                              leading: const Icon(Icons.bookmark_outline),
                              title: Text(
                                row['verses']?['full_text']?.toString() ?? '',
                              ),
                              subtitle: Text(row['note']?.toString() ?? ''),
                            ),
                          ),
                        ),
                      ],
                    ),
    );
  }
}
