import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class VerseVariantsScreen extends StatefulWidget {
  final String verseId;
  final String verseText;

  const VerseVariantsScreen({
    super.key,
    required this.verseId,
    required this.verseText,
  });

  @override
  State<VerseVariantsScreen> createState() => _VerseVariantsScreenState();
}

class _VerseVariantsScreenState extends State<VerseVariantsScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> variants = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final rows = await Supabase.instance.client
          .from('verse_variant_catalog')
          .select('*')
          .eq('verse_id', widget.verseId);

      if (!mounted) return;
      setState(() {
        variants = List<Map<String, dynamic>>.from(rows as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اختلاف الروايات')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !AppConfig.hasSupabase
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('تحتاج هذه الشاشة ربط Supabase.'),
                )
              : error != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(error!),
                    )
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(18),
                            child: Text(
                              widget.verseText,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 20,
                                height: 1.8,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        if (variants.isEmpty)
                          const Card(
                            child: Padding(
                              padding: EdgeInsets.all(16),
                              child: Text(
                                'لا توجد اختلافات رواية مسجلة لهذا البيت حاليًا.',
                              ),
                            ),
                          ),
                        ...variants.map((v) {
                          final first =
                              v['first_hemistich_variant']?.toString() ?? '';
                          final second =
                              v['second_hemistich_variant']?.toString() ?? '';
                          final full = v['full_text_variant']?.toString();
                          final text = (full != null && full.isNotEmpty)
                              ? full
                              : '$first $second'.trim();

                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          v['source_title']?.toString() ??
                                              'مصدر غير مسمى',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                      ),
                                      if (v['is_preferred'] == true)
                                        const Chip(
                                          label: Text('الرواية المختارة'),
                                        ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    text,
                                    style: const TextStyle(
                                      fontSize: 19,
                                      height: 1.7,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    'النوع: ${v['variant_type'] ?? 'other'}',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                  if ((v['editorial_note']?.toString() ?? '')
                                      .isNotEmpty)
                                    Text(
                                      v['editorial_note'].toString(),
                                      style: const TextStyle(
                                        fontSize: 12,
                                        height: 1.5,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
    );
  }
}
