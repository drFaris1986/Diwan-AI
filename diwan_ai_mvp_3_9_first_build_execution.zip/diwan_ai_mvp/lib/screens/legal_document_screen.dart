import 'package:flutter/material.dart';

class LegalDocumentScreen extends StatelessWidget {
  final String title;
  final List<LegalSection> sections;

  const LegalDocumentScreen({
    super.key,
    required this.title,
    required this.sections,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w900,
              color: Color(0xFF0D2240),
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'نسخة Beta — سبتمبر 2026',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 20),
          ...sections.map(
            (section) => Padding(
              padding: const EdgeInsets.only(bottom: 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    section.title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    section.body,
                    style: const TextStyle(height: 1.8),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class LegalSection {
  final String title;
  final String body;

  const LegalSection(this.title, this.body);
}

const privacySections = [
  LegalSection(
    'ما الذي نجمعه؟',
    'عند استخدام ميزات الحساب قد نخزن البريد الإلكتروني، المفضلة، الأبيات المحفوظة، تقدم القراءة، وسجل أسئلة ديوان المرتبط بالحساب. كما قد نسجل أحداث استخدام مجمعة مثل فتح قصيدة أو مشاركة بيت لتحسين المنتج.',
  ),
  LegalSection(
    'البحث والتحليلات',
    'لا يخزن نظام Analytics نص عبارة البحث. تسجل فقط معلومات تشغيلية محدودة مثل طول الاستعلام، وجود فلاتر، وعدد النتائج. سجلات Analytics الخام غير متاحة للقراءة من تطبيق الهاتف.',
  ),
  LegalSection(
    'الذكاء الاصطناعي',
    'الأسئلة المرسلة إلى ميزة اسأل ديوان قد تعالج عبر خدمة ذكاء اصطناعي من الخادم. لا ينبغي إدخال معلومات شخصية حساسة في الأسئلة. ديوان AI يحاول تقييد الإجابة بالأدلة المسترجعة، لكن الإجابات الآلية قد تحتاج مراجعة.',
  ),
  LegalSection(
    'المحتوى الشعري',
    'يعرض التطبيق حالات توثيق مثل verified وreview_required وdisputed. لا تعني نتيجة البحث أو التشابه الدلالي وحدها أن نسبة البيت إلى شاعر قد ثبتت.',
  ),
  LegalSection(
    'الحذف والأمان',
    'عند الإطلاق العام يجب توفير وسيلة واضحة لطلب حذف الحساب والبيانات المرتبطة به. مفاتيح OpenAI ومفاتيح Supabase السرية لا تحفظ داخل تطبيق الهاتف.',
  ),
];

const termsSections = [
  LegalSection(
    'طبيعة الخدمة',
    'ديوان AI منصة للقراءة والبحث والتعلم حول الشعر العربي. النسخة الحالية تجريبية وقد تتغير الميزات والمحتويات.',
  ),
  LegalSection(
    'الدقة والتوثيق',
    'نبذل جهدًا لتوثيق النصوص ونسبتها إلى مصادر، لكن بعض المحتوى يبقى قيد المراجعة. يجب الانتباه إلى شارة حالة التوثيق والمصادر المرتبطة.',
  ),
  LegalSection(
    'الذكاء الاصطناعي',
    'الإجابات الآلية ليست مرجعًا أكاديميًا نهائيًا. عند الحاجة إلى استشهاد علمي أو نشر رسمي يجب الرجوع إلى الطبعة أو المصدر المبين والتحقق منه.',
  ),
  LegalSection(
    'حقوق المحتوى',
    'تعطى الأولوية للشعر الكلاسيكي والتراثي. لا يسمح باستخدام التطبيق لإعادة نشر محتوى حديث محمي بحقوق نشر على نطاق واسع دون إذن مناسب.',
  ),
  LegalSection(
    'الاستخدام المقبول',
    'لا يجوز محاولة تجاوز أنظمة الأمان أو إساءة استخدام الحسابات أو تحميل محتوى غير مصرح به أو استخدام الخدمة بطريقة مخالفة للقانون.',
  ),
];
