import 'package:flutter/material.dart';

import '../services/local_preferences_service.dart';

class OnboardingScreen extends StatefulWidget {
  final VoidCallback onComplete;

  const OnboardingScreen({
    super.key,
    required this.onComplete,
  });

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final controller = PageController();
  int index = 0;
  bool saving = false;

  static const pages = [
    (
      icon: Icons.menu_book_rounded,
      title: 'الشعر العربي في مكان واحد',
      body:
          'استكشف الشعراء والقصائد من العصر الجاهلي إلى العصر المعاصر، مع تجربة عربية مصممة للقراءة.',
    ),
    (
      icon: Icons.verified_outlined,
      title: 'اعرف مصدر البيت',
      body:
          'ديوان AI يفرق بين النص الموثق، النص قيد المراجعة، والاختلافات بين الروايات بدل إخفائها.',
    ),
    (
      icon: Icons.auto_awesome,
      title: 'اسأل ديوان',
      body:
          'استخدم الذكاء الاصطناعي للبحث والتحليل، مع ربط الإجابات بالأدلة الموجودة في قاعدة ديوان.',
    ),
    (
      icon: Icons.manage_search,
      title: 'ابحث بطريقتك',
      body:
          'ابحث بالبيت أو الشاعر أو القصيدة، وصفِّ النتائج حسب العصر والبحر والقافية.',
    ),
  ];

  Future<void> finish() async {
    if (saving) return;
    setState(() => saving = true);
    await LocalPreferencesService().completeOnboarding();
    if (!mounted) return;
    widget.onComplete();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF0D2240);
    const cream = Color(0xFFF7F1E7);
    const gold = Color(0xFFC99A3D);

    return Scaffold(
      backgroundColor: cream,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                onPressed: finish,
                child: const Text('تخطي'),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: controller,
                itemCount: pages.length,
                onPageChanged: (value) => setState(() => index = value),
                itemBuilder: (context, i) {
                  final page = pages[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 110,
                          height: 110,
                          decoration: BoxDecoration(
                            color: navy,
                            borderRadius: BorderRadius.circular(32),
                          ),
                          child: Icon(
                            page.icon,
                            size: 54,
                            color: gold,
                          ),
                        ),
                        const SizedBox(height: 28),
                        Text(
                          page.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: navy,
                            fontSize: 27,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          page.body,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 16,
                            height: 1.8,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 8, 22, 24),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      pages.length,
                      (i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: i == index ? 24 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: i == index ? gold : const Color(0xFFD9D0C2),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: saving
                          ? null
                          : () {
                              if (index == pages.length - 1) {
                                finish();
                              } else {
                                controller.nextPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeOut,
                                );
                              }
                            },
                      child: Text(
                        index == pages.length - 1 ? 'ابدأ مع ديوان' : 'التالي',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
