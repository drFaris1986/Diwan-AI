import 'package:flutter/material.dart';

import '../services/account_deletion_service.dart';

class AccountDeletionScreen extends StatefulWidget {
  const AccountDeletionScreen({super.key});

  @override
  State<AccountDeletionScreen> createState() =>
      _AccountDeletionScreenState();
}

class _AccountDeletionScreenState extends State<AccountDeletionScreen> {
  final reason = TextEditingController();
  final service = AccountDeletionService();

  bool loading = true;
  bool submitting = false;
  Map<String, dynamic>? latest;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final row = await service.latestRequest();
      if (!mounted) return;
      setState(() {
        latest = row;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> submit() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('طلب حذف الحساب'),
        content: const Text(
          'سيتم إرسال طلب حذف للحساب والبيانات المرتبطة به. '
          'في نسخة Beta تتم عملية الحذف النهائية بواسطة إجراء إداري آمن '
          'ولا يحذف التطبيق الحساب فورًا من الهاتف.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('إرسال الطلب'),
          ),
        ],
      ),
    );

    if (approved != true) return;

    setState(() {
      submitting = true;
      error = null;
    });

    try {
      await service.requestDeletion(reason: reason.text);
      reason.clear();
      await load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تسجيل طلب حذف الحساب.')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        submitting = false;
        error = e.toString();
      });
      return;
    }

    if (mounted) setState(() => submitting = false);
  }


  Future<void> permanentlyDelete() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف نهائي'),
        content: const Text(
          'سيتم حذف الحساب نهائيًا عبر الخادم. لا يمكن التراجع عن هذه العملية.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف نهائي'),
          ),
        ],
      ),
    );

    if (approved != true) return;
    setState(() {
      submitting = true;
      error = null;
    });

    try {
      await service.permanentlyDeleteAccount();
      if (!mounted) return;
      Navigator.of(context).popUntil((route) => route.isFirst);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حذف الحساب.')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        submitting = false;
        error = e.toString();
      });
    }
  }

  @override
  void dispose() {
    reason.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final status = latest?['status']?.toString();

    return Scaffold(
      appBar: AppBar(title: const Text('حذف الحساب')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Icon(
                  Icons.delete_forever_outlined,
                  size: 52,
                  color: Color(0xFF0D2240),
                ),
                const SizedBox(height: 14),
                const Text(
                  'طلب حذف الحساب والبيانات',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'يشمل الطلب بيانات الحساب التي يديرها ديوان AI مثل '
                  'المفضلة، الأبيات المحفوظة، تقدم القراءة وسجل الأسئلة '
                  'المرتبط بالحساب. سجلات التشغيل المجمعة التي لا تعرّف '
                  'المستخدم قد تبقى ضمن إحصاءات المنتج.',
                  style: TextStyle(height: 1.7),
                ),
                if (status != null) ...[
                  const SizedBox(height: 16),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.pending_actions_outlined),
                      title: const Text('آخر طلب'),
                      subtitle: Text(
                        'الحالة: $status\n'
                        'التاريخ: ${latest?['requested_at'] ?? '-'}',
                      ),
                      isThreeLine: true,
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                TextField(
                  controller: reason,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'سبب الحذف — اختياري',
                    hintText: 'لا تكتب معلومات حساسة.',
                  ),
                ),
                if (error != null) ...[
                  const SizedBox(height: 10),
                  Text(error!),
                ],
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed:
                      submitting || status == 'requested' ? null : submit,
                  icon: const Icon(Icons.delete_outline),
                  label: Text(
                    status == 'requested'
                        ? 'الطلب مسجل'
                        : 'إرسال طلب حذف الحساب',
                  ),
                ),
                if (status == 'requested') ...[
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: submitting ? null : permanentlyDelete,
                    icon: const Icon(Icons.delete_forever_outlined),
                    label: const Text('تأكيد الحذف النهائي'),
                  ),
                ],
              ],
            ),
    );
  }
}
