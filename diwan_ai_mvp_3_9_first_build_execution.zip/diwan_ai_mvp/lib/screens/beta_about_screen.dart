import 'package:flutter/material.dart';

class BetaAboutScreen extends StatelessWidget {
  const BetaAboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حول النسخة التجريبية')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ديوان AI',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF0D2240),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'الإصدار 2.1.0-beta',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 14),
                  Text(
                    'نسخة تجريبية لمنصة شعر عربي تعتمد على قاعدة بيانات قابلة للتوثيق، '
                    'وبحث ذكي مقيد بالأدلة والمصادر.',
                    style: TextStyle(height: 1.7),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 12),
          Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'تنبيه: بعض النصوص قد تحمل حالة review_required، '
                'أي أنها لم تصل بعد إلى اعتماد تحريري نهائي.',
                style: TextStyle(height: 1.7),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
