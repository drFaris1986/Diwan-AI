import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../models/rag_answer.dart';
import '../services/rag_service.dart';

class RagAiScreen extends StatefulWidget {
  const RagAiScreen({super.key});

  @override
  State<RagAiScreen> createState() => _RagAiScreenState();
}

class _RagAiScreenState extends State<RagAiScreen> {
  final controller = TextEditingController();
  final service = RagService();

  bool loading = false;
  String? error;
  RagAnswer? result;

  Future<void> ask() async {
    final q = controller.text.trim();
    if (q.isEmpty || loading) return;

    setState(() {
      loading = true;
      error = null;
      result = null;
    });

    try {
      final answer = await service.ask(q);
      if (!mounted) return;
      setState(() {
        result = answer;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اسأل ديوان — RAG')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (!AppConfig.hasSupabase)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'لتشغيل RAG الحقيقي، شغّل التطبيق مع مفاتيح Supabase '
                  'وانشر Edge Function المسماة ask-diwan.',
                  style: TextStyle(height: 1.7),
                ),
              ),
            ),
          TextField(
            controller: controller,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              hintText: 'مثال: ما أشهر معنى للفخر في الأبيات الموجودة بقاعدة ديوان؟',
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: loading ? null : ask,
            icon: const Icon(Icons.auto_awesome),
            label: Text(loading ? 'يبحث في الأدلة...' : 'اسأل من المصادر'),
          ),
          if (loading) ...[
            const SizedBox(height: 24),
            const Center(child: CircularProgressIndicator()),
          ],
          if (error != null) ...[
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text('خطأ: $error'),
              ),
            ),
          ],
          if (result != null) ...[
            const SizedBox(height: 18),
            _AnswerCard(result: result!),
            const SizedBox(height: 14),
            Text(
              'الأدلة (${result!.evidence.length})',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFF0D2240),
              ),
            ),
            const SizedBox(height: 8),
            ...result!.evidence.asMap().entries.map(
              (entry) => _EvidenceCard(
                number: entry.key + 1,
                evidence: entry.value,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _AnswerCard extends StatelessWidget {
  final RagAnswer result;
  const _AnswerCard({required this.result});

  @override
  Widget build(BuildContext context) {
    final pct = (result.confidence * 100).round();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'الإجابة',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 20,
                color: Color(0xFF0D2240),
              ),
            ),
            const SizedBox(height: 10),
            Text(result.answer, style: const TextStyle(height: 1.8)),
            const Divider(height: 28),
            Row(
              children: [
                const Icon(Icons.shield_outlined),
                const SizedBox(width: 8),
                Text(
                  'مؤشر الثقة: $pct%',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 4),
            const Text(
              'مؤشر منتج إرشادي مبني على التشابه وحالة التوثيق والمصادر، وليس احتمالًا إحصائيًا.',
              style: TextStyle(fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _EvidenceCard extends StatelessWidget {
  final int number;
  final RagEvidence evidence;

  const _EvidenceCard({
    required this.number,
    required this.evidence,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ExpansionTile(
        leading: CircleAvatar(child: Text('$number')),
        title: Text(
          evidence.text,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text('${evidence.poet} • ${evidence.poemTitle}'),
        childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: Text('العصر: ${evidence.era}'),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: Text('حالة التوثيق: ${evidence.verificationStatus}'),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              'تشابه دلالي: ${(evidence.similarity * 100).round()}%',
            ),
          ),
          const SizedBox(height: 10),
          if (evidence.sources.isEmpty)
            const Align(
              alignment: Alignment.centerRight,
              child: Text('لا يوجد مصدر مرتبط ظاهر لهذا الدليل.'),
            )
          else
            ...evidence.sources.map(
              (s) => Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    'المصدر: ${s['title'] ?? '—'}'
                    '${s['page_reference'] != null ? ' • ${s['page_reference']}' : ''}',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
