import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class EditorialStatusScreen extends StatefulWidget {
  const EditorialStatusScreen({super.key});

  @override
  State<EditorialStatusScreen> createState() => _EditorialStatusScreenState();
}

class _EditorialStatusScreenState extends State<EditorialStatusScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> rows = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final data = await Supabase.instance.client
          .from('poem_editorial_status')
          .select('*')
          .order('poet_name');

      if (!mounted) return;
      setState(() {
        rows = List<Map<String, dynamic>>.from(data as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حالة التوثيق')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !AppConfig.hasSupabase
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text(
                        'اربط Supabase ثم نفّذ ملف mvp_1_7_editorial.sql '
                        'لعرض لوحة التوثيق.',
                      ),
                    ),
                  ),
                )
              : error != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(error!),
                    )
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        const Card(
                          child: Padding(
                            padding: EdgeInsets.all(16),
                            child: Text(
                              'هذه اللوحة لا تعتمد القصائد آليًا؛ '
                              'هي تعرض مؤشرات تساعد فريق التحرير على معرفة ما ينقص قبل verified.',
                              style: TextStyle(height: 1.7),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        ...rows.map((row) {
                          final status =
                              row['verification_status']?.toString() ?? 'review_required';
                          return Card(
                            child: ExpansionTile(
                              title: Text(row['title_ar']?.toString() ?? ''),
                              subtitle: Text(
                                '${row['poet_name'] ?? ''} • $status',
                              ),
                              childrenPadding:
                                  const EdgeInsets.fromLTRB(18, 0, 18, 16),
                              children: [
                                _line('عدد الأبيات', row['verse_count']),
                                _line('المصادر المرتبطة', row['linked_source_count']),
                                _line('اختلافات الرواية', row['variant_count']),
                                _line('موافقات المراجعين', row['approval_count']),
                                _line(
                                  'طلبات التعديل',
                                  row['changes_requested_count'],
                                ),
                                _line(
                                  'مراجعات متنازع عليها',
                                  row['disputed_review_count'],
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
    );
  }

  Widget _line(String label, dynamic value) => Align(
        alignment: Alignment.centerRight,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 5),
          child: Text('$label: ${value ?? 0}'),
        ),
      );
}
