import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import '../data/mock_data.dart';
import 'poet_profile_screen.dart';
import 'cloud_poem_detail_screen.dart';

class CloudLibraryScreen extends StatefulWidget {
  const CloudLibraryScreen({super.key});

  @override
  State<CloudLibraryScreen> createState() => _CloudLibraryScreenState();
}

class _CloudLibraryScreenState extends State<CloudLibraryScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> cloudPoets = const [];
  List<Map<String, dynamic>> cloudPoems = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final client = Supabase.instance.client;

      final poetResponse = await client
          .from('poets')
          .select('id,name_ar,bio_ar,eras(name_ar)')
          .order('name_ar');

      final poemResponse = await client
          .from('poems')
          .select(
            'id,title_ar,meter_ar,rhyme_ar,verification_status,'
            'poets(name_ar),eras(name_ar),'
            'poem_sources(page_reference,sources(title,url,reliability_score))',
          )
          .order('title_ar');

      if (!mounted) return;
      setState(() {
        cloudPoets = List<Map<String, dynamic>>.from(poetResponse as List);
        cloudPoems = List<Map<String, dynamic>>.from(poemResponse as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المكتبة الموثقة')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Text('تعذر قراءة Supabase:\n$error'),
                    ),
                  ),
                )
              : AppConfig.hasSupabase
                  ? _CloudContent(
                      poets: cloudPoets,
                      poems: cloudPoems,
                    )
                  : const _LocalPreview(),
    );
  }
}

class _CloudContent extends StatelessWidget {
  final List<Map<String, dynamic>> poets;
  final List<Map<String, dynamic>> poems;

  const _CloudContent({
    required this.poets,
    required this.poems,
  });

  String nestedName(dynamic value) {
    if (value is Map<String, dynamic>) {
      return value['name_ar']?.toString() ?? '';
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          'الشعراء (${poets.length})',
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: Color(0xFF0D2240),
          ),
        ),
        const SizedBox(height: 8),
        ...poets.map(
          (p) => Card(
            child: ListTile(
              leading: const Icon(Icons.person_outline),
              title: Text(p['name_ar'] ?? ''),
              subtitle: Text(nestedName(p['eras'])),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PoetProfileScreen(
                    poetId: p['id'].toString(),
                    poetName: p['name_ar']?.toString() ?? '',
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'القصائد (${poems.length})',
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: Color(0xFF0D2240),
          ),
        ),
        const SizedBox(height: 8),
        ...poems.map((p) {
          final sourceLinks = p['poem_sources'];
          var sourceLabel = 'لا يوجد مصدر ظاهر';
          if (sourceLinks is List && sourceLinks.isNotEmpty) {
            final link = sourceLinks.first;
            if (link is Map<String, dynamic>) {
              final source = link['sources'];
              if (source is Map<String, dynamic>) {
                sourceLabel = source['title']?.toString() ?? sourceLabel;
              }
            }
          }

          return Card(
            child: ExpansionTile(
              leading: const Icon(Icons.menu_book_outlined),
              title: Text(p['title_ar'] ?? ''),
              subtitle: Text(
                '${nestedName(p['poets'])} • ${nestedName(p['eras'])}',
              ),
              trailing: IconButton(
                tooltip: 'فتح القصيدة',
                icon: const Icon(Icons.open_in_new),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CloudPoemDetailScreen(
                      poemId: p['id'].toString(),
                      title: p['title_ar']?.toString() ?? '',
                    ),
                  ),
                ),
              ),
              childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
              children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('الحالة: ${p['verification_status']}'),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('البحر: ${p['meter_ar'] ?? '—'}'),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('القافية: ${p['rhyme_ar'] ?? '—'}'),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'المصدر: $sourceLabel',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}

class _LocalPreview extends StatelessWidget {
  const _LocalPreview();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'التطبيق يعمل حاليًا في الوضع المحلي. '
              'بعد إضافة مفاتيح Supabase ستظهر هنا المكتبة المستوردة مباشرة من قاعدة البيانات.',
              style: TextStyle(height: 1.7),
            ),
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'معاينة محلية',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
        ),
        const SizedBox(height: 8),
        ...poets.map(
          (p) => Card(
            child: ListTile(
              title: Text(p.name),
              subtitle: Text(p.era),
            ),
          ),
        ),
      ],
    );
  }
}
