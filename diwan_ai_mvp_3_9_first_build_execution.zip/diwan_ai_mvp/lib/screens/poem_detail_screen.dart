import 'package:flutter/material.dart';
import '../models/poem.dart';

class PoemDetailScreen extends StatelessWidget {
  final Poem poem;
  const PoemDetailScreen({super.key, required this.poem});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(poem.title)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    poem.title,
                    style: const TextStyle(
                      color: Color(0xFF0D2240),
                      fontWeight: FontWeight.w800,
                      fontSize: 22,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('${poem.poet} • ${poem.era}'),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Chip(label: Text('البحر: ${poem.meter}')),
                      Chip(label: Text('القافية: ${poem.rhyme}')),
                      Chip(
                        avatar: const Icon(Icons.verified_outlined, size: 18),
                        label: Text(poem.sourceStatus),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
              child: Column(
                children: poem.verses
                    .map(
                      (verse) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Text(
                          verse,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 21,
                            height: 1.8,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: const Text(
                'شرح وتحليل بالذكاء الاصطناعي',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text(
                'سيتم ربط هذه الميزة بنظام RAG وقاعدة المصادر في المرحلة التالية.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
