import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import 'poets_screen.dart';

class ErasScreen extends StatelessWidget {
  const ErasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('العصور الشعرية')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: eras.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final era = eras[index];
          return Card(
            child: ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFF3E8D1),
                child: Text('${index + 1}'),
              ),
              title: Text(
                era,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(
                index == 0 || index == 3
                    ? 'توجد بيانات تجريبية'
                    : 'سيُضاف المحتوى في المرحلة التالية',
              ),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PoetsScreen(initialEra: era),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
