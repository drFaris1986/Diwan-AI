import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class AnalyticsDashboardScreen extends StatefulWidget {
  const AnalyticsDashboardScreen({super.key});

  @override
  State<AnalyticsDashboardScreen> createState() =>
      _AnalyticsDashboardScreenState();
}

class _AnalyticsDashboardScreenState
    extends State<AnalyticsDashboardScreen> {
  bool loading = true;
  String? error;
  Map<String, dynamic> overview = const {};
  List<Map<String, dynamic>> poems = const [];
  List<Map<String, dynamic>> poets = const [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final client = Supabase.instance.client;
      if (client.auth.currentUser == null) {
        setState(() => loading = false);
        return;
      }

      final data = await Future.wait([
        client.from('analytics_overview_30d').select('*').maybeSingle(),
        client.from('analytics_top_poems_30d').select('*').limit(10),
        client.from('analytics_top_poets_30d').select('*').limit(10),
      ]);

      if (!mounted) return;
      setState(() {
        overview = data[0] == null
            ? <String, dynamic>{}
            : Map<String, dynamic>.from(data[0] as Map);
        poems = List<Map<String, dynamic>>.from(data[1] as List);
        poets = List<Map<String, dynamic>>.from(data[2] as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = AppConfig.hasSupabase
        ? Supabase.instance.client.auth.currentUser
        : null;

    return Scaffold(
      appBar: AppBar(title: const Text('مؤشرات Beta')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !AppConfig.hasSupabase
              ? const _Message(
                  text:
                      'تحتاج لوحة المؤشرات ربط Supabase وتشغيل migration 2.8.',
                )
              : user == null
                  ? const _Message(
                      text: 'سجّل الدخول لعرض مؤشرات Beta المجمعة.',
                    )
                  : error != null
                      ? _Message(text: error!)
                      : RefreshIndicator(
                          onRefresh: load,
                          child: ListView(
                            padding: const EdgeInsets.all(16),
                            children: [
                              const Text(
                                'آخر 30 يومًا',
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  color: Color(0xFF0D2240),
                                ),
                              ),
                              const SizedBox(height: 10),
                              GridView.count(
                                crossAxisCount: 2,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                childAspectRatio: 1.55,
                                mainAxisSpacing: 8,
                                crossAxisSpacing: 8,
                                children: [
                                  _Metric(
                                    label: 'فتح القصائد',
                                    value: overview['poem_opens'],
                                  ),
                                  _Metric(
                                    label: 'عمليات البحث',
                                    value: overview['searches'],
                                  ),
                                  _Metric(
                                    label: 'حفظ الأبيات',
                                    value: overview['verse_saves'],
                                  ),
                                  _Metric(
                                    label: 'مشاركة الأبيات',
                                    value: overview['verse_shares'],
                                  ),
                                  _Metric(
                                    label: 'جلسات',
                                    value: overview['sessions'],
                                  ),
                                  _Metric(
                                    label: 'أسئلة RAG',
                                    value: overview['rag_questions'],
                                  ),
                                ],
                              ),
                              const SizedBox(height: 22),
                              const _SectionTitle('أكثر القصائد تفاعلًا'),
                              ...poems.map(
                                (row) => Card(
                                  child: ListTile(
                                    leading: const Icon(
                                      Icons.menu_book_outlined,
                                    ),
                                    title: Text(
                                      row['title_ar']?.toString() ?? '',
                                    ),
                                    subtitle: Text(
                                      row['poet_name']?.toString() ?? '',
                                    ),
                                    trailing: Text(
                                      '${row['total_events'] ?? 0}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 18),
                              const _SectionTitle('أكثر الشعراء تفاعلًا'),
                              ...poets.map(
                                (row) => Card(
                                  child: ListTile(
                                    leading:
                                        const Icon(Icons.person_outline),
                                    title: Text(
                                      row['poet_name']?.toString() ?? '',
                                    ),
                                    trailing: Text(
                                      '${row['total_events'] ?? 0}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 18),
                              const Card(
                                child: Padding(
                                  padding: EdgeInsets.all(16),
                                  child: Text(
                                    'اللوحة تعرض بيانات مجمعة فقط. '
                                    'نصوص البحث لا تُخزن ضمن Analytics.',
                                    style: TextStyle(height: 1.6),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label;
  final dynamic value;

  const _Metric({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '${value ?? 0}',
              style: const TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.w900,
                color: Color(0xFF0D2240),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 19,
            fontWeight: FontWeight.w900,
          ),
        ),
      );
}

class _Message extends StatelessWidget {
  final String text;
  const _Message({required this.text});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(text, textAlign: TextAlign.center),
        ),
      );
}
