import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class DataStatusScreen extends StatefulWidget {
  const DataStatusScreen({super.key});

  @override
  State<DataStatusScreen> createState() => _DataStatusScreenState();
}

class _DataStatusScreenState extends State<DataStatusScreen> {
  bool loading = true;
  String status = '';
  Map<String, int> counts = const {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() {
        loading = false;
        status = 'الوضع المحلي';
        counts = const {};
      });
      return;
    }

    try {
      final client = Supabase.instance.client;
      final eraRows = await client.from('eras').select('id');
      final poetRows = await client.from('poets').select('id');
      final poemRows = await client.from('poems').select('id');
      final verseRows = await client.from('verses').select('id');

      if (!mounted) return;
      setState(() {
        loading = false;
        status = 'متصل بـ Supabase';
        counts = {
          'العصور': (eraRows as List).length,
          'الشعراء': (poetRows as List).length,
          'القصائد': (poemRows as List).length,
          'الأبيات': (verseRows as List).length,
        };
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        status = 'تعذر الاتصال: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حالة البيانات')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.storage_outlined),
                      title: Text(
                        status,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: Text(
                        AppConfig.hasSupabase
                            ? 'يستخدم التطبيق قاعدة البيانات السحابية.'
                            : 'لم يتم تمرير مفاتيح Supabase؛ التطبيق يعمل بالبيانات التجريبية المحلية.',
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ...counts.entries.map(
                    (e) => Card(
                      child: ListTile(
                        title: Text(e.key),
                        trailing: Text(
                          '${e.value}',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
