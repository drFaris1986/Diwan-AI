import 'package:flutter/material.dart';

class ReleaseReadinessScreen extends StatelessWidget {
  const ReleaseReadinessScreen({super.key});

  static const checks = [
    ('Onboarding', true, 'موجود ومخزن محليًا'),
    ('سياسة الخصوصية', true, 'مسودة Beta داخل التطبيق'),
    ('شروط الاستخدام', true, 'مسودة Beta داخل التطبيق'),
    ('طلب حذف الحساب', true, 'واجهة + جدول RLS'),
    ('Supabase migrations', true, 'ملفات timestamped موجودة'),
    ('Flutter compile', false, 'لم يتم تشغيل Flutter SDK'),
    ('iOS native project', false, 'مجلد ios غير مولد'),
    ('Android native project', false, 'مجلد android غير مولد'),
    ('Supabase staging deploy', false, 'يحتاج مشروعًا حقيقيًا'),
    ('OpenAI live test', false, 'يحتاج secret + deploy'),
    ('Store signing', false, 'لم يتم إعداد الشهادات/keystore'),
    ('Public privacy URL', false, 'يحتاج نطاقًا/صفحة منشورة'),
  ];

  @override
  Widget build(BuildContext context) {
    final passed = checks.where((e) => e.$2).length;

    return Scaffold(
      appBar: AppBar(title: const Text('جاهزية الإصدار')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    '$passed / ${checks.length}',
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF0D2240),
                    ),
                  ),
                  const Text('بوابات جاهزية مكتملة في المصدر'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          ...checks.map(
            (item) => Card(
              child: ListTile(
                leading: Icon(
                  item.$2
                      ? Icons.check_circle_outline
                      : Icons.radio_button_unchecked,
                  color: item.$2 ? null : const Color(0xFFC99A3D),
                ),
                title: Text(item.$1),
                subtitle: Text(item.$3),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'هذه الشاشة تقيس جاهزية ملفات المصدر فقط. '
                'لا تعني أن التطبيق تم رفعه أو اعتماده من أي متجر.',
                style: TextStyle(height: 1.6),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
