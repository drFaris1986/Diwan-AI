import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import 'cloud_poem_detail_screen.dart';
import 'verse_share_card_screen.dart';

class DailyVerseScreen extends StatefulWidget {
  const DailyVerseScreen({super.key});

  @override
  State<DailyVerseScreen> createState() => _DailyVerseScreenState();
}

class _DailyVerseScreenState extends State<DailyVerseScreen> {
  bool loading = true;
  String? error;
  Map<String, dynamic>? row;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final today = DateTime.now();
      final day =
          '${today.year.toString().padLeft(4, '0')}-'
          '${today.month.toString().padLeft(2, '0')}-'
          '${today.day.toString().padLeft(2, '0')}';

      final data = await Supabase.instance.client
          .from('daily_verse_catalog')
          .select('*')
          .eq('day', day)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        row = data == null ? null : Map<String, dynamic>.from(data);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بيت اليوم')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !AppConfig.hasSupabase
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text(
                        'بيت اليوم يحتاج ربط Supabase وتشغيل ملف mvp_1_8_daily_verse.sql.',
                      ),
                    ),
                  ),
                )
              : error != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(error!),
                    )
                  : row == null
                      ? const Padding(
                          padding: EdgeInsets.all(16),
                          child: Card(
                            child: Padding(
                              padding: EdgeInsets.all(18),
                              child: Text(
                                'لم يتم اختيار بيت لهذا اليوم بعد.',
                              ),
                            ),
                          ),
                        )
                      : ListView(
                          padding: const EdgeInsets.all(16),
                          children: [
                            Card(
                              child: Padding(
                                padding: const EdgeInsets.all(22),
                                child: Column(
                                  children: [
                                    const Icon(
                                      Icons.wb_sunny_outlined,
                                      color: Color(0xFFC99A3D),
                                      size: 32,
                                    ),
                                    const SizedBox(height: 14),
                                    Text(
                                      row!['first_hemistich']?.toString() ?? '',
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        fontSize: 24,
                                        height: 1.8,
                                        fontWeight: FontWeight.w700,
                                        color: Color(0xFF0D2240),
                                      ),
                                    ),
                                    if ((row!['second_hemistich']?.toString() ?? '').isNotEmpty)
                                      Text(
                                        row!['second_hemistich'].toString(),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          fontSize: 24,
                                          height: 1.8,
                                          fontWeight: FontWeight.w700,
                                          color: Color(0xFF0D2240),
                                        ),
                                      ),
                                    const Divider(height: 30),
                                    Text(
                                      row!['poet_name']?.toString() ?? '',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    Text(
                                      row!['poem_title']?.toString() ?? '',
                                      textAlign: TextAlign.center,
                                    ),
                                    if ((row!['editorial_note']?.toString() ?? '').isNotEmpty) ...[
                                      const SizedBox(height: 12),
                                      Text(
                                        row!['editorial_note'].toString(),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(height: 1.6),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            FilledButton.icon(
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => CloudPoemDetailScreen(
                                    poemId: row!['poem_id'].toString(),
                                    title: row!['poem_title']?.toString() ?? '',
                                  ),
                                ),
                              ),
                              icon: const Icon(Icons.menu_book_outlined),
                              label: const Text('فتح القصيدة'),
                            ),
                            const SizedBox(height: 8),
                            OutlinedButton.icon(
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => VerseShareCardScreen(
                                    firstHemistich:
                                        row!['first_hemistich']?.toString() ?? '',
                                    secondHemistich:
                                        row!['second_hemistich']?.toString() ?? '',
                                    poetName: row!['poet_name']?.toString() ?? '',
                                    poemTitle: row!['poem_title']?.toString() ?? '',
                                    verificationStatus:
                                        row!['verification_status']?.toString() ??
                                            'review_required',
                                  ),
                                ),
                              ),
                              icon: const Icon(Icons.ios_share_outlined),
                              label: const Text('مشاركة بيت اليوم'),
                            ),
                          ],
                        ),
    );
  }
}
