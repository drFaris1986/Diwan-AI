import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import '../services/auth_service.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final auth = AuthService();

  bool loading = false;
  String? message;

  Future<void> run(Future<void> Function() fn) async {
    setState(() {
      loading = true;
      message = null;
    });
    try {
      await fn();
      if (!mounted) return;
      setState(() {
        loading = false;
        message = 'تمت العملية بنجاح.';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        message = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!AppConfig.hasSupabase) {
      return const Scaffold(
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Text(
                  'الحسابات تحتاج تشغيل التطبيق مع Supabase.',
                  style: TextStyle(height: 1.7),
                ),
              ),
            ),
          ),
        ),
      );
    }

    final user = Supabase.instance.client.auth.currentUser;

    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (user != null) ...[
            Card(
              child: ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.person_outline),
                ),
                title: Text(user.email ?? 'مستخدم ديوان'),
                subtitle: const Text('يمكنك حفظ القصائد والأبيات وسجل الأسئلة.'),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.tonalIcon(
              onPressed: loading ? null : () => run(auth.signOut),
              icon: const Icon(Icons.logout),
              label: const Text('تسجيل الخروج'),
            ),
          ] else ...[
            TextField(
              controller: email,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'البريد الإلكتروني',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: password,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'كلمة المرور',
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: loading
                  ? null
                  : () => run(
                        () => auth.signInWithEmail(
                          email.text.trim(),
                          password.text,
                        ),
                      ),
              child: const Text('تسجيل الدخول'),
            ),
            const SizedBox(height: 8),
            OutlinedButton(
              onPressed: loading
                  ? null
                  : () => run(
                        () => auth.signUpWithEmail(
                          email.text.trim(),
                          password.text,
                        ),
                      ),
              child: const Text('إنشاء حساب'),
            ),
          ],
          if (message != null) ...[
            const SizedBox(height: 14),
            Text(message!),
          ],
        ],
      ),
    );
  }
}
