import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/poet.dart';

class PoetsScreen extends StatefulWidget {
  final String? initialEra;
  const PoetsScreen({super.key, this.initialEra});

  @override
  State<PoetsScreen> createState() => _PoetsScreenState();
}

class _PoetsScreenState extends State<PoetsScreen> {
  String? era;

  @override
  void initState() {
    super.initState();
    era = widget.initialEra;
  }

  @override
  Widget build(BuildContext context) {
    final filtered = era == null
        ? poets
        : poets.where((poet) => poet.era == era).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('الشعراء')),
      body: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                ChoiceChip(
                  label: const Text('الكل'),
                  selected: era == null,
                  onSelected: (_) => setState(() => era = null),
                ),
                const SizedBox(width: 8),
                ...eras.map(
                  (e) => Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: ChoiceChip(
                      label: Text(e),
                      selected: era == e,
                      onSelected: (_) => setState(() => era = e),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: filtered.isEmpty
                ? const Center(
                    child: Text('لم نضف شعراء لهذا العصر في النسخة التجريبية بعد.'),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final poet = filtered[index];
                      return _PoetCard(poet: poet);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _PoetCard extends StatelessWidget {
  final Poet poet;
  const _PoetCard({required this.poet});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ExpansionTile(
        leading: const CircleAvatar(
          child: Icon(Icons.person_outline),
        ),
        title: Text(
          poet.name,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(poet.era),
        childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: Text(poet.bio, style: const TextStyle(height: 1.7)),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: poet.themes
                .map((theme) => Chip(label: Text(theme)))
                .toList(),
          ),
        ],
      ),
    );
  }
}
