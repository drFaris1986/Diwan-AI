import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../services/feedback_service.dart';

class BetaFeedbackScreen extends StatefulWidget {
  const BetaFeedbackScreen({super.key});

  @override
  State<BetaFeedbackScreen> createState() => _BetaFeedbackScreenState();
}

class _BetaFeedbackScreenState extends State<BetaFeedbackScreen> {
  final controller = TextEditingController();
  String category = 'suggestion';
  bool sending = false;
  String? message;

  final categories = const {
    'bug': 'مشكلة تقنية',
    'content': 'ملاحظة على المحتوى',
    'suggestion': 'اقتراح',
    'ai_answer': 'إجابة الذكاء الاصطناعي',
    'other': 'أخرى',
  };

  Future<void> send() async {
    final text = controller.text.trim();
    if (text.length < 5 || sending) return;

    setState(() {
      sending = true;
      message = null;
    });

    try {
      await FeedbackService().submit(
        category: category,
        message: text,
        screenName: 'beta_feedback',
      );

      if (!mounted) return;
      controller.clear();
      setState(() {
        sending = false;
        message = 'شكرًا، تم إرسال ملاحظتك لفريق ديوان.';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        sending = false;
        message = 'تعذر الإرسال: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ملاحظات النسخة التجريبية')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (!AppConfig.hasSupabase)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'إرسال الملاحظات يحتاج ربط Supabase.',
                  style: TextStyle(height: 1.7),
                ),
              ),
            ),
          const Text(
            'ساعدنا في تحسين ديوان AI',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF0D2240),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'اكتب المشكلة أو الملاحظة بدقة. إذا كانت عن بيت أو قصيدة فاذكر النص أو اسم الشاعر.',
            style: TextStyle(height: 1.6),
          ),
          const SizedBox(height: 18),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'نوع الملاحظة'),
            items: categories.entries
                .map(
                  (e) => DropdownMenuItem(
                    value: e.key,
                    child: Text(e.value),
                  ),
                )
                .toList(),
            onChanged: sending
                ? null
                : (value) {
                    if (value != null) setState(() => category = value);
                  },
          ),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            minLines: 5,
            maxLines: 8,
            decoration: const InputDecoration(
              hintText: 'اكتب ملاحظتك هنا...',
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: sending ? null : send,
            icon: const Icon(Icons.send_outlined),
            label: Text(sending ? 'جاري الإرسال...' : 'إرسال'),
          ),
          if (message != null) ...[
            const SizedBox(height: 12),
            Text(message!),
          ],
        ],
      ),
    );
  }
}
