import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import '../services/deep_link_service.dart';
import 'cloud_poem_detail_screen.dart';
import 'poet_profile_screen.dart';

class DeepLinkShell extends StatefulWidget {
  final Widget child;

  const DeepLinkShell({
    super.key,
    required this.child,
  });

  @override
  State<DeepLinkShell> createState() => _DeepLinkShellState();
}

class _DeepLinkShellState extends State<DeepLinkShell> {
  final links = DeepLinkService();

  @override
  void initState() {
    super.initState();
    links.listen(handle);
  }

  Future<void> handle(DiwanDeepLink link) async {
    if (!AppConfig.hasSupabase || !mounted) return;

    try {
      final client = Supabase.instance.client;

      if (link.kind == 'poem') {
        final row = await client
            .from('poems')
            .select('id,title_ar')
            .eq('id', link.id)
            .single();

        if (!mounted) return;
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => CloudPoemDetailScreen(
              poemId: row['id'].toString(),
              title: row['title_ar']?.toString() ?? 'قصيدة',
            ),
          ),
        );
        return;
      }

      if (link.kind == 'poet') {
        final row = await client
            .from('poets')
            .select('id,name_ar')
            .eq('id', link.id)
            .single();

        if (!mounted) return;
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => PoetProfileScreen(
              poetId: row['id'].toString(),
              poetName: row['name_ar']?.toString() ?? 'شاعر',
            ),
          ),
        );
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تعذر فتح رابط ديوان المطلوب.'),
        ),
      );
    }
  }

  @override
  void dispose() {
    links.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
