import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class VerseEvidenceScreen extends StatefulWidget {
  final String verseId;
  final String verseText;

  const VerseEvidenceScreen({
    super.key,
    required this.verseId,
    required this.verseText,
  });

  @override
  State<VerseEvidenceScreen> createState() => _VerseEvidenceScreenState();
}

class _VerseEvidenceScreenState extends State<VerseEvidenceScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> evidence = const [];
  Map<String, dynamic>? readiness;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (!AppConfig.hasSupabase) {
      setState(() => loading = false);
      return;
    }

    try {
      final client = Supabase.instance.client;
      final ev = await client
          .from('textual_evidence')
          .select(
            'evidence_type,page_start,page_end,normalized_match,reviewer_note,'
            'sources(title,author_or_editor,publisher,edition,publication_year,url,reliability_score)',
          )
          .eq('verse_id', widget.verseId);

      final ready = await client
          .from('verse_verification_readiness')
          .select('*')
          .eq('verse_id', widget.verseId)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        evidence = List<Map<String, dynamic>>.from(ev as List);
        readiness =
            ready == null ? null : Map<String, dynamic>.from(ready);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أدلة البيت')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : !AppConfig.hasSupabase
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text(
                        'هذه الشاشة تحتاج Supabase وتشغيل mvp_2_3_evidence_model.sql.',
                      ),
                    ),
                  ),
                )
              : error != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(error!),
                    )
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(18),
                            child: Text(
                              widget.verseText,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 21,
                                height: 1.8,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        if (readiness != null)
                          Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  _line(
                                    'مصادر الأدلة',
                                    readiness!['evidence_source_count'],
                                  ),
                                  _line(
                                    'أدلة بصفحات',
                                    readiness!['page_evidence_count'],
                                  ),
                                  _line(
                                    'مطابقات رقمية',
                                    readiness!['digital_crosscheck_count'],
                                  ),
                                  _line(
                                    'مراجعة بشرية',
                                    readiness!['human_reviewed'] == true
                                        ? 'نعم'
                                        : 'لا',
                                  ),
                                  _line(
                                    'جاهز لـ verified',
                                    readiness!['ready_for_verified'] == true
                                        ? 'نعم'
                                        : 'لا',
                                  ),
                                ],
                              ),
                            ),
                          ),
                        const SizedBox(height: 12),
                        const Text(
                          'المصادر المرتبطة',
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 8),
                        if (evidence.isEmpty)
                          const Text('لم تتم إضافة أدلة تحريرية لهذا البيت بعد.'),
                        ...evidence.map((row) {
                          final source = row['sources'] is Map
                              ? Map<String, dynamic>.from(row['sources'])
                              : <String, dynamic>{};

                          final pageStart =
                              row['page_start']?.toString() ?? '';
                          final pageEnd =
                              row['page_end']?.toString() ?? '';
                          final pages = pageStart.isEmpty
                              ? 'الصفحة لم تسجل بعد'
                              : pageEnd.isEmpty || pageEnd == pageStart
                                  ? 'ص $pageStart'
                                  : 'ص $pageStart–$pageEnd';

                          return Card(
                            child: ListTile(
                              leading: const Icon(Icons.source_outlined),
                              title: Text(
                                source['title']?.toString() ?? 'مصدر',
                              ),
                              subtitle: Text(
                                '${row['evidence_type'] ?? ''}\n$pages',
                              ),
                              isThreeLine: true,
                            ),
                          );
                        }),
                      ],
                    ),
    );
  }

  Widget _line(String label, dynamic value) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Text(
              value?.toString() ?? '0',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ],
        ),
      );
}
