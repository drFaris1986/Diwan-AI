import 'package:flutter/material.dart';

import '../services/local_preferences_service.dart';
import 'deep_link_shell.dart';
import 'home_screen.dart';
import 'onboarding_screen.dart';

class StartupGate extends StatefulWidget {
  const StartupGate({super.key});

  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  bool loading = true;
  bool complete = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final value = await LocalPreferencesService().isOnboardingComplete();
    if (!mounted) return;
    setState(() {
      complete = value;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (!complete) {
      return OnboardingScreen(
        onComplete: () => setState(() => complete = true),
      );
    }

    return const DeepLinkShell(
      child: HomeScreen(),
    );
  }
}
