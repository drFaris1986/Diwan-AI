class AppConfig {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');

  /// Preferred client-side key name in current Supabase docs.
  static const supabasePublishableKey =
      String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

  /// Backward-compatible fallback for older project setups.
  static const legacyAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static String get clientKey =>
      supabasePublishableKey.isNotEmpty ? supabasePublishableKey : legacyAnonKey;

  static bool get hasSupabase =>
      supabaseUrl.isNotEmpty && clientKey.isNotEmpty;

  static bool get usesLegacyAnonKey =>
      supabasePublishableKey.isEmpty && legacyAnonKey.isNotEmpty;
}
