import '../models/verse_result.dart';
import 'poetry_repository.dart';

class AiAnswer {
  final String answer;
  final List<VerseResult> evidence;
  final bool isDemo;

  const AiAnswer({
    required this.answer,
    required this.evidence,
    this.isDemo = true,
  });
}

class AiAnswerService {
  final PoetryRepository repository;

  const AiAnswerService(this.repository);

  Future<AiAnswer> answerQuestion(String question) async {
    final evidence = await repository.searchVerses(question);

    if (evidence.isEmpty) {
      return const AiAnswer(
        answer:
            'لم أجد في قاعدة النسخة التجريبية نصًا كافيًا للإجابة بثقة. '
            'عند ربط قاعدة البيانات الكاملة سيعرض ديوان النتائج الموثقة ومصادرها قبل صياغة الإجابة.',
        evidence: [],
      );
    }

    final top = evidence.first;
    return AiAnswer(
      answer:
          'وجدت نتيجة مرتبطة بسؤالك في قاعدة ديوان التجريبية: '
          '«${top.text}» للشاعر ${top.poet} من ${top.poemTitle}. '
          'هذه إجابة MVP محلية، وسيتم لاحقًا تمرير الأدلة المسترجعة إلى نموذج الذكاء الاصطناعي '
          'مع إلزامه بالاستشهاد بالمصادر وعدم اختلاق أبيات غير موجودة.',
      evidence: evidence.take(3).toList(),
    );
  }
}
