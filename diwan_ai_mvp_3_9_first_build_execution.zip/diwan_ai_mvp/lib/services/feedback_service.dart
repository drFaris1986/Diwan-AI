import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class FeedbackService {
  Future<void> submit({
    required String category,
    required String message,
    String? screenName,
    Map<String, dynamic>? metadata,
  }) async {
    if (!AppConfig.hasSupabase) {
      throw StateError('Supabase is not configured.');
    }

    final client = Supabase.instance.client;
    final userId = client.auth.currentUser?.id;

    await client.from('beta_feedback').insert({
      'user_id': userId,
      'category': category,
      'message': message,
      'screen_name': screenName,
      'app_version': '2.1.0-beta',
      'metadata': metadata ?? const <String, dynamic>{},
    });
  }
}
