import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import '../models/rag_answer.dart';
import 'user_library_service.dart';

class RagService {
  Future<RagAnswer?> ask(String question) async {
    if (!AppConfig.hasSupabase) return null;

    final response = await Supabase.instance.client.functions.invoke(
      'ask-diwan',
      body: {'question': question},
    );

    if (response.status >= 400) {
      throw Exception(response.data?.toString() ?? 'RAG request failed');
    }

    final answer = RagAnswer.fromJson(
      Map<String, dynamic>.from(response.data as Map),
    );

    if (Supabase.instance.client.auth.currentUser != null) {
      final library = UserLibraryService(Supabase.instance.client);
      await library.saveQuestion(
        question: question,
        answer: answer.answer,
        confidence: answer.confidence,
        evidence: answer.evidence
            .map(
              (e) => {
                'text': e.text,
                'poet': e.poet,
                'poem_title': e.poemTitle,
                'era': e.era,
                'verification_status': e.verificationStatus,
                'similarity': e.similarity,
                'sources': e.sources,
              },
            )
            .toList(),
      );
    }

    return answer;
  }
}
