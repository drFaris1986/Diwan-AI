import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import 'local_poetry_repository.dart';
import 'poetry_repository.dart';
import 'supabase_poetry_repository.dart';

class RepositoryProvider {
  static PoetryRepository create() {
    if (AppConfig.hasSupabase) {
      return SupabasePoetryRepository(Supabase.instance.client);
    }
    return const LocalPoetryRepository();
  }
}
