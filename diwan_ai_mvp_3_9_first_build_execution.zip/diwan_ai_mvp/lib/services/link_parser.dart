class DiwanLink {
  final String kind;
  final String id;

  const DiwanLink({
    required this.kind,
    required this.id,
  });
}

class DiwanLinkParser {
  static DiwanLink? parse(Uri uri) {
    final segments = uri.pathSegments.where((e) => e.isNotEmpty).toList();

    String? kind;
    String? id;

    if (uri.scheme == 'diwanai') {
      kind = uri.host;
      if (segments.isNotEmpty) id = segments.first;
    } else if ((uri.scheme == 'https' || uri.scheme == 'http') &&
        segments.length >= 2) {
      kind = segments[0];
      id = segments[1];
    }

    if ((kind == 'poem' || kind == 'poet') &&
        id != null &&
        id.trim().isNotEmpty) {
      return DiwanLink(kind: kind, id: id);
    }

    return null;
  }
}
