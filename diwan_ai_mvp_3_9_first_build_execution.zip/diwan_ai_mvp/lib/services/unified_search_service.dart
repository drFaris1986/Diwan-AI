import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import '../models/search_result_item.dart';

class SearchFilters {
  final String? eraId;
  final String? poetId;
  final String? meter;
  final String? rhyme;

  const SearchFilters({
    this.eraId,
    this.poetId,
    this.meter,
    this.rhyme,
  });

  bool get isEmpty =>
      eraId == null && poetId == null && meter == null && rhyme == null;
}

class UnifiedSearchService {
  Future<List<SearchResultItem>> search(
    String query, {
    SearchFilters filters = const SearchFilters(),
  }) async {
    if (!AppConfig.hasSupabase || query.trim().isEmpty) return const [];

    final rows = await Supabase.instance.client.rpc(
      'search_poetry',
      params: {
        'query_text': query.trim(),
        'filter_era_id': filters.eraId,
        'filter_poet_id': filters.poetId,
        'filter_meter': filters.meter,
        'filter_rhyme': filters.rhyme,
        'result_limit': 50,
      },
    );

    return List<Map<String, dynamic>>.from(rows as List)
        .map(SearchResultItem.fromMap)
        .toList();
  }

  Future<List<Map<String, dynamic>>> eras() async {
    if (!AppConfig.hasSupabase) return const [];
    final rows = await Supabase.instance.client
        .from('eras')
        .select('id,name_ar')
        .order('id');
    return List<Map<String, dynamic>>.from(rows as List);
  }

  Future<List<Map<String, dynamic>>> poets() async {
    if (!AppConfig.hasSupabase) return const [];
    final rows = await Supabase.instance.client
        .from('poets')
        .select('id,name_ar,era_id')
        .order('name_ar');
    return List<Map<String, dynamic>>.from(rows as List);
  }

  Future<List<String>> distinctPoemField(String field) async {
    if (!AppConfig.hasSupabase) return const [];
    final rows = await Supabase.instance.client
        .from('poems')
        .select(field)
        .not(field, 'is', null);

    final values = List<Map<String, dynamic>>.from(rows as List)
        .map((e) => e[field]?.toString())
        .whereType<String>()
        .where((e) => e.trim().isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    return values;
  }
}
