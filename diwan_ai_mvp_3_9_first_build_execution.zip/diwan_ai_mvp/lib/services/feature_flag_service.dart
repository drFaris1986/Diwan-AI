import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class FeatureFlagService {
  Future<Map<String, bool>> load() async {
    const fallback = <String, bool>{
      'rag': true,
      'daily_verse': true,
      'share_cards': true,
      'favorites': true,
      'deep_links': true,
      'feedback': true,
    };

    if (!AppConfig.hasSupabase) return fallback;

    try {
      final row = await Supabase.instance.client
          .from('app_settings')
          .select('value')
          .eq('key', 'features')
          .maybeSingle();

      if (row == null || row['value'] is! Map) return fallback;

      final value = Map<String, dynamic>.from(row['value']);
      return {
        for (final entry in fallback.entries)
          entry.key: value[entry.key] is bool
              ? value[entry.key] as bool
              : entry.value,
      };
    } catch (_) {
      return fallback;
    }
  }
}
