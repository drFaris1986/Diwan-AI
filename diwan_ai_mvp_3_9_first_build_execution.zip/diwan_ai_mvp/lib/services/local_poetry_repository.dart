import '../data/mock_data.dart';
import '../models/source_reference.dart';
import '../models/verse_result.dart';
import 'arabic_normalizer.dart';
import 'poetry_repository.dart';

class LocalPoetryRepository implements PoetryRepository {
  const LocalPoetryRepository();

  @override
  Future<List<VerseResult>> searchVerses(
    String query, {
    int limit = 8,
  }) async {
    final q = ArabicNormalizer.normalize(query);
    if (q.isEmpty) return [];

    final results = <VerseResult>[];

    for (final poem in poems) {
      for (final verse in poem.verses) {
        final normalizedVerse = ArabicNormalizer.normalize(verse);
        final normalizedPoet = ArabicNormalizer.normalize(poem.poet);
        final normalizedTitle = ArabicNormalizer.normalize(poem.title);
        final normalizedEra = ArabicNormalizer.normalize(poem.era);

        var score = 0.0;
        if (normalizedVerse.contains(q)) score += 0.75;
        if (normalizedPoet.contains(q)) score += 0.55;
        if (normalizedTitle.contains(q)) score += 0.45;
        if (normalizedEra.contains(q)) score += 0.25;

        final queryTokens = q.split(' ').where((e) => e.isNotEmpty).toSet();
        final corpus = '$normalizedVerse $normalizedPoet $normalizedTitle';
        final matched = queryTokens.where(corpus.contains).length;
        if (queryTokens.isNotEmpty) {
          score += (matched / queryTokens.length) * 0.35;
        }

        if (score > 0) {
          results.add(
            VerseResult(
              text: verse,
              poet: poem.poet,
              poemTitle: poem.title,
              era: poem.era,
              verificationStatus: poem.sourceStatus,
              relevance: score.clamp(0, 1),
              sources: const [
                SourceReference(
                  title: 'بيانات تجريبية داخل MVP',
                  reliabilityScore: 0.50,
                ),
              ],
            ),
          );
        }
      }
    }

    results.sort((a, b) => b.relevance.compareTo(a.relevance));
    return results.take(limit).toList();
  }

  @override
  Future<List<VerseResult>> verifyVerse(String verseText) async {
    final q = ArabicNormalizer.normalize(verseText);
    if (q.length < 4) return [];

    final results = <VerseResult>[];
    for (final poem in poems) {
      for (final verse in poem.verses) {
        final v = ArabicNormalizer.normalize(verse);
        final exact = v == q;
        final contains = v.contains(q) || q.contains(v);

        if (exact || contains) {
          results.add(
            VerseResult(
              text: verse,
              poet: poem.poet,
              poemTitle: poem.title,
              era: poem.era,
              verificationStatus: poem.sourceStatus,
              relevance: exact ? 1.0 : 0.82,
              sources: const [
                SourceReference(
                  title: 'بيانات تجريبية داخل MVP',
                  reliabilityScore: 0.50,
                ),
              ],
            ),
          );
        }
      }
    }
    return results;
  }
}
