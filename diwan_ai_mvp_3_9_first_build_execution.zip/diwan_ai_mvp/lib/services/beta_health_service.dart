import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class BetaHealthResult {
  final String name;
  final bool ok;
  final String detail;

  const BetaHealthResult({
    required this.name,
    required this.ok,
    required this.detail,
  });
}

class BetaHealthService {
  Future<List<BetaHealthResult>> run() async {
    final results = <BetaHealthResult>[];

    results.add(
      BetaHealthResult(
        name: 'إعدادات Supabase',
        ok: AppConfig.hasSupabase,
        detail: AppConfig.hasSupabase
            ? (AppConfig.usesLegacyAnonKey
                ? 'متصل بمفتاح anon قديم؛ يفضّل الانتقال إلى publishable key.'
                : 'SUPABASE_URL و publishable key موجودان.')
            : 'لم يتم تمرير SUPABASE_URL و SUPABASE_PUBLISHABLE_KEY.',
      ),
    );

    if (!AppConfig.hasSupabase) return results;

    final client = Supabase.instance.client;

    Future<void> checkCount(String label, String table) async {
      try {
        final response =
            await client.from(table).select('id').limit(1);
        final rows = List<dynamic>.from(response as List);
        results.add(
          BetaHealthResult(
            name: label,
            ok: true,
            detail: rows.isEmpty
                ? 'الاتصال ناجح لكن الجدول لا يحتوي بيانات بعد.'
                : 'الاتصال والقراءة يعملان.',
          ),
        );
      } catch (e) {
        results.add(
          BetaHealthResult(
            name: label,
            ok: false,
            detail: e.toString(),
          ),
        );
      }
    }

    await checkCount('جدول الشعراء', 'poets');
    await checkCount('جدول القصائد', 'poems');
    await checkCount('جدول الأبيات', 'verses');

    try {
      final response = await client
          .from('daily_verse_catalog')
          .select('day')
          .limit(1);
      List<dynamic>.from(response as List);
      results.add(
        const BetaHealthResult(
          name: 'بيت اليوم',
          ok: true,
          detail: 'View daily_verse_catalog قابل للقراءة.',
        ),
      );
    } catch (e) {
      results.add(
        BetaHealthResult(
          name: 'بيت اليوم',
          ok: false,
          detail: e.toString(),
        ),
      );
    }

    try {
      await client.functions.invoke(
        'ask-diwan',
        body: {'question': 'اختبار جاهزية فقط'},
      );
      results.add(
        const BetaHealthResult(
          name: 'RAG Edge Function',
          ok: true,
          detail: 'ask-diwan استجابت للطلب.',
        ),
      );
    } catch (e) {
      results.add(
        BetaHealthResult(
          name: 'RAG Edge Function',
          ok: false,
          detail: e.toString(),
        ),
      );
    }

    return results;
  }
}
