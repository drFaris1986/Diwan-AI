import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class PoemReadingVerse {
  final String id;
  final int order;
  final String first;
  final String second;
  final int variantCount;
  final int evidenceCount;

  const PoemReadingVerse({
    required this.id,
    required this.order,
    required this.first,
    required this.second,
    required this.variantCount,
    required this.evidenceCount,
  });

  String get fullText => '$first $second'.trim();
}

class PoemReadingService {
  Future<List<PoemReadingVerse>> load(String poemId) async {
    if (!AppConfig.hasSupabase) return const [];

    final rows = await Supabase.instance.client
        .from('poem_reading_catalog')
        .select(
          'verse_id,verse_order,first_hemistich,second_hemistich,variant_count,evidence_count',
        )
        .eq('poem_id', poemId)
        .order('verse_order');

    return List<Map<String, dynamic>>.from(rows as List)
        .map(
          (row) => PoemReadingVerse(
            id: row['verse_id'].toString(),
            order: (row['verse_order'] as num?)?.toInt() ?? 0,
            first: row['first_hemistich']?.toString() ?? '',
            second: row['second_hemistich']?.toString() ?? '',
            variantCount: (row['variant_count'] as num?)?.toInt() ?? 0,
            evidenceCount: (row['evidence_count'] as num?)?.toInt() ?? 0,
          ),
        )
        .toList();
  }
}
