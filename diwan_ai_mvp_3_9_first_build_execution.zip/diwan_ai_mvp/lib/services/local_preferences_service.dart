import 'package:shared_preferences/shared_preferences.dart';

class LocalPreferencesService {
  static const _onboardingKey = 'onboarding_complete_v1';
  static const _compactReadingKey = 'compact_reading_mode';
  static const _showReviewLabelsKey = 'show_review_labels';

  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();

  Future<bool> isOnboardingComplete() async =>
      await _prefs.getBool(_onboardingKey) ?? false;

  Future<void> completeOnboarding() async =>
      await _prefs.setBool(_onboardingKey, true);

  Future<void> resetOnboarding() async =>
      await _prefs.remove(_onboardingKey);

  Future<bool> compactReadingMode() async =>
      await _prefs.getBool(_compactReadingKey) ?? false;

  Future<void> setCompactReadingMode(bool value) async =>
      await _prefs.setBool(_compactReadingKey, value);

  Future<bool> showReviewLabels() async =>
      await _prefs.getBool(_showReviewLabelsKey) ?? true;

  Future<void> setShowReviewLabels(bool value) async =>
      await _prefs.setBool(_showReviewLabelsKey, value);
}
