class ArabicNormalizer {
  static String normalize(String input) {
    var s = input.trim().toLowerCase();

    const replacements = {
      'أ': 'ا',
      'إ': 'ا',
      'آ': 'ا',
      'ٱ': 'ا',
      'ى': 'ي',
      'ؤ': 'و',
      'ئ': 'ي',
      'ة': 'ه',
    };

    replacements.forEach((from, to) {
      s = s.replaceAll(from, to);
    });

    // Remove common Arabic diacritics and tatweel.
    s = s.replaceAll(
      RegExp(r'[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]'),
      '',
    );

    s = s.replaceAll(RegExp(r'[^\u0600-\u06FFa-z0-9\s]'), ' ');
    s = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    return s;
  }
}
