import 'dart:async';

import 'package:app_links/app_links.dart';

import 'link_parser.dart';

class DiwanDeepLink {
  final String kind;
  final String id;

  const DiwanDeepLink({
    required this.kind,
    required this.id,
  });
}

class DeepLinkService {
  AppLinks? _appLinks;
  StreamSubscription<Uri>? _subscription;

  DiwanDeepLink? parse(Uri uri) {
    final parsed = DiwanLinkParser.parse(uri);
    if (parsed == null) return null;
    return DiwanDeepLink(kind: parsed.kind, id: parsed.id);
  }

  void listen(void Function(DiwanDeepLink link) onLink) {
    _subscription?.cancel();
    _appLinks ??= AppLinks();
    _subscription = _appLinks!.uriLinkStream.listen((uri) {
      final parsed = parse(uri);
      if (parsed != null) onLink(parsed);
    });
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
  }
}
