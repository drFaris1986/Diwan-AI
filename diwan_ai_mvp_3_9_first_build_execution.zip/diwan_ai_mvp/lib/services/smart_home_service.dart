import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class SmartHomeService {
  SupabaseClient? get _client =>
      AppConfig.hasSupabase ? Supabase.instance.client : null;

  Future<List<Map<String, dynamic>>> popularPoems() async {
    final client = _client;
    if (client == null) return const [];

    final rows = await client
        .from('popular_poems_30d')
        .select('*')
        .limit(8);

    return List<Map<String, dynamic>>.from(rows as List);
  }

  Future<List<Map<String, dynamic>>> continueReading() async {
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return const [];

    final rows = await client
        .from('continue_reading_catalog')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', ascending: false)
        .limit(5);

    return List<Map<String, dynamic>>.from(rows as List);
  }

  Future<List<Map<String, dynamic>>> personalizedSuggestions() async {
    final client = _client;
    if (client == null) return const [];

    final popular = await popularPoems();
    final user = client.auth.currentUser;
    if (user == null) return popular.take(6).toList();

    final favorites = await client
        .from('favorite_poems')
        .select('poem_id,poems(poet_id,era_id)')
        .eq('user_id', user.id)
        .limit(20);

    final favoriteRows =
        List<Map<String, dynamic>>.from(favorites as List);

    final poetIds = <String>{};
    final eraIds = <String>{};

    for (final row in favoriteRows) {
      final poem = row['poems'];
      if (poem is Map) {
        if (poem['poet_id'] != null) {
          poetIds.add(poem['poet_id'].toString());
        }
        if (poem['era_id'] != null) {
          eraIds.add(poem['era_id'].toString());
        }
      }
    }

    if (poetIds.isEmpty && eraIds.isEmpty) {
      return popular.take(6).toList();
    }

    final rows = await client
        .from('poems')
        .select(
          'id,title_ar,verification_status,poets(name_ar),era_id,poet_id',
        )
        .or(
          [
            if (poetIds.isNotEmpty)
              'poet_id.in.(${poetIds.map((e) => '"$e"').join(',')})',
            if (eraIds.isNotEmpty)
              'era_id.in.(${eraIds.map((e) => '"$e"').join(',')})',
          ].join(','),
        )
        .limit(12);

    return List<Map<String, dynamic>>.from(rows as List);
  }

  Future<void> saveReadingProgress({
    required String poemId,
    String? lastVerseId,
    int? lastVerseOrder,
    required double progressPercent,
  }) async {
    final client = _client;
    final user = client?.auth.currentUser;
    if (client == null || user == null) return;

    await client.from('reading_progress').upsert({
      'user_id': user.id,
      'poem_id': poemId,
      'last_verse_id': lastVerseId,
      'last_verse_order': lastVerseOrder,
      'progress_percent': progressPercent.clamp(0, 100),
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }
}
