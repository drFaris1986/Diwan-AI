import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/source_reference.dart';
import '../models/verse_result.dart';
import 'arabic_normalizer.dart';
import 'poetry_repository.dart';

class SupabasePoetryRepository implements PoetryRepository {
  final SupabaseClient client;

  const SupabasePoetryRepository(this.client);

  @override
  Future<List<VerseResult>> searchVerses(
    String query, {
    int limit = 8,
  }) async {
    final normalized = ArabicNormalizer.normalize(query);
    if (normalized.isEmpty) return [];

    final response = await client
        .from('verse_catalog')
        .select()
        .or(
          'normalized_text.ilike.%$normalized%,'
          'poet_name.ilike.%$query%,'
          'poem_title.ilike.%$query%,'
          'era_name.ilike.%$query%',
        )
        .limit(limit);

    final rows = List<Map<String, dynamic>>.from(response as List);

    return rows.map((row) {
      return VerseResult(
        text: row['full_text'] ?? '',
        poet: row['poet_name'] ?? '',
        poemTitle: row['poem_title'] ?? '',
        era: row['era_name'] ?? '',
        verificationStatus: row['verification_status'] ?? 'review_required',
        relevance: 0.75,
        sources: const [],
      );
    }).toList();
  }

  @override
  Future<List<VerseResult>> verifyVerse(String verseText) async {
    final normalized = ArabicNormalizer.normalize(verseText);
    if (normalized.length < 4) return [];

    final response = await client
        .from('verse_catalog')
        .select()
        .ilike('normalized_text', '%$normalized%')
        .limit(10);

    final rows = List<Map<String, dynamic>>.from(response as List);

    final results = <VerseResult>[];
    for (final row in rows) {
      final sourceResponse = await client
          .from('verse_sources')
          .select('page_reference, sources(title,reliability_score)')
          .eq('verse_id', row['verse_id']);

      final sources = <SourceReference>[];
      for (final item in List<Map<String, dynamic>>.from(sourceResponse as List)) {
        final source = item['sources'] as Map<String, dynamic>?;
        if (source == null) continue;
        sources.add(
          SourceReference(
            title: source['title'] ?? 'مصدر',
            page: item['page_reference'],
            reliabilityScore:
                (source['reliability_score'] as num?)?.toDouble() ?? 0.0,
          ),
        );
      }

      results.add(
        VerseResult(
          text: row['full_text'] ?? '',
          poet: row['poet_name'] ?? '',
          poemTitle: row['poem_title'] ?? '',
          era: row['era_name'] ?? '',
          verificationStatus: row['verification_status'] ?? 'review_required',
          relevance: 0.9,
          sources: sources,
        ),
      );
    }

    return results;
  }
}
