import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class AccountDeletionService {
  Future<void> requestDeletion({String? reason}) async {
    if (!AppConfig.hasSupabase) {
      throw StateError('Supabase is not configured.');
    }

    final client = Supabase.instance.client;
    final user = client.auth.currentUser;
    if (user == null) {
      throw StateError('Sign in is required.');
    }

    await client.from('account_deletion_requests').insert({
      'user_id': user.id,
      'reason': reason?.trim().isEmpty == true ? null : reason?.trim(),
      'status': 'requested',
    });
  }

  Future<Map<String, dynamic>?> latestRequest() async {
    if (!AppConfig.hasSupabase) return null;

    final client = Supabase.instance.client;
    final user = client.auth.currentUser;
    if (user == null) return null;

    final row = await client
        .from('account_deletion_requests')
        .select('*')
        .eq('user_id', user.id)
        .order('requested_at', ascending: false)
        .limit(1)
        .maybeSingle();

    if (row == null) return null;
    return Map<String, dynamic>.from(row);
  }

  /// Permanently deletes the authenticated account through a privileged
  /// Edge Function. A deletion request must already exist.
  Future<void> permanentlyDeleteAccount() async {
    if (!AppConfig.hasSupabase) {
      throw StateError('Supabase is not configured.');
    }

    final client = Supabase.instance.client;
    if (client.auth.currentUser == null) {
      throw StateError('Sign in is required.');
    }

    final response = await client.functions.invoke('delete-account');
    final data = response.data;

    if (data is Map && data['deleted'] == true) {
      await client.auth.signOut(scope: SignOutScope.local);
      return;
    }

    final message = data is Map ? data['error']?.toString() : null;
    throw StateError(message ?? 'Account deletion failed.');
  }
}
