import 'package:supabase_flutter/supabase_flutter.dart';

class UserLibraryService {
  final SupabaseClient client;

  const UserLibraryService(this.client);

  String get _userId {
    final id = client.auth.currentUser?.id;
    if (id == null) {
      throw StateError('User is not signed in.');
    }
    return id;
  }

  Future<void> favoritePoem(String poemId) async {
    await client.from('favorite_poems').upsert({
      'user_id': _userId,
      'poem_id': poemId,
    });
  }

  Future<void> unfavoritePoem(String poemId) async {
    await client
        .from('favorite_poems')
        .delete()
        .eq('user_id', _userId)
        .eq('poem_id', poemId);
  }

  Future<void> saveVerse(String verseId, {String? note}) async {
    await client.from('saved_verses').upsert({
      'user_id': _userId,
      'verse_id': verseId,
      'note': note,
    });
  }

  Future<List<Map<String, dynamic>>> favoritePoems() async {
    final response = await client
        .from('favorite_poems')
        .select(
          'created_at, poems(id,title_ar,verification_status,poets(name_ar),eras(name_ar))',
        )
        .eq('user_id', _userId)
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(response as List);
  }

  Future<List<Map<String, dynamic>>> savedVerses() async {
    final response = await client
        .from('saved_verses')
        .select(
          'note,created_at,verses(id,full_text,poems(title_ar,poets(name_ar)))',
        )
        .eq('user_id', _userId)
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(response as List);
  }

  Future<void> saveQuestion({
    required String question,
    required String answer,
    required double confidence,
    required List<Map<String, dynamic>> evidence,
  }) async {
    await client.from('question_history').insert({
      'user_id': _userId,
      'question': question,
      'answer': answer,
      'confidence': confidence,
      'evidence': evidence,
    });
  }
}
