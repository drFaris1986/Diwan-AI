import 'dart:math';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

class AnalyticsService {
  AnalyticsService._();

  static final AnalyticsService instance = AnalyticsService._();

  static final String _sessionId = _newSessionId();

  static String _newSessionId() {
    final random = Random();
    final a = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
    final b = random.nextInt(1 << 32).toRadixString(36);
    return '$a-$b';
  }

  SupabaseClient? get _client =>
      AppConfig.hasSupabase ? Supabase.instance.client : null;

  Future<void> track(
    String eventName, {
    String? poemId,
    String? verseId,
    Map<String, dynamic> metadata = const {},
  }) async {
    final client = _client;
    if (client == null) return;

    try {
      await client.from('app_events').insert({
        'event_name': eventName,
        'user_id': client.auth.currentUser?.id,
        'session_id': _sessionId,
        'poem_id': poemId,
        'verse_id': verseId,
        'metadata': metadata,
      });
    } catch (_) {
      // Analytics must never block the reading experience.
    }
  }

  Future<void> poemOpen(String poemId) => track(
        'poem_open',
        poemId: poemId,
      );

  Future<void> verseSave({
    required String poemId,
    required String verseId,
  }) =>
      track(
        'verse_save',
        poemId: poemId,
        verseId: verseId,
      );

  Future<void> favorite({
    required String poemId,
    required bool added,
  }) =>
      track(
        added ? 'favorite_add' : 'favorite_remove',
        poemId: poemId,
      );

  Future<void> verseShare({
    String? poemId,
    String? verseId,
    required String format,
  }) =>
      track(
        'verse_share',
        poemId: poemId,
        verseId: verseId,
        metadata: {'format': format},
      );

  Future<void> search({
    required int queryLength,
    required bool hasFilters,
    required int resultCount,
  }) =>
      track(
        'search_performed',
        metadata: {
          // Search text is intentionally NOT stored.
          'query_length': queryLength,
          'has_filters': hasFilters,
          'result_count': resultCount,
        },
      );
}
