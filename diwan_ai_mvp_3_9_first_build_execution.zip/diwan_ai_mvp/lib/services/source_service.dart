import 'package:supabase_flutter/supabase_flutter.dart';

class SourceService {
  final SupabaseClient client;
  const SourceService(this.client);

  Future<List<Map<String, dynamic>>> getPoemSources(String poemId) async {
    final response = await client
        .from('poem_sources')
        .select(
          'page_reference, notes, sources(title,author_or_editor,publisher,edition,publication_year,url,reliability_score)',
        )
        .eq('poem_id', poemId);

    return List<Map<String, dynamic>>.from(response as List);
  }
}
