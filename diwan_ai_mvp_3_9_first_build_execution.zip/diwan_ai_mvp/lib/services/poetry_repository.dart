import '../models/verse_result.dart';

abstract class PoetryRepository {
  Future<List<VerseResult>> searchVerses(String query, {int limit = 8});
  Future<List<VerseResult>> verifyVerse(String verseText);
}
