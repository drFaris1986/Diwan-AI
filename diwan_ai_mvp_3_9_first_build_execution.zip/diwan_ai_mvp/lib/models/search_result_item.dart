class SearchResultItem {
  final String type;
  final String id;
  final String? poemId;
  final String? poetId;
  final String? eraId;
  final String title;
  final String subtitle;
  final String matchedText;
  final int? verseOrder;
  final String? verificationStatus;
  final String? meter;
  final String? rhyme;
  final double score;

  const SearchResultItem({
    required this.type,
    required this.id,
    required this.poemId,
    required this.poetId,
    required this.eraId,
    required this.title,
    required this.subtitle,
    required this.matchedText,
    required this.verseOrder,
    required this.verificationStatus,
    required this.meter,
    required this.rhyme,
    required this.score,
  });

  factory SearchResultItem.fromMap(Map<String, dynamic> row) {
    return SearchResultItem(
      type: row['result_type']?.toString() ?? '',
      id: row['result_id'].toString(),
      poemId: row['poem_id']?.toString(),
      poetId: row['poet_id']?.toString(),
      eraId: row['era_id']?.toString(),
      title: row['title']?.toString() ?? '',
      subtitle: row['subtitle']?.toString() ?? '',
      matchedText: row['matched_text']?.toString() ?? '',
      verseOrder: (row['verse_order'] as num?)?.toInt(),
      verificationStatus: row['verification_status']?.toString(),
      meter: row['meter_ar']?.toString(),
      rhyme: row['rhyme_ar']?.toString(),
      score: (row['score'] as num?)?.toDouble() ?? 0,
    );
  }
}
