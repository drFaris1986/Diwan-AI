class Poem {
  final String title;
  final String poet;
  final String era;
  final String meter;
  final String rhyme;
  final String sourceStatus;
  final List<String> verses;

  const Poem({
    required this.title,
    required this.poet,
    required this.era,
    required this.meter,
    required this.rhyme,
    required this.sourceStatus,
    required this.verses,
  });
}
