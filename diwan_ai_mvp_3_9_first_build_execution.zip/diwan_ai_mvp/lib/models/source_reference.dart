class SourceReference {
  final String title;
  final String? page;
  final double reliabilityScore;

  const SourceReference({
    required this.title,
    this.page,
    required this.reliabilityScore,
  });
}
