class RagEvidence {
  final String text;
  final String poet;
  final String poemTitle;
  final String era;
  final String verificationStatus;
  final double similarity;
  final List<Map<String, dynamic>> sources;

  const RagEvidence({
    required this.text,
    required this.poet,
    required this.poemTitle,
    required this.era,
    required this.verificationStatus,
    required this.similarity,
    required this.sources,
  });

  factory RagEvidence.fromJson(Map<String, dynamic> json) {
    return RagEvidence(
      text: json['text']?.toString() ?? '',
      poet: json['poet']?.toString() ?? '',
      poemTitle: json['poem_title']?.toString() ?? '',
      era: json['era']?.toString() ?? '',
      verificationStatus:
          json['verification_status']?.toString() ?? 'review_required',
      similarity: (json['similarity'] as num?)?.toDouble() ?? 0,
      sources: List<Map<String, dynamic>>.from(
        (json['sources'] as List?) ?? const [],
      ),
    );
  }
}

class RagAnswer {
  final String answer;
  final double confidence;
  final List<RagEvidence> evidence;

  const RagAnswer({
    required this.answer,
    required this.confidence,
    required this.evidence,
  });

  factory RagAnswer.fromJson(Map<String, dynamic> json) {
    return RagAnswer(
      answer: json['answer']?.toString() ?? '',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0,
      evidence: ((json['evidence'] as List?) ?? const [])
          .map((e) => RagEvidence.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
    );
  }
}
