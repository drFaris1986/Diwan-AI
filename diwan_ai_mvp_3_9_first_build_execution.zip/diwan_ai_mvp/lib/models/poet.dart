class Poet {
  final String name;
  final String era;
  final String bio;
  final List<String> themes;

  const Poet({
    required this.name,
    required this.era,
    required this.bio,
    required this.themes,
  });
}
