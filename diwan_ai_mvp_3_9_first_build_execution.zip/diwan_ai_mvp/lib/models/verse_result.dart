import 'source_reference.dart';

class VerseResult {
  final String text;
  final String poet;
  final String poemTitle;
  final String era;
  final String verificationStatus;
  final double relevance;
  final List<SourceReference> sources;

  const VerseResult({
    required this.text,
    required this.poet,
    required this.poemTitle,
    required this.era,
    required this.verificationStatus,
    required this.relevance,
    this.sources = const [],
  });
}
