from pathlib import Path
import os, plistlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
ANDROID_MIN_SDK = 24
IOS_MIN_VERSION = "15.0"
CUSTOM_SCHEME = "diwanai"
domain = os.environ.get("DIWAN_APP_LINK_DOMAIN", "").strip()
android_app_id = os.environ.get("DIWAN_ANDROID_APP_ID", "").strip()
ios_bundle_id = os.environ.get("DIWAN_IOS_BUNDLE_ID", "").strip()

def fail(message):
    print(f"FAIL: {message}")
    sys.exit(1)

def configure_android():
    android = ROOT / "android"
    if not android.exists():
        print("SKIP Android: android/ not generated.")
        return
    manifest = android / "app/src/main/AndroidManifest.xml"
    if not manifest.exists():
        fail("AndroidManifest.xml not found.")
    text = manifest.read_text(encoding="utf-8")
    if "android.permission.INTERNET" not in text:
        first_close = text.find(">")
        text = text[:first_close+1] + '\n    <uses-permission android:name="android.permission.INTERNET" />' + text[first_close+1:]
    if "flutter_deeplinking_enabled" not in text:
        activity_start = text.find("<activity")
        activity_end = text.find(">", activity_start)
        insertion = '\n            <meta-data android:name="flutter_deeplinking_enabled" android:value="false" />'
        text = text[:activity_end+1] + insertion + text[activity_end+1:]
    if f'android:scheme="{CUSTOM_SCHEME}"' not in text:
        close_activity = text.find("</activity>")
        intent = "\n".join([
            "            <intent-filter>",
            '                <action android:name="android.intent.action.VIEW" />',
            '                <category android:name="android.intent.category.DEFAULT" />',
            '                <category android:name="android.intent.category.BROWSABLE" />',
            f'                <data android:scheme="{CUSTOM_SCHEME}" />',
            "            </intent-filter>",
            ""
        ])
        text = text[:close_activity] + intent + text[close_activity:]
    if domain and f'android:host="{domain}"' not in text:
        close_activity = text.find("</activity>")
        intent = "\n".join([
            '            <intent-filter android:autoVerify="true">',
            '                <action android:name="android.intent.action.VIEW" />',
            '                <category android:name="android.intent.category.DEFAULT" />',
            '                <category android:name="android.intent.category.BROWSABLE" />',
            f'                <data android:scheme="https" android:host="{domain}" android:pathPrefix="/poem" />',
            f'                <data android:scheme="https" android:host="{domain}" android:pathPrefix="/poet" />',
            "            </intent-filter>",
            ""
        ])
        text = text[:close_activity] + intent + text[close_activity:]
    manifest.write_text(text, encoding="utf-8")
    for gradle in [android/"app/build.gradle.kts", android/"app/build.gradle"]:
        if not gradle.exists(): continue
        g = gradle.read_text(encoding="utf-8")
        g = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", f"minSdk = {ANDROID_MIN_SDK}", g)
        g = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", f"minSdkVersion {ANDROID_MIN_SDK}", g)
        if android_app_id:
            g = re.sub(r'applicationId\s*=\s*"[^"]+"', f'applicationId = "{android_app_id}"', g)
            g = re.sub(r'applicationId\s+"[^"]+"', f'applicationId "{android_app_id}"', g)
            g = re.sub(r'namespace\s*=\s*"[^"]+"', f'namespace = "{android_app_id}"', g)
            g = re.sub(r'namespace\s+"[^"]+"', f'namespace "{android_app_id}"', g)
        gradle.write_text(g, encoding="utf-8")
    print(f"PASS Android configured: minSdk={ANDROID_MIN_SDK}, scheme={CUSTOM_SCHEME}, domain={domain or 'none'}")

def configure_ios():
    ios = ROOT / "ios"
    if not ios.exists():
        print("SKIP iOS: ios/ not generated.")
        return
    info = ios / "Runner/Info.plist"
    if not info.exists(): fail('iOS Runner/Info.plist not found.')
    with info.open("rb") as f: plist = plistlib.load(f)
    plist["FlutterDeepLinkingEnabled"] = False
    url_types = plist.setdefault("CFBundleURLTypes", [])
    if not any(CUSTOM_SCHEME in (entry.get("CFBundleURLSchemes") or []) for entry in url_types if isinstance(entry, dict)):
        url_types.append({"CFBundleURLName":"Diwan AI","CFBundleURLSchemes":[CUSTOM_SCHEME]})
    with info.open("wb") as f: plistlib.dump(plist, f, sort_keys=False)
    podfile = ios / "Podfile"
    if podfile.exists():
        t = podfile.read_text(encoding="utf-8")
        if re.search(r"platform\s*:ios", t):
            t = re.sub(r"platform\s*:ios,\s*'[^']+'", f"platform :ios, '{IOS_MIN_VERSION}'", t)
        else:
            t = f"platform :ios, '{IOS_MIN_VERSION}'\n" + t
        podfile.write_text(t, encoding="utf-8")
    if domain:
        entitlements = ios / "Runner/Runner.entitlements"
        with entitlements.open("wb") as f: plistlib.dump({"com.apple.developer.associated-domains":[f"applinks:{domain}"]}, f, sort_keys=False)
    pbxproj = ios / "Runner.xcodeproj/project.pbxproj"
    if pbxproj.exists():
        t = pbxproj.read_text(encoding="utf-8")
        t = re.sub(r"IPHONEOS_DEPLOYMENT_TARGET = [^;]+;", f"IPHONEOS_DEPLOYMENT_TARGET = {IOS_MIN_VERSION};", t)
        if ios_bundle_id:
            t = re.sub(r"PRODUCT_BUNDLE_IDENTIFIER = [^;]+;", f"PRODUCT_BUNDLE_IDENTIFIER = {ios_bundle_id};", t)
        pbxproj.write_text(t, encoding="utf-8")
    print(f"PASS iOS configured: min={IOS_MIN_VERSION}, scheme={CUSTOM_SCHEME}, domain={domain or 'none'}")

configure_android()
configure_ios()
