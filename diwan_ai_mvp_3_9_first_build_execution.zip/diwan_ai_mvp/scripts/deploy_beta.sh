#!/usr/bin/env bash
set -euo pipefail

: "${SUPABASE_PROJECT_REF:?Set SUPABASE_PROJECT_REF before deploy}"

if ! command -v supabase >/dev/null 2>&1; then
  echo "Supabase CLI is required."
  exit 1
fi

if [ ! -d "supabase/migrations" ]; then
  echo "supabase/migrations is missing."
  exit 1
fi

echo "== Linking project =="
supabase link --project-ref "$SUPABASE_PROJECT_REF"

echo "== Applying timestamped migrations =="
supabase db push

echo "== Deploying health =="
supabase functions deploy health

echo "== Deploying embed-verses =="
supabase functions deploy embed-verses

echo "== Deploying ask-diwan =="
supabase functions deploy ask-diwan

echo "== Deploying delete-account =="
supabase functions deploy delete-account

cat <<'EOF'

Deployment commands completed.

Required server secrets:
- OPENAI_API_KEY
- optional OPENAI_RAG_MODEL
- optional OPENAI_EMBEDDING_MODEL

Supabase-hosted Edge Functions should use the platform-provided secret/service key.
Never place OpenAI or Supabase secret keys in Flutter dart-defines.
EOF
