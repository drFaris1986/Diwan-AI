from pathlib import Path
import plistlib, re, sys
ROOT = Path(__file__).resolve().parents[1]
checks = []
def add(name, ok, detail=""): checks.append((name, bool(ok), detail))
android = ROOT/"android"
ios = ROOT/"ios"
if android.exists():
    manifest = android/"app/src/main/AndroidManifest.xml"
    text = manifest.read_text(encoding="utf-8") if manifest.exists() else ""
    add("android:internet", "android.permission.INTERNET" in text)
    add("android:plugin_deeplink_mode", 'flutter_deeplinking_enabled' in text and 'android:value="false"' in text)
    add("android:scheme", 'android:scheme="diwanai"' in text)
    gradle = next((p for p in [android/"app/build.gradle.kts", android/"app/build.gradle"] if p.exists()), None)
    g = gradle.read_text(encoding="utf-8") if gradle else ""
    add("android:min24", bool(re.search(r"minSdk(?:Version)?\s*(?:=\s*)?24", g)))
else:
    add("android:generated", False, "platform not generated")
if ios.exists():
    info = ios/"Runner/Info.plist"
    if info.exists():
        with info.open("rb") as f: plist = plistlib.load(f)
        add("ios:plugin_deeplink_mode", plist.get("FlutterDeepLinkingEnabled") is False)
        schemes = []
        for item in plist.get("CFBundleURLTypes", []): schemes.extend(item.get("CFBundleURLSchemes", []))
        add("ios:scheme", "diwanai" in schemes)
    pbx = ios/"Runner.xcodeproj/project.pbxproj"
    t = pbx.read_text(encoding="utf-8") if pbx.exists() else ""
    add("ios:min15", "IPHONEOS_DEPLOYMENT_TARGET = 15.0;" in t)
else:
    add("ios:generated", False, "platform not generated")
passed = sum(1 for _,ok,_ in checks if ok)
for n,ok,d in checks: print(("PASS" if ok else "PENDING"), n, d)
print(f"\n{passed}/{len(checks)} mobile config checks passed")
sys.exit(0)
