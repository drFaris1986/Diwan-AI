from pathlib import Path
import re
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
check(
    "pubspec:single_flutter_block",
    len(re.findall(r"(?m)^flutter:\s*$", pubspec)) == 1,
    f"found={len(re.findall(r'(?m)^flutter:\\s*$', pubspec))}",
)
check(
    "pubspec:data_asset",
    "- data/" in pubspec,
)

legacy_policy_hits = []
for p in (ROOT / "supabase").rglob("*.sql"):
    if "migrations" in p.parts:
        continue
    text = p.read_text(encoding="utf-8")
    if re.search(r"create\s+policy\s+if\s+not\s+exists", text, re.I):
        legacy_policy_hits.append(str(p.relative_to(ROOT)))
check(
    "sql:no_create_policy_if_not_exists",
    not legacy_policy_hits,
    ", ".join(legacy_policy_hits),
)

ask = (ROOT / "supabase/functions/ask-diwan/index.ts").read_text(encoding="utf-8")
check(
    "edge:ask_uses_secret_helper",
    "getSupabaseSecretKey()" in ask
    and 'Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")' not in ask,
)

migrations = sorted((ROOT / "supabase/migrations").glob("*.sql"))
check(
    "supabase:migrations_present",
    len(migrations) >= 16,
    f"count={len(migrations)}",
)

compat = (ROOT / "supabase/mvp_2_9_compatibility.sql").read_text(encoding="utf-8")
for field in [
    "editorial_notes",
    "reviewed_at",
    "license_status",
    "is_primary",
    "variant_type",
]:
    check(f"compat:{field}", field in compat)


check(
    "release:onboarding_screen",
    (ROOT / "lib/screens/onboarding_screen.dart").exists(),
)
check(
    "release:settings_screen",
    (ROOT / "lib/screens/settings_screen.dart").exists(),
)
check(
    "release:legal_screen",
    (ROOT / "lib/screens/legal_document_screen.dart").exists(),
)
check(
    "release:shared_preferences_compatible",
    "shared_preferences: ^2.5.3" in pubspec,
)
check(
    "release:startup_gate",
    "StartupGate" in (ROOT / "lib/main.dart").read_text(encoding="utf-8"),
)


check(
    "ops:delete_account_function",
    (ROOT / "supabase/functions/delete-account/index.ts").exists(),
)
check(
    "ops:release_pipeline",
    (ROOT / "scripts/release_pipeline.sh").exists(),
)
check(
    "ops:staging_smoke",
    (ROOT / "scripts/staging_smoke_test.py").exists(),
)


check(
    "mobile:github_workflow",
    (ROOT / ".github/workflows/mobile-build.yml").exists(),
)
check(
    "mobile:bootstrap_script",
    (ROOT / "scripts/bootstrap_mobile_platforms.sh").exists(),
)
check(
    "mobile:android_build_script",
    (ROOT / "scripts/build_android_ci.sh").exists(),
)
check(
    "mobile:ios_build_script",
    (ROOT / "scripts/build_ios_ci.sh").exists(),
)


check(
    "build_gate:normalizer_test",
    (ROOT / "test/arabic_normalizer_test.dart").exists(),
)
check(
    "build_gate:deep_link_test",
    (ROOT / "test/deep_link_parser_test.dart").exists(),
)
check(
    "build_gate:diagnostic_collector",
    (ROOT / "scripts/collect_flutter_diagnostics.sh").exists(),
)
check(
    "build_gate:failure_parser",
    (ROOT / "scripts/parse_flutter_failures.py").exists(),
)

check("native_config:configurer", (ROOT / "scripts/configure_mobile_platforms.py").exists())
check("native_config:verifier", (ROOT / "scripts/verify_mobile_platform_config.py").exists())

check("ci_handoff:repo_prepare", (ROOT / "scripts/prepare_github_repository.sh").exists())
check("ci_handoff:failure_summary", (ROOT / "scripts/ci_failure_summary.py").exists())
check("ci_handoff:exact_steps", (ROOT / "docs/github_setup_exact_steps.md").exists())

for json_file in (ROOT / "data").glob("*.json"):
    try:
        json.loads(json_file.read_text(encoding="utf-8"))
        check(f"json:{json_file.name}", True)
    except Exception as exc:
        check(f"json:{json_file.name}", False, str(exc))

passed = sum(1 for _, ok, _ in checks if ok)
total = len(checks)

for name, ok, detail in checks:
    suffix = f" — {detail}" if detail else ""
    print(("PASS" if ok else "FAIL"), name + suffix)

print(f"\n{passed}/{total} checks passed")
sys.exit(0 if passed == total else 1)
