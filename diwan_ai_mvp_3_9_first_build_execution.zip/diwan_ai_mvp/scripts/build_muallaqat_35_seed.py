"""
Converts the 35-verse digital-crosscheck batch to the project's poetry seed shape.
Every poem remains review_required.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
src = json.loads(
    (ROOT / "data/muallaqat_opening_35_verses.json").read_text(encoding="utf-8")
)

items = []
for poem in src["poems"]:
    items.append({
        "era": "العصر الجاهلي",
        "poet": poem["poet"],
        "poem": {
            "title_ar": poem["title"],
            "verification_status": "review_required",
            "editorial_notes": "دفعة مطابقة رقمية أولية؛ تحتاج مقابلة الطبعة وتسجيل الصفحات."
        },
        "source": {
            "title": "ويكي مصدر — مطابقة رقمية مساعدة",
            "url": poem["digital_source"],
            "source_type": "digital_crosscheck",
            "reliability_score": 0.60,
            "notes": "ليس مصدر الاعتماد النهائي."
        },
        "verses": [
            {
                "verse_order": i,
                "first_hemistich": v[0],
                "second_hemistich": v[1],
                "full_text": f"{v[0]} {v[1]}",
                "verification_status": "review_required"
            }
            for i, v in enumerate(poem["verses"], start=1)
        ]
    })

out = ROOT / "data/muallaqat_35_import_seed.json"
out.write_text(
    json.dumps({"items": items}, ensure_ascii=False, indent=2),
    encoding="utf-8"
)
print(out)
