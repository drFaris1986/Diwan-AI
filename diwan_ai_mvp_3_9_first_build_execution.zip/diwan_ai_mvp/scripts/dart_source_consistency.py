from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / "lib"
TEST = ROOT / "test"

failures = []
warnings = []

def fail(msg):
    failures.append(msg)

def warn(msg):
    warnings.append(msg)

pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
m = re.search(r"^name:\s*([A-Za-z0-9_]+)\s*$", pubspec, re.M)
package_name = m.group(1) if m else None
if not package_name:
    fail("pubspec package name not found")

dart_files = list(LIB.rglob("*.dart")) + list(TEST.rglob("*.dart"))

for dart in dart_files:
    text = dart.read_text(encoding="utf-8")
    imports = re.findall(r"import\s+'([^']+)';", text)
    for imp in imports:
        if imp.startswith("dart:"):
            continue
        if imp.startswith("package:"):
            if package_name and imp.startswith(f"package:{package_name}/"):
                rel = imp.split("/", 1)[1]
                target = LIB / rel
                if not target.exists():
                    fail(f"{dart.relative_to(ROOT)} imports missing {imp}")
            continue
        target = (dart.parent / imp).resolve()
        if not target.exists():
            fail(f"{dart.relative_to(ROOT)} imports missing {imp}")

if package_name:
    for dart in TEST.rglob("*.dart"):
        text = dart.read_text(encoding="utf-8")
        for pkg in re.findall(r"package:([A-Za-z0-9_]+)/", text):
            if pkg not in {package_name, "flutter_test", "flutter"}:
                fail(f"{dart.relative_to(ROOT)} uses package:{pkg}/ but pubspec name is {package_name}")

all_lib_text = "\n".join(p.read_text(encoding="utf-8") for p in LIB.rglob("*.dart"))

main = (LIB / "main.dart").read_text(encoding="utf-8")
if "publishableKey:" in main:
    fail("main.dart still uses publishableKey with the pinned Supabase client baseline")
if ".or([" in all_lib_text:
    warn("Found .or([ pattern; verify PostgREST filter receives a String")
if "StartupGate" in main and not (LIB / "screens/startup_gate.dart").exists():
    fail("StartupGate is referenced but startup_gate.dart is missing")

# Very simple delimiter-count smoke checks.
for dart in LIB.rglob("*.dart"):
    text = dart.read_text(encoding="utf-8")
    for left, right, label in [("(", ")", "parentheses"), ("[", "]", "brackets"), ("{", "}", "braces")]:
        if text.count(left) != text.count(right):
            warn(f"{dart.relative_to(ROOT)} has unequal raw {label} counts")

print(f"package={package_name}")
for item in warnings:
    print("WARN", item)
for item in failures:
    print("FAIL", item)

if failures:
    print(f"\nSource consistency: {len(failures)} failure(s), {len(warnings)} warning(s)")
    sys.exit(1)

print(f"\nSource consistency: PASS ({len(warnings)} warning(s))")
