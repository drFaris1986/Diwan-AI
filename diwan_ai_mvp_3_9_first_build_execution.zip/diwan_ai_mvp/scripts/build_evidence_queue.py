"""
Builds an editorial queue from muallaqat_evidence_batch_v1.json.
No automatic verified status is produced.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
src = json.loads(
    (ROOT / "data/muallaqat_evidence_batch_v1.json").read_text(encoding="utf-8")
)

rows = []
for index, item in enumerate(src["opening_verses"], start=1):
    rows.append({
        "priority": index,
        "poet": item["poet"],
        "poem": item["poem"],
        "first": item["first"],
        "second": item["second"],
        "primary_page_start": None,
        "primary_page_end": None,
        "secondary_page_start": None,
        "secondary_page_end": None,
        "digital_crosscheck": any(
            d["poet"] == item["poet"] for d in src["digital_crosschecks"]
        ),
        "material_variant": None,
        "human_reviewed": False,
        "decision": "pending_page_mapping",
    })

out = ROOT / "data/muallaqat_page_review_queue.json"
out.write_text(
    json.dumps(
        {
            "version": "1.0",
            "count": len(rows),
            "items": rows,
        },
        ensure_ascii=False,
        indent=2,
    ),
    encoding="utf-8",
)
print(out)
