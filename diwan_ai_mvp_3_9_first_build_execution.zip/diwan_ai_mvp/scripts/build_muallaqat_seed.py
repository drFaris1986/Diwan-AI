"""
Build a Supabase-import compatible JSON batch from the editorial catalog.
This creates only the opening verse for each Mu'allaqa.
It intentionally keeps verification_status=review_required.
"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
catalog = json.loads((ROOT / "data/muallaqat_seven_catalog.json").read_text(encoding="utf-8"))

source = {
    "title": "المعلقات السبع مع الحواشي المفيدة للزوزني",
    "author_or_editor": "الحسين بن أحمد الزوزني؛ تحقيق محمد خير أبو الوفا ومصطفى قصاص",
    "source_type": "critical_edition_candidate",
    "reliability_score": 0.85,
    "notes": "مرجع مرشح للمقابلة الأساسية؛ يلزم تسجيل الصفحة لكل قصيدة قبل verified."
}

poems = []
for item in catalog["poets"]:
    poems.append({
        "poet": item["name"],
        "era": item["era"],
        "title": item["muallaqa_title"],
        "verification_status": item["verification_status"],
        "source": source,
        "verses": [{
            "first": item["opening_first"],
            "second": item["opening_second"],
            "explanation": "مطلع المعلقة؛ شرح تفصيلي يضاف بعد المراجعة التحريرية."
        }]
    })

payload = {
    "dataset_version": "muallaqat-opening-v1",
    "poems": poems
}

out = ROOT / "data/muallaqat_opening_seed.json"
out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
print(out)
