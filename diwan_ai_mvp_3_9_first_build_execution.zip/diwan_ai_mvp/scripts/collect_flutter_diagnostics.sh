#!/usr/bin/env bash
set -u

OUT="${1:-build_diagnostics}"
mkdir -p "$OUT"

{
  echo "date=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "os=$(uname -a)"
  echo
  command -v flutter || true
  command -v dart || true
  command -v java || true
} > "$OUT/environment.txt" 2>&1

if command -v flutter >/dev/null 2>&1; then
  flutter --version > "$OUT/flutter_version.txt" 2>&1 || true
  flutter doctor -v > "$OUT/flutter_doctor.txt" 2>&1 || true
  flutter pub get > "$OUT/pub_get.txt" 2>&1 || true
  flutter analyze > "$OUT/analyze.txt" 2>&1 || true
  flutter test > "$OUT/test.txt" 2>&1 || true

  if [ -d android ]; then
    flutter build apk --debug > "$OUT/android_build.txt" 2>&1 || true
  fi

  if [ "$(uname -s)" = "Darwin" ] && [ -d ios ]; then
    flutter build ios --simulator > "$OUT/ios_build.txt" 2>&1 || true
  fi
else
  echo "Flutter SDK unavailable." > "$OUT/flutter_version.txt"
fi

tar -czf "${OUT}.tar.gz" "$OUT"
echo "${OUT}.tar.gz"
