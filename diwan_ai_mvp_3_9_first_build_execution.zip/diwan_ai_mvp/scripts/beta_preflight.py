"""
Diwan AI MVP 1.9 — local beta preflight

Checks source structure and environment values without needing Flutter SDK.
Does NOT compile the app.
"""

from pathlib import Path
import json
import os
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

checks = []

def check(name, ok, detail):
    checks.append((name, bool(ok), detail))

required_files = [
    "pubspec.yaml",
    "lib/main.dart",
    "lib/config/app_config.dart",
    "supabase/schema.sql",
    "supabase/mvp_1_4_rag.sql",
    "supabase/mvp_1_5_user_features.sql",
    "supabase/mvp_1_7_editorial.sql",
    "supabase/mvp_1_8_daily_verse.sql",
    "supabase/mvp_1_9_production_security.sql",
]

for rel in required_files:
    p = ROOT / rel
    check(f"file:{rel}", p.exists(), "present" if p.exists() else "missing")

# JSON integrity.
for rel in [
    "data/muallaqat_seven_catalog.json",
    "data/muallaqat_editorial_queue.json",
    "data/daily_verse_plan.json",
]:
    try:
        json.loads((ROOT / rel).read_text(encoding="utf-8"))
        check(f"json:{rel}", True, "valid JSON")
    except Exception as exc:
        check(f"json:{rel}", False, str(exc))

pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
check(
    "dependency:supabase_flutter",
    "supabase_flutter: ^2.15.4" in pubspec,
    "expected 2.15.4 baseline",
)
check(
    "dependency:share_plus",
    "share_plus: ^12.0.2" in pubspec,
    "expected 12.0.2 baseline",
)
check(
    "dependency:app_links",
    "app_links: ^6.4.1" in pubspec,
    "expected 6.4.1 baseline",
)

url = os.getenv("SUPABASE_URL", "")
publishable = os.getenv("SUPABASE_PUBLISHABLE_KEY", "")
legacy = os.getenv("SUPABASE_ANON_KEY", "")
check(
    "env:supabase",
    bool(url and (publishable or legacy)),
    "configured" if url and (publishable or legacy) else "not configured",
)

passed = sum(1 for _, ok, _ in checks if ok)
print(f"Diwan AI beta preflight: {passed}/{len(checks)} passed")
for name, ok, detail in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")

sys.exit(0 if passed == len(checks) else 1)
