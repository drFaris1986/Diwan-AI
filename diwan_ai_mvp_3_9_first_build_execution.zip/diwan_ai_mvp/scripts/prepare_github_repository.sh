#!/usr/bin/env bash
set -euo pipefail

if [ ! -d .git ]; then
  git init
  git branch -M main
fi

cat <<'EOF'
Diwan AI repository preparation complete.

Before pushing, configure GitHub:

Repository Variables:
  DIWAN_ANDROID_APP_ID
  DIWAN_IOS_BUNDLE_ID
  DIWAN_APP_LINK_DOMAIN

Repository Secrets:
  SUPABASE_URL
  SUPABASE_PUBLISHABLE_KEY

For the FIRST compile-only run, Supabase secrets may be left empty because
the Flutter app supports local mode. Do not put OpenAI or Supabase server
secret keys into GitHub mobile-client secrets.

Then:
  git add .
  git commit -m "Diwan AI first mobile build candidate"
  git remote add origin <YOUR_PRIVATE_REPOSITORY_URL>
  git push -u origin main

Open GitHub Actions and run:
  Diwan AI Mobile Build
EOF
