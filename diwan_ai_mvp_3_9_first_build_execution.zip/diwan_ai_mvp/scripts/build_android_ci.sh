#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required."
  exit 2
fi

if [ ! -d android ]; then
  bash scripts/bootstrap_mobile_platforms.sh
fi

flutter pub get
flutter analyze

if [ -d test ]; then
  flutter test
fi

# Debug APK gives us a deterministic compile gate without requiring a
# production signing keystore.
flutter build apk --debug \
  --dart-define=SUPABASE_URL="${SUPABASE_URL:-}" \
  --dart-define=SUPABASE_PUBLISHABLE_KEY="${SUPABASE_PUBLISHABLE_KEY:-}"

APK="build/app/outputs/flutter-apk/app-debug.apk"
test -f "$APK"

echo "ANDROID_BUILD_OK=$APK"
