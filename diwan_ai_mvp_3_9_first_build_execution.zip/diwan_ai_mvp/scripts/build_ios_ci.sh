#!/usr/bin/env bash
set -euo pipefail

if [ "$(uname -s)" != "Darwin" ]; then
  echo "iOS builds require macOS/Xcode."
  exit 3
fi

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required."
  exit 2
fi

if [ ! -d ios ]; then
  bash scripts/bootstrap_mobile_platforms.sh
fi

flutter pub get
flutter analyze

if [ -d test ]; then
  flutter test
fi

# Simulator build proves iOS compilation without requiring a paid signing
# identity or provisioning profile.
flutter build ios --simulator \
  --dart-define=SUPABASE_URL="${SUPABASE_URL:-}" \
  --dart-define=SUPABASE_PUBLISHABLE_KEY="${SUPABASE_PUBLISHABLE_KEY:-}"

APP="build/ios/iphonesimulator/Runner.app"
test -d "$APP"

echo "IOS_BUILD_OK=$APP"
