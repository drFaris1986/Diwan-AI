from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request

BASE = os.environ.get("SUPABASE_URL", "").rstrip("/")
KEY = os.environ.get("SUPABASE_PUBLISHABLE_KEY", "")

if not BASE or not KEY:
    print("Set SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY.")
    sys.exit(2)

headers = {
    "apikey": KEY,
    "Authorization": f"Bearer {KEY}",
    "Accept": "application/json",
}

checks = []

def get(name: str, url: str):
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            body = response.read().decode("utf-8")
            checks.append((name, response.status == 200, body[:180]))
    except Exception as exc:
        checks.append((name, False, str(exc)))

get("rest:eras", f"{BASE}/rest/v1/eras?select=id,name_ar&limit=1")
get("rest:poets", f"{BASE}/rest/v1/poets?select=id,name_ar&limit=1")
get("rest:poems", f"{BASE}/rest/v1/poems?select=id,title_ar&limit=1")
get("rest:verses", f"{BASE}/rest/v1/verses?select=id,verse_order&limit=1")
get("view:popular_poems", f"{BASE}/rest/v1/popular_poems_30d?select=poem_id,title_ar&limit=1")

# Edge health uses the publishable key as a normal function caller.
get("function:health", f"{BASE}/functions/v1/health")

passed = sum(1 for _, ok, _ in checks if ok)
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL"), name, detail)

print(f"\n{passed}/{len(checks)} staging smoke checks passed")
sys.exit(0 if passed == len(checks) else 1)
