from pathlib import Path
import re
import sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".")

patterns = [
    ("dart", re.compile(r"(?P<file>(?:lib|test)/[^:\n]+):(?P<line>\d+):(?P<col>\d+):\s*(?:Error:|error •)\s*(?P<message>.+)")),
    ("dependency", re.compile(r"Because\s+(?P<message>.+?)(?:\n\n|\Z)", re.S)),
    ("gradle", re.compile(r"(?:FAILURE: Build failed with an exception\.|What went wrong:)(?P<message>.+?)(?:\n\* Try:|\Z)", re.S)),
    ("xcode", re.compile(r"(?P<message>(?:error:|Error \(Xcode\):).+)", re.I)),
]

logs = list(ROOT.rglob("*.txt")) + list(ROOT.rglob("*.log"))
findings = []

for path in logs:
    text = path.read_text(encoding="utf-8", errors="replace")
    for category, pattern in patterns:
        for match in pattern.finditer(text):
            gd = match.groupdict()
            findings.append({
                "category": category,
                "file": gd.get("file"),
                "line": gd.get("line"),
                "column": gd.get("col"),
                "message": (gd.get("message") or "").strip().replace("\n", " ")[:700],
                "log": str(path),
            })

seen = set()
unique = []
for item in findings:
    key = (item["category"], item["file"], item["line"], item["message"])
    if key not in seen:
        seen.add(key)
        unique.append(item)

print(f"CI findings: {len(unique)}")
for index, item in enumerate(unique[:80], 1):
    loc = item["file"] or ""
    if item["line"]:
        loc += f":{item['line']}"
    print(f"{index}. [{item['category']}] {loc} {item['message']}")
    print(f"   source: {item['log']}")
