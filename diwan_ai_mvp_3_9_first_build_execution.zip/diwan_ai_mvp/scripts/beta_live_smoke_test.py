"""
Live smoke test for a connected Diwan AI Beta.

Required:
  SUPABASE_URL
  SUPABASE_PUBLISHABLE_KEY

Optional authenticated checks are intentionally excluded because
test-user credentials should not be committed to automation files.
"""

import json
import os
import sys
import urllib.error
import urllib.request

base = os.environ.get("SUPABASE_URL", "").rstrip("/")
key = os.environ.get("SUPABASE_PUBLISHABLE_KEY", "")

if not base or not key:
    print("FAIL: SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY are missing.")
    sys.exit(2)

headers = {
    "apikey": key,
    "Authorization": f"Bearer {key}",
    "Content-Type": "application/json",
}

checks = []

def request_json(name, method, url, body=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
            checks.append((name, True, response.status, payload))
    except Exception as exc:
        checks.append((name, False, None, str(exc)))

request_json("poets", "GET", f"{base}/rest/v1/poets?select=id,name_ar&limit=1")
request_json("poems", "GET", f"{base}/rest/v1/poems?select=id,title_ar&limit=1")
request_json("verses", "GET", f"{base}/rest/v1/verses?select=id,full_text&limit=1")
request_json("health", "POST", f"{base}/functions/v1/health", {})

passed = sum(1 for _, ok, _, _ in checks if ok)
print(f"Live smoke test: {passed}/{len(checks)} passed")
for name, ok, status, detail in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {name} status={status}: {detail}")

sys.exit(0 if passed == len(checks) else 1)
