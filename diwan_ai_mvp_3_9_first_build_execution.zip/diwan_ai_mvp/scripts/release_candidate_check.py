from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def add(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
main = (ROOT / "lib/main.dart").read_text(encoding="utf-8")

add("version:beta", "version: 0.3.0-beta.1+30" in pubspec)
add("dependency:shared_preferences", "shared_preferences: ^2.5.3" in pubspec)
add("startup:onboarding_gate", "StartupGate" in main)
add("legal:privacy_screen", (ROOT/"lib/screens/legal_document_screen.dart").exists())
add("account:deletion_screen", (ROOT/"lib/screens/account_deletion_screen.dart").exists())
add("account:deletion_migration", (ROOT/"supabase/mvp_3_1_account_release.sql").exists())
add("release:store_draft", (ROOT/"docs/store_listing_draft_ar.md").exists())
add("release:assets_checklist", (ROOT/"docs/store_release_assets_checklist.md").exists())
add("native:ios_present", (ROOT/"ios").exists(), "expected false until Flutter generation")
add("native:android_present", (ROOT/"android").exists(), "expected false until Flutter generation")

required_migrations = sorted((ROOT/"supabase/migrations").glob("*.sql"))
add("supabase:migrations", len(required_migrations) >= 17, f"count={len(required_migrations)}")

passed = sum(1 for _, ok, _ in checks if ok)
for name, ok, detail in checks:
    print(("PASS" if ok else "PENDING"), name, detail)

print(f"\nSource release gates: {passed}/{len(checks)}")
print("PENDING native checks are expected in this environment.")
sys.exit(0)
