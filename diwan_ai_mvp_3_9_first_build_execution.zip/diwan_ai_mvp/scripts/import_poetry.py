"""
Import reviewed poetry data into Supabase through the REST API.

Usage:
  export SUPABASE_URL="https://xxxx.supabase.co"
  export SUPABASE_SERVICE_ROLE_KEY="..."
  python scripts/import_poetry.py data/poetry_seed.json

This script is intentionally simple and designed for reviewed editorial batches.
Never ship the service-role key inside the mobile app.
"""

import json
import os
import sys
import urllib.request
import urllib.error

BASE = os.environ.get("SUPABASE_URL", "").rstrip("/")
KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")

if not BASE or not KEY:
    raise SystemExit("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY")

HEADERS = {
    "apikey": KEY,
    "Authorization": f"Bearer {KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=representation",
}

def request(path, method="GET", body=None):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        f"{BASE}/rest/v1/{path}",
        data=data,
        headers=HEADERS,
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"{e.code}: {e.read().decode('utf-8')}") from e

def get_one(table, query):
    rows = request(f"{table}?{query}&limit=1")
    return rows[0] if rows else None

def insert(table, payload):
    rows = request(table, method="POST", body=payload)
    return rows[0] if isinstance(rows, list) and rows else rows

def main(path):
    payload = json.loads(open(path, "r", encoding="utf-8").read())

    for poem in payload["poems"]:
        era = get_one("eras", f"name_ar=eq.{poem['era']}")
        if not era:
            raise RuntimeError(f"Era not found: {poem['era']}")

        poet = get_one("poets", f"name_ar=eq.{poem['poet']}")
        if not poet:
            poet = insert("poets", {
                "era_id": era["id"],
                "name_ar": poem["poet"],
                "name_normalized": poem["poet"],
                "bio_ar": poem.get("poet_bio"),
            })

        source_data = poem["source"]
        source = get_one("sources", f"title=eq.{source_data['title']}")
        if not source:
            source = insert("sources", {
                "title": source_data["title"],
                "author_or_editor": source_data.get("author_or_editor"),
                "publisher": source_data.get("publisher"),
                "edition": source_data.get("edition"),
                "publication_year": source_data.get("publication_year"),
                "url": source_data.get("url"),
                "source_type": source_data.get("source_type", "book"),
                "reliability_score": source_data.get("reliability_score", 0.8),
                "notes": source_data.get("notes"),
            })

        db_poem = insert("poems", {
            "poet_id": poet["id"],
            "era_id": era["id"],
            "title_ar": poem["title"],
            "title_normalized": poem["title"],
            "meter_ar": poem.get("meter"),
            "rhyme_ar": poem.get("rhyme"),
            "occasion_ar": poem.get("occasion"),
            "verification_status": poem.get("verification_status", "review_required"),
        })

        insert("poem_sources", {
            "poem_id": db_poem["id"],
            "source_id": source["id"],
            "page_reference": source_data.get("page_reference"),
            "notes": source_data.get("notes"),
        })

        for i, verse in enumerate(poem["verses"], start=1):
            db_verse = insert("verses", {
                "poem_id": db_poem["id"],
                "verse_order": i,
                "first_hemistich": verse["first"],
                "second_hemistich": verse.get("second"),
                "normalized_text": verse.get("normalized") or
                    (verse["first"] + " " + (verse.get("second") or "")),
                "explanation_ar": verse.get("explanation"),
                "vocabulary_ar": verse.get("vocabulary", {}),
                "rhetoric_ar": verse.get("rhetoric", []),
            })

            insert("verse_sources", {
                "verse_id": db_verse["id"],
                "source_id": source["id"],
                "page_reference": source_data.get("page_reference"),
                "quote_variant": verse.get("quote_variant"),
            })

        print("Imported:", poem["title"])

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python scripts/import_poetry.py data/poetry_seed.json")
    main(sys.argv[1])
