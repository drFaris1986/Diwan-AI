"""
Quickly inspect embedding coverage in Supabase via REST.
Requires:
  SUPABASE_URL
  SUPABASE_SERVICE_ROLE_KEY
"""
import json, os, urllib.request

url = os.environ["SUPABASE_URL"].rstrip("/")
key = os.environ["SUPABASE_SERVICE_ROLE_KEY"]

req = urllib.request.Request(
    f"{url}/rest/v1/verses?select=id,full_text,embedding",
    headers={
        "apikey": key,
        "Authorization": f"Bearer {key}",
    },
)

with urllib.request.urlopen(req) as r:
    rows = json.loads(r.read().decode("utf-8"))

total = len(rows)
embedded = sum(1 for x in rows if x.get("embedding") is not None)

print(f"Total verses: {total}")
print(f"Embedded: {embedded}")
print(f"Pending: {total - embedded}")
print(f"Coverage: {(embedded / total * 100) if total else 0:.1f}%")
