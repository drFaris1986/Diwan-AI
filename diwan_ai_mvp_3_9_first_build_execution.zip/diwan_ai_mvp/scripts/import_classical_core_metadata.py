"""
Imports the 20-poet classical core metadata into Supabase.
It DOES NOT import poem text.

Required:
  SUPABASE_URL
  SUPABASE_SERVICE_ROLE_KEY  (legacy)
or a trusted server secret adapted to your deployment environment.

This script is intentionally metadata-first.
"""
import json
import os
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
payload = json.loads((ROOT / "data/classical_core_20_poets.json").read_text(encoding="utf-8"))

BASE = os.environ["SUPABASE_URL"].rstrip("/")
KEY = os.environ["SUPABASE_SERVICE_ROLE_KEY"]

headers = {
    "apikey": KEY,
    "Authorization": f"Bearer {KEY}",
    "Content-Type": "application/json",
    "Prefer": "return=representation,resolution=merge-duplicates",
}

def request(path, method="GET", body=None):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else None

def find_or_create_era(name):
    rows = request(f"/rest/v1/eras?name_ar=eq.{urllib.parse.quote(name)}&select=id&limit=1")
    if rows:
        return rows[0]["id"]
    created = request("/rest/v1/eras", "POST", [{"name_ar": name}])
    return created[0]["id"]

# urllib.parse is loaded lazily to keep imports clear.
import urllib.parse

for item in payload["poets"]:
    era_id = find_or_create_era(item["era"])
    body = [{
        "name_ar": item["name"],
        "era_id": era_id,
        "bio_ar": f"شاعر ضمن النواة الكلاسيكية لديوان AI. حالة المصدر: {item['source_status']}.",
    }]
    request(
        "/rest/v1/poets?on_conflict=name_ar",
        "POST",
        body,
    )
    print("UPSERT:", item["name"])

print("Done. Poem text was not imported.")
