from pathlib import Path
import re
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else "build_diagnostics")
files = [
    "pub_get.txt",
    "analyze.txt",
    "test.txt",
    "android_build.txt",
    "ios_build.txt",
]

patterns = [
    re.compile(r"error • (?P<msg>.*?) • (?P<file>[^:]+):(?P<line>\d+):(?P<col>\d+)"),
    re.compile(r"(?P<file>lib/[^:\n]+):(?P<line>\d+):(?P<col>\d+): Error: (?P<msg>.+)"),
    re.compile(r"Because (?P<msg>.+)"),
    re.compile(r"FAILURE: Build failed with an exception\.(?P<msg>.*)", re.S),
]

found = []
for name in files:
    path = root / name
    if not path.exists():
        continue
    text = path.read_text(encoding="utf-8", errors="replace")
    for pattern in patterns:
        for match in pattern.finditer(text):
            item = {k: v for k, v in match.groupdict().items() if v}
            item["source_log"] = name
            found.append(item)

print(f"diagnostic_findings={len(found)}")
for i, item in enumerate(found[:100], start=1):
    location = ""
    if "file" in item:
        location = f"{item['file']}:{item.get('line','')}:{item.get('col','')}"
    print(f"{i}. [{item['source_log']}] {location} {item.get('msg','').strip()[:500]}")
