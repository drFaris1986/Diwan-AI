#!/usr/bin/env bash
set -euo pipefail

echo "Diwan AI — First CI Run Checklist"
echo
echo "[1] Required project files"
for f in \
  pubspec.yaml \
  .github/workflows/mobile-build.yml \
  scripts/bootstrap_mobile_platforms.sh \
  scripts/build_android_ci.sh \
  scripts/build_ios_ci.sh \
  scripts/dart_source_consistency.py \
  scripts/compile_risk_scan.py
do
  test -f "$f"
  echo "PASS $f"
done

echo
echo "[2] Local non-Flutter checks"
python3 scripts/dart_source_consistency.py
python3 scripts/compile_risk_scan.py
python3 scripts/project_structure_preflight.py

echo
echo "[3] Current binary status"
echo "Android APK: pending external Flutter CI"
echo "iOS Simulator app: pending macOS Flutter CI"
echo
echo "NEXT: push this repository and run 'Diwan AI Mobile Build'."
