from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / "lib"

findings = []
patterns = [
    ("publishableKey parameter", r"publishableKey\s*:"),
    ("service role in Flutter", r"SUPABASE_SERVICE_ROLE_KEY"),
    ("OpenAI key in Flutter", r"OPENAI_API_KEY"),
    ("hardcoded secret-like token", r"(?:sk-|sb_secret_)[A-Za-z0-9_-]{12,}"),
]

for path in LIB.rglob("*.dart"):
    text = path.read_text(encoding="utf-8")
    for label, pattern in patterns:
        if re.search(pattern, text):
            findings.append(f"{label}: {path.relative_to(ROOT)}")

if findings:
    for item in findings:
        print("FAIL", item)
    sys.exit(1)

print("Compile/security risk scan: PASS")
