#!/usr/bin/env bash
set -euo pipefail

echo "== Diwan AI release pipeline =="

python3 scripts/project_structure_preflight.py
python3 scripts/release_candidate_check.py

if command -v flutter >/dev/null 2>&1; then
  echo "== Flutter checks =="
  flutter pub get
  flutter analyze
  if [ -d test ]; then
    flutter test
  fi
else
  echo "PENDING: Flutter SDK is not installed; build/analyze/test skipped."
fi

if [ -n "${SUPABASE_URL:-}" ] && [ -n "${SUPABASE_PUBLISHABLE_KEY:-}" ]; then
  echo "== Staging smoke test =="
  python3 scripts/staging_smoke_test.py
else
  echo "PENDING: Supabase staging environment is not configured."
fi

echo
echo "Mobile build scripts available:"
echo "- scripts/build_android_ci.sh"
echo "- scripts/build_ios_ci.sh"
echo "Use GitHub Actions workflow .github/workflows/mobile-build.yml for cross-platform builds."
echo "Release pipeline finished."
