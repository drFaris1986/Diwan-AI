#!/usr/bin/env bash
set -euo pipefail
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required."
  exit 2
fi
flutter --version
flutter create --platforms=android,ios --project-name diwan_ai --org com.example .
python3 scripts/configure_mobile_platforms.py
test -d android && echo "PASS android/"
test -d ios && echo "PASS ios/"
