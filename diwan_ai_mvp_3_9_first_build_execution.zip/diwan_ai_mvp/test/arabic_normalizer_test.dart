import 'package:flutter_test/flutter_test.dart';
import 'package:diwan_ai/services/arabic_normalizer.dart';

void main() {
  group('ArabicNormalizer', () {
    test('removes Arabic diacritics and normalizes alif forms', () {
      expect(
        ArabicNormalizer.normalize('عَلى قَدرِ أَهلِ العَزمِ'),
        'علي قدر اهل العزم',
      );
    });

    test('normalizes taa marbuta and alef maqsura', () {
      expect(
        ArabicNormalizer.normalize('حكمة فتى'),
        'حكمه فتي',
      );
    });

    test('collapses punctuation and whitespace', () {
      expect(
        ArabicNormalizer.normalize('المتنبي،   شاعر!'),
        'المتنبي شاعر',
      );
    });
  });
}
