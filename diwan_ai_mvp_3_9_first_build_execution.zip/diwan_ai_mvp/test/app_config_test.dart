import 'package:flutter_test/flutter_test.dart';
import 'package:diwan_ai/config/app_config.dart';

void main() {
  test('clientKey resolves without throwing', () {
    expect(AppConfig.clientKey, isA<String>());
  });
}
