import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:diwan_ai/screens/onboarding_screen.dart';

void main() {
  testWidgets('onboarding renders first page', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: OnboardingScreen(onComplete: () {}),
      ),
    );

    expect(find.text('الشعر العربي في مكان واحد'), findsOneWidget);
    expect(find.text('التالي'), findsOneWidget);
  });
}
