import 'package:flutter_test/flutter_test.dart';
import 'package:diwan_ai/services/link_parser.dart';

void main() {
  test('parses custom-scheme poem link', () {
    final link = DiwanLinkParser.parse(Uri.parse('diwanai://poem/1234'));
    expect(link, isNotNull);
    expect(link!.kind, 'poem');
    expect(link.id, '1234');
  });

  test('parses https poet link', () {
    final link = DiwanLinkParser.parse(Uri.parse('https://diwanai.app/poet/abcd'));
    expect(link, isNotNull);
    expect(link!.kind, 'poet');
    expect(link.id, 'abcd');
  });

  test('rejects unsupported link kind', () {
    expect(DiwanLinkParser.parse(Uri.parse('diwanai://unknown/1234')), isNull);
  });
}
