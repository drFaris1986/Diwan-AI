# ديوان AI — MVP 3.9 First Build Execution Package

تطبيق عربي متخصص في الشعر العربي، مع بنية جاهزة للانتقال من البيانات المحلية إلى Supabase.

## المزايا الحالية
- Flutter / iPhone / Android
- RTL عربي
- العصور
- الشعراء
- القصائد
- البحث
- "هل هذا البيت صحيح؟"
- "اسأل ديوان"
- استرجاع الأدلة قبل الإجابة
- Supabase اختياري
- وضع Local fallback عند عدم توفر مفاتيح Supabase
- قاعدة PostgreSQL جاهزة
- RLS للقراءة العامة
- مصادر ودرجة موثوقية
- حالة توثيق للقصيدة
- سكربت استيراد دفعات شعرية مراجعة

## تشغيل سريع بدون Supabase
```bash
flutter pub get
flutter run
```

## تشغيل مع Supabase
```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

راجع:
- `docs/supabase_setup.md`
- `docs/rag_architecture.md`
- `docs/data_ingestion_plan.md`
- `docs/mvp_roadmap.md`

## ملاحظة تحريرية
البيانات المرفقة داخل MVP تجريبية. قبل الإطلاق العام يجب استبدال سجلات المصادر التجريبية بمراجع محققة ومراجعة النصوص والروايات.


## Dataset v1
تمت إضافة أول حزمة قابلة للتتبع لـ5 شعراء و5 قصائد في `data/poetry_seed_traceable_v1.json`، مع مصدر URL وحالة مراجعة لكل سجل.


## MVP 1.4 — RAG
أضيفت:
- `pgvector` + HNSW index.
- دالة `match_verses`.
- Edge Function لتوليد embeddings.
- Edge Function `ask-diwan`.
- OpenAI embeddings على الخادم.
- إجابة RAG مقيدة بالأدلة.
- عرض الأدلة وحالة التوثيق والمصادر.
- مؤشر ثقة إرشادي.
- شاشة Flutter مستقلة لاختبار RAG.

راجع `docs/rag_setup_mvp_1_4.md`.


## MVP 1.5
- حساب مستخدم عبر Supabase Auth.
- المفضلة.
- حفظ الأبيات.
- سجل أسئلة RAG.
- شاشة "حسابي".
- شاشة "مكتبتي".
- Source Registry لمراجع محققة للمعلقات.
- Workflow صارم للانتقال من `review_required` إلى `verified`.

مهم: لم نرفع حالة القصائد إلى `verified` آليًا؛ الاعتماد النهائي يتطلب مقابلة النص والصفحة والروايات.


## MVP 1.6
- صفحة شاعر احترافية من Supabase.
- صفحة قصيدة تعرض الأبيات والمصادر وحالة التوثيق.
- حفظ القصيدة في المفضلة.
- حفظ بيت في مكتبة المستخدم.
- كتالوج المعلقات السبع.
- أداة لبناء Seed للمطالع السبعة.

راجع:
- `docs/mvp_1_6.md`
- `docs/editorial_checklist_muallaqat.md`


## MVP 1.7
- بطاقة شعرية PNG قابلة للمشاركة.
- Share Sheet للنص والصورة.
- عرض تنبيه المراجعة على البطاقات غير الموثقة.
- دعم اختلاف الروايات.
- سجل مراجعة بشرية.
- شاشة "حالة التوثيق التحريري".

ملاحظة بيئية: المشروع ما زال مولدًا كمصدر ولم يتم تجميعه في هذه البيئة لعدم توفر Flutter SDK.


## MVP 1.8
- بيت اليوم.
- مشاركة بيت اليوم.
- Deep Links للقصائد والشعراء.
- لوحة تحرير لقياس جاهزية الاعتماد.
- `app_links ^6.4.1` مع baseline Dart 3.5.

المشروع لم يُجمع في هذه البيئة لعدم توفر Flutter SDK؛ الكود يحتاج اختبار جهاز فعلي قبل Beta.


## MVP 1.9 — Beta Preparation
- اعتماد `publishableKey` لتهيئة Supabase.
- baseline حزم متوافق مع Dart 3.5.
- SQL أمان Production.
- شاشة جاهزية Beta.
- Local preflight script.
- Beta test matrix.
- `.env.example` يوضح الفصل بين مفاتيح العميل والأسرار الخادمية.

راجع `docs/mvp_1_9_beta_preparation.md`.


## MVP 2.0 — Beta Candidate
- Modern Supabase secret-key support in Edge Functions.
- OpenAI configuration centralized server-side.
- Health Edge Function.
- Deployment script.
- Live smoke-test script.
- Beta launch checklist.

This package is ready for connection to a real Supabase project, but no live project credentials are bundled.


## MVP 2.1 — Beta Operations
- Remote feature flags.
- Beta feedback collection.
- Feedback RLS.
- Beta information screen.
- Operational triage documentation.

هذه المرحلة مخصصة لتشغيل Beta حقيقية وجمع الملاحظات عند ربط Supabase.


## MVP 2.2 — Content Expansion
- Classical core: 20 poets.
- First-batch target: 100 poems.
- Expanded source registry.
- Content expansion SQL queue/status view.
- Metadata-only import script.
- In-app content expansion screen.

Important: bulk poem text remains blocked until edition/page review is completed.


## MVP 2.3 — Muallaqat Evidence
- Page-level textual evidence model.
- Verse verification readiness view.
- Human-review state per verse.
- Muallaqat opening-verse evidence batch.
- Page-review queue.
- "أدلة البيت" screen.

Important: no page number is invented. Current Muallaqat openings remain ready_for_page_mapping until the scanned editions are reviewed.


## MVP 2.4 — Muallaqat Progress
- 35-verse Muallaqat opening batch.
- 5 opening verses per Muallaqa.
- Digital crosscheck sources.
- Import-ready seed.
- Documentation progress SQL view.
- In-app progress screen.

No verse has been upgraded to verified; page mapping and human review are still required.


## MVP 2.5 — Reading & Variants
- Search inside a poem.
- Jump to verse number.
- Font-size controls.
- Verse evidence counters.
- Verse variant counters.
- Dedicated variant screen.
- 100-verse expansion plan with editorial safety rules.

The current crosschecked Muallaqat corpus remains 35 verses; no additional verse text was fabricated to reach the 100-verse target.


## MVP 2.6 — Unified Search
- One search engine for poets, poems, and verses.
- Filters by era, poet, meter, and rhyme.
- PostgreSQL trigram search and indexes.
- Result-type cards and direct navigation.
- Search quality test cases.

Exact/lexical evidence remains distinct from semantic RAG similarity.


## MVP 2.7 — Smart Home
- Continue reading.
- 30-day popular poems.
- Lightweight personalization from favorites.
- Reading progress persistence.
- RLS-protected per-user reading state.
- Smart-home UI.

Popularity event ingestion is intentionally left for the next iteration.


## MVP 2.8 — Analytics & Events
- Real app event ingestion.
- Poem open, save, favorite, share, and search tracking.
- Search text is never stored in analytics.
- Popularity counters are updated by a database trigger.
- 30-day aggregate Beta dashboard.
- Raw analytics rows are not readable by Flutter clients.

This source was generated without compiling because a Flutter SDK is not available in the current execution environment.


## MVP 2.9 — Production Hardening
- Fixed duplicate Flutter YAML block.
- Repaired legacy policy syntax.
- Added schema compatibility migration.
- Added real timestamped Supabase migrations.
- Hardened Edge Function secret handling.
- Updated deploy flow.
- Added release gate and structural preflight.

Structural preflight passes in this environment. Flutter compilation and live Supabase deployment remain untested because those runtimes/credentials are not available here.


## MVP 3.0 — Beta Release Candidate
- Persistent first-run onboarding.
- Settings screen.
- In-app privacy and terms drafts.
- Store listing draft and release-assets checklist.
- Version bumped to `0.3.0-beta.1+30`.
- Uses `shared_preferences 2.5.3` with the async API for Dart 3.5 compatibility.

No App Store or Google Play submission has been performed. Native iOS/Android project folders are not present yet, and Flutter compilation is still pending.


## MVP 3.1 — Release Readiness
- Account deletion request flow.
- RLS-protected deletion request table.
- In-app release readiness screen.
- 17th timestamped migration.
- Release candidate source checker.

Destructive account deletion is intentionally not performed from the Flutter client; it must be completed by a privileged backend/admin workflow.


## MVP 3.2 — Operational Beta
- Privileged server-side account deletion Edge Function.
- Client never receives an admin/service secret.
- Final account deletion confirmation flow.
- Unified release pipeline.
- Staging smoke-test script.
- Beta operations runbook.

Live deployment is still pending until a real Supabase staging project and Flutter SDK are available.


## MVP 3.3 — Mobile Build Infrastructure
- GitHub Actions Android build on Linux.
- GitHub Actions iOS Simulator build on macOS.
- Mobile platform bootstrap script.
- Android debug APK build script.
- iOS Simulator compile script.
- CI artifact upload for both platforms.

The current execution container does not have Flutter SDK, Android SDK, or macOS/Xcode, so no mobile binary was falsely claimed. The CI workflow is the next executable gate.


## MVP 3.4 — First Real Build Gate
- CI quality gate before Android/iOS.
- Real Flutter unit tests.
- Android APK and iOS simulator jobs depend on analyze/tests.
- Build diagnostics collector and parser.
- Flutter version pinned to 3.47.2.

The next milestone is not another feature: it is the first green CI run producing mobile artifacts.


## MVP 3.5
Automated Android/iOS native configuration after Flutter platform generation.


## MVP 3.6 — CI Execution Handoff
- Quality/Android/iOS GitHub Actions gates.
- Repository-variable support for real app identifiers and link domain.
- Client-safe Supabase secret wiring.
- Git repository preparation script.
- CI failure summarizer.
- Explicit current build status.

The project is now prepared for the first external CI execution. No binary is marked built until an actual workflow artifact exists.


## MVP 3.7
Added pre-CI Dart source consistency checks and fixed likely client API compatibility issues before the first real Flutter compile.


## MVP 3.8
Reduced plugin-dependent test risk and added a compile/security risk scan before Flutter CI.


## MVP 3.9 — First Build Execution Package

The project is feature-frozen for the first compile gate.

Start here:
`docs/FIRST_BUILD_NOW.md`

The next useful input is a GitHub Actions result or its failure-log artifact. Android/iOS are not marked built until actual CI artifacts exist.
